package UserInfo;

/**
 * Created by KyoungSik on 2017-04-11.
 * 사업자 회원 정보를 가지는 클래스
 */
public class CompanyUserInfo {

    private String eailid;
    private String companyName;
    private String companyCeoName;
    private String companyBusinessNumber;
    private String companyType;
    private String companyBusiness;
    private String companyAddress;
    private String phoneNumver;
    private String companyPhoneNumber;
    private String profile_img;

    public String getEailid() {
        return eailid;
    }

    public void setEailid(String eailid) {
        this.eailid = eailid;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCeoName() {
        return companyCeoName;
    }

    public void setCompanyCeoName(String companyCeoName) {
        this.companyCeoName = companyCeoName;
    }

    public String getCompanyBusinessNumber() {
        return companyBusinessNumber;
    }

    public void setCompanyBusinessNumber(String companyBusinessNumber) {
        this.companyBusinessNumber = companyBusinessNumber;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String getCompanyBusiness() {
        return companyBusiness;
    }

    public void setCompanyBusiness(String companyBusiness) {
        this.companyBusiness = companyBusiness;
    }

    public String getPhoneNumver() {
        return phoneNumver;
    }

    public void setPhoneNumver(String phoneNumver) {
        this.phoneNumver = phoneNumver;
    }

    public String getCompanyPhoneNumber() {
        return companyPhoneNumber;
    }

    public void setCompanyPhoneNumber(String companyPhoneNumber) {
        this.companyPhoneNumber = companyPhoneNumber;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getProfile_img() {
        return profile_img;
    }

    public void setProfile_img(String profile_img) {
        this.profile_img = profile_img;
    }
}
