package UserInfo;

/**
 * Created by KyoungSik on 2017-04-09.
 * 개인 유저정보를 가지는 클래스
 */
public class PrivateUserInfo {
    private String emailid;//이메일 아이디
    private String pw;//비밀번호
    private String name;//유저이름
    private String phone_number;//유저 휴대폰 번호
    private String profile_img;
    private String user_type;

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfile_img() {
        return profile_img;
    }

    public void setProfile_img(String profile_img) {
        this.profile_img = profile_img;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }
}
