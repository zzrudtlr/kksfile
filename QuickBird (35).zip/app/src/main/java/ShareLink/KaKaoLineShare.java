package ShareLink;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import com.kakao.kakaolink.KakaoLink;
import com.kakao.kakaolink.KakaoTalkLinkMessageBuilder;
import com.kakao.util.KakaoParameterException;

import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-04-03.
 * 카카오톡 연동
 */
public class KaKaoLineShare {

    //카카오톡 공유하기
    public void shareKakao(Activity act){
        try {
            final KakaoLink kakaoLink = KakaoLink.getKakaoLink(act);
            final KakaoTalkLinkMessageBuilder kakaoBuilder = kakaoLink.createKakaoTalkLinkMessageBuilder();

            /*메시지 추가*/
            kakaoBuilder.addText("퀵버드");

            /*이미지 가로/세로 사이즈는 80px 보다 커야하며, 이미지 용량은 500kb 이하로 제한된다.*/
            String url = Conn_Address.SERVER_ADDRESS  + "images/img_share.png";
            kakaoBuilder.addImage(url, 1080, 1920);

            /*앱 실행버튼 추가*/
            kakaoBuilder.addAppButton("퀵버드 실행");

            /*메시지 발송*/
            kakaoLink.sendMessage(kakaoBuilder, act);
        } catch (KakaoParameterException e){
            e.printStackTrace();
        }
    }

    public void shareLine(Activity act)
    {
        try {
            String text = "line://msg/text/" + "www.naver.com";
            text = text.replaceAll("\n", "");
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(text));
            act.startActivity(intent);
        }catch (ActivityNotFoundException e)
        {
            //앱 미설치 시
            Toast.makeText(act, "라인이 설치되지 않았습니다.", Toast.LENGTH_SHORT).show();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
