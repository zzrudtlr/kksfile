package Gps;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.quickbird.quickbird.QB_MainActivity;
import com.quickbird.quickbird.SelectAddressActivity;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import Database.DB_SingleTon;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import connection.Conn_Address;
import connection.JsonParse;

/**
 * Created by KyoungSik on 2017-04-17.
 * 배송자 위치 업데이트
 */
public class GpsUpdate {

    private final String TAG="GpsUpdate";

    private final int updateTime = 30000;//배송자 위치업데이트 시간

    private GpsInfo gps;//gps 위치 정보

    private Activity act;
   // private Timer timer;
    public GpsUpdate(Activity act){
        this.act = act;
      //  startGps();
    }

    public void startGps(){
       // gps = new GpsInfo(act);
        TimerTask adTast = new TimerTask() {
            public void run() {
                Log.e("adTast ", "timer");
                // GPS 사용유무 가져오기
                if(DB_SingleTon.getInstance(act).getUserInfoTable().getDelivery_idx().matches("0")){
                    Log.d(TAG,"선택된 배송자 없음");
                }else{
                   handler.sendEmptyMessage(0);//배송자 위치 업데이트

                }

            }
        };
        Timer timer = new Timer();
//timer.schedule(adTast , 5000);  // 5초후 실행하고 종료
        timer.schedule(adTast, 0, updateTime); // 0초후 첫실행, 30초마다 계속실행
    }

    /* 배송자 위치 업데이트 주소 값
    *
    * */
    private String getUrlStr(String lat,String lng){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.UPDATE_DELIVERYLOCATION;
        urlStr = urlStr + "?lat=" + lat;
        urlStr = urlStr + "&lng=" + lng;
        urlStr = urlStr + "&address=";
        urlStr = urlStr + "&delivery_idx="+ DB_SingleTon.getInstance(act).getUserInfoTable().getDelivery_idx();
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }

    private void updateDeliveryLocation(String lat,String lng){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);

                if (flag.matches("1")) {

                    Log.d(TAG, "배송자 위치 업데이트 : " + message);
                } else {

                }

            }
        };
        jsonParse.getJsonParse(getUrlStr(lat,lng));
    }
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {//배송자 위치 업데이트
                gps = new GpsInfo(act);
                new GetData().execute();
            }
        }
    };
    public class GetData extends AsyncTask<Boolean,Boolean,Boolean> {

        private boolean toastState = false;

        private String lat="0";
        private String lng= "0";

        //post방식
        public GetData(String urlStr){


        }

        //get방식
        public GetData(){


        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected Boolean doInBackground(Boolean... params) {

            //  return rc.node_Value;
            if (gps.isGetLocation()) {
                double latitude = gps.getLatitude();
                double longitude = gps.getLongitude();

                //lat = String.format("%.4f",latitude);
               // lng = String.format("%.4f",longitude);
                lat = ""+latitude;
                lng = ""+longitude;
                Log.d(TAG,"lat : " + latitude + " lng : " + longitude);
                toastState = true;
            } else {
                // GPS 를 사용할수 없으므로
               // gps.showSettingsAlert();
                toastState = false;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Boolean result){
            super.onPostExecute(result);
            //     if(networkcheck) {//네트워크가 가능할떄
            if(toastState){
                /*Toast.makeText(
                        act,
                        "당신의 위치 - \n위도: " + lat + "\n경도: " + lng,
                        Toast.LENGTH_SHORT).show();*/
                Log.d(TAG,"위도 : " + lat + " 경도 : " + lng);
                updateDeliveryLocation(lat,lng);
            }else{
                Log.d(TAG,"gps 사용중아님");
            }
            // }
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onProgressUpdate(Boolean... values) {
            super.onProgressUpdate(values);
        }
    }
}
