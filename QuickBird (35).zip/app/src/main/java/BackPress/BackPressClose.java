package BackPress;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by KimKyougSik
 * 기기 뒤로가기 했을때 처리되는 이벤트
 */
public class BackPressClose {
    private long backKeyPressedTime = 0;
    private Toast toast;
    private Activity act;
    public BackPressClose(Activity act){
        toast = new Toast(act);
        this.act = act;
    }
    /*
    * 앱 종료 함수
    * */
    public void CloseOnBackPressed() {

            if (System.currentTimeMillis() > backKeyPressedTime + 2000) {
                backKeyPressedTime = System.currentTimeMillis();
                showGuide();
                return;
            }
            if (System.currentTimeMillis() <= backKeyPressedTime + 2000) {
                act.finish();
                toast.cancel();
            }

    }
    /*
    * 메인 액티비티로 넘어가는 함수
    * */
    public void BackActivity(Activity act1,Class act2){
        Intent next = new Intent(act1,act2);
        act1.startActivity(next);
        act1.finish();
    }

    /*
    * 종료하기 전에 띄우는 Handler
    * */
    public void showGuide() {
        toast = Toast.makeText(act, "\'뒤로\'버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
       toast.show();
    }

}
