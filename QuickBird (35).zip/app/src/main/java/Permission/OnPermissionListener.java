package Permission;

/**
 * Created by KyoungSik on 2017-04-02.
 */
public interface OnPermissionListener {
    public void onSuccess(int perState);
}
