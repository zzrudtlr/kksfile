package Permission;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

import Picture.MultiplePicture.Action;

/**
 * Created by KyoungSik on 2017-04-02.
 * 기기 접근 허용
 */
public class DevicePermission {

    private final String TAG = "DevicePermission";

    private OnPermissionListener onPermissionListener;

    private final int APP_PERMISSION_STORAGE = 0;

    public DevicePermission(){

    }

    /**
     * 퍼미션 체크
     */
    public boolean checkPermission(Activity act){
        boolean check = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG, "마시멜로우 버전");

            //권한이 없는 경우
            if (act.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    || act.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                //최초 거부를 선택하면 두번째부터 이벤트 발생 & 권한 획득이 필요한 이융를 설명
                if (act.shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(act, "shouldShowRequestPermissionRationale", Toast.LENGTH_SHORT).show();
                }

                //요청 팝업 팝업 선택시 onRequestPermissionsResult 이동
                act.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE}, APP_PERMISSION_STORAGE);
                check = false;

            }
            //권한이 있는 경우
            else {

            }
            return check;
        }
        return check;
    }
    /* 전화걸기 권한
    *
    * */
    public void checkPermissionCall(Activity act,String phoneNumber){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG,"마시멜로우 버전");
            int permissionResult = act.checkSelfPermission(Manifest.permission.CALL_PHONE);

            if (permissionResult == PackageManager.PERMISSION_DENIED) {
                Log.d(TAG,"권한 요청");
                if (act.shouldShowRequestPermissionRationale(Manifest.permission.CALL_PHONE)) {
                    Log.d(TAG,"권한 1");
                    act.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1000);
                }else{
                    Log.d(TAG,"권한 2");
                    act.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1000);

                }
            }else{
                // 즉시 실행
                Log.d(TAG,"권한 있음");
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+phoneNumber));
                act.startActivity(intent);
            }
        }else{
            Log.d(TAG,"마시멜로우 이하 버전");
            Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+phoneNumber));
            act.startActivity(intent);
        }
    }

    /* GPS 권한
    *
    * */
    public void checkPermissionGps(Activity act){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG,"마시멜로우 버전");
            int permissionResult = act.checkSelfPermission(Manifest.permission.CALL_PHONE);

            if (permissionResult == PackageManager.PERMISSION_DENIED) {
                Log.d(TAG,"권한 요청");
                if (act.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    Log.d(TAG,"권한 1");
                    act.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
                }else{
                    Log.d(TAG,"권한 2");
                    act.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);

                }
            }else{
                // 즉시 실행
                Log.d(TAG, "권한 있음");

            }
        }else {
            Log.d(TAG, "마시멜로우 이하 버전");

        }
    }

    public boolean checkPerGps(Activity act){
        boolean check = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.d(TAG,"마시멜로우 버전");
            int permissionResult = act.checkSelfPermission(Manifest.permission.CALL_PHONE);

            if (permissionResult == PackageManager.PERMISSION_DENIED) {
                Log.d(TAG,"권한 요청");
                if (act.shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    Log.d(TAG,"권한 1");
                    act.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
                }else{
                    Log.d(TAG,"권한 2");
                    act.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1000);

                }
                check = false;
            }else{
                // 즉시 실행
                Log.d(TAG, "권한 있음");
                check = true;
            }
            int permissionResult2 = act.checkSelfPermission(Manifest.permission.CALL_PHONE);
            if (permissionResult2 != PackageManager.PERMISSION_DENIED) {
                check = true;
            }

        }else {
            Log.d(TAG, "마시멜로우 이하 버전");

        }
        return check;
    }

    public OnPermissionListener getOnPermissionListener() {
        return onPermissionListener;
    }

    public void setOnPermissionListener(OnPermissionListener onPermissionListener) {
        this.onPermissionListener = onPermissionListener;
    }
}
