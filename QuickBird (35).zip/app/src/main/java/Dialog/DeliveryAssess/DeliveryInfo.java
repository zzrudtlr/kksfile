package Dialog.DeliveryAssess;

/**
 * Created by KyoungSik on 2017-04-27.
 */
public class DeliveryInfo {

    private String delivery_name="";
    private String delivery_img="";
    private String delivery_memo = "";
    private String delivery_phone = "";

    public String getDelivery_name() {
        return delivery_name;
    }

    public void setDelivery_name(String delivery_name) {
        this.delivery_name = delivery_name;
    }

    public String getDelivery_img() {
        return delivery_img;
    }

    public void setDelivery_img(String delivery_img) {
        this.delivery_img = delivery_img;
    }

    public String getDelivery_memo() {
        return delivery_memo;
    }

    public void setDelivery_memo(String delivery_memo) {
        this.delivery_memo = delivery_memo;
    }

    public String getDelivery_phone() {
        return delivery_phone;
    }

    public void setDelivery_phone(String delivery_phone) {
        this.delivery_phone = delivery_phone;
    }
}
