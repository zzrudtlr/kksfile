package Dialog.DeliveryAssess;

/**
 * Created by KyoungSik on 2017-04-24.
 */
public class DeliveryAssessInfo {
    private String score="";
    private String memo="";

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }
}
