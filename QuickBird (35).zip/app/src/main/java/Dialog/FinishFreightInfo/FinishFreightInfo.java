package Dialog.FinishFreightInfo;

/**
 * Created by KyoungSik on 2017-04-24.
 */
public class FinishFreightInfo {

    private String freight_image;
    private String freight_memo;
    private boolean info_check = false;

    public String getFreight_image() {
        return freight_image;
    }

    public void setFreight_image(String freight_image) {
        this.freight_image = freight_image;
    }

    public String getFreight_memo() {
        return freight_memo;
    }

    public void setFreight_memo(String freight_memo) {
        this.freight_memo = freight_memo;
    }

    public boolean isInfo_check() {
        return info_check;
    }

    public void setInfo_check(boolean info_check) {
        this.info_check = info_check;
    }
}
