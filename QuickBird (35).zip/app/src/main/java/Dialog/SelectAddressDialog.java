package Dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;

import com.quickbird.quickbird.R;

import Gps.GpsInfo;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-04-03.
 * 지도 주소 선택 다이얼로그
 */
public abstract class SelectAddressDialog extends Dialog {

    private final String TAG = "SelectAddressDialog";

    public abstract void onClickSelect(String lat,String lng,String address);
    public abstract void onClickCancel();

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;

    private String lat;//위도
    private String lng;//경도

    private double my_lat;
    private double my_lng;

    private GpsInfo gps;//gps 위치 정보
    private String address;//주소

    private Activity act;

    public SelectAddressDialog(Context context) {
        super(context);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setCanceledOnTouchOutside(false);
        setContentView(R.layout.dialog_map_address);

        this.act = (Activity)context;
        init();
    }

    private void init(){
        loading = new Loading(act);
        errorView = (LinearLayout)findViewById(R.id.fr_errorview);
        gps = new GpsInfo(act);
        if (gps.isGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();

            //lat = String.format("%.4f",latitude);
            // lng = String.format("%.4f",longitude);
            my_lat = latitude;
            my_lng = longitude;
            Log.d(TAG,"lat : " + my_lat + " lng : " + my_lng);
        } else {
            // GPS 를 사용할수 없으므로
            // gps.showSettingsAlert();
        }
        webViewinit();
        eventButton();

    }

    /* 주소 선택 지도 웹 뷰
     *
     * */
    private void webViewinit(){

        webViewClass = new WebViewClass((WebView)findViewById(R.id.mawebview),act,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });


        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void map(String lat,String lng, String address) {
                Log.d(TAG, "map lat : " + lat + " lng : " + lng + " address : "+ address);
                setLat(lat);
                setLng(lng);
                setAddress(address);

            }

        }, "quickbird");
    }

    private void eventButton(){
        //웹뷰 재시도 버튼
        Button restartbtn = (Button)findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              webViewClass.getWebView().reload();
              errorView.setVisibility(View.GONE);
            }
        });

        //확인 버튼
        Button selectbtn = (Button)findViewById(R.id.maconfirmbtn);
        selectbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickSelect(lat,lng,address);
                dismiss();
            }
        });

        //취소 버튼
        Button cancelbtn = (Button)findViewById(R.id.macancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickCancel();
                dismiss();
            }
        });
    }

    /* 지도 주소 받아오기 url
    *
    * */
    private String getUrlStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.ADDRESS_MAP;
        if(my_lat == 0){
            webUrlStr = webUrlStr + "?lat=";
        }else{
            webUrlStr = webUrlStr + "?lat="+ my_lat;
        }

        if(my_lng == 0){
            webUrlStr = webUrlStr + "&lng=";
        }else{
            webUrlStr = webUrlStr + "&lng=" + my_lng;
        }
        Log.d(TAG,"webUrlStr : " + webUrlStr);
        return webUrlStr;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
