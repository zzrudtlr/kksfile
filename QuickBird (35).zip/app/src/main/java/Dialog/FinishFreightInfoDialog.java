package Dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.quickbird.quickbird.R;

import Dialog.FinishFreightInfo.FinishFreightInfo;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-04-12.
 * 화물 배송완료 정보
 */
public abstract class FinishFreightInfoDialog extends Dialog {

    private final String TAG = "FinishFreightInfoDialog";

    public abstract void onClickSelect(FinishFreightInfoDialog finishFreightInfoDialog);
    public abstract void onClickCamera(ImageView imageView);

    private ImageView freightImage;//화물 이미지
    private EditText memoEdit;//메모
    private Bitmap freightBitmap;

    private FinishFreightInfo finishFreightInfo;

    public FinishFreightInfoDialog(Context context) {
        super(context);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setCanceledOnTouchOutside(false);
        setContentView(R.layout.dialog_deliveryfinishinfo);
        init();
    }

    private void init(){
        freightImage = (ImageView)findViewById(R.id.dfiimageview);
        memoEdit = (EditText)findViewById(R.id.dfimemoEdit);
        buttonEvent();
    }


    /* 버튼이벤트
      *
      * */
    private void buttonEvent(){
        //X버튼
       /* ImageView exitbtn = (ImageView)findViewById(R.id.difexit);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });*/

        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.dficancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        //완료버튼
        Button registerbtn = (Button)findViewById(R.id.dfiselectbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickSelect(getFinishFreightInfoDialog());
                dismiss();
            }
        });

        //이미지 클릭
        freightImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickCamera(getFreightImage());
            }
        });
    }

    public void setFreightImageView(Bitmap bitmap){
        freightBitmap = bitmap;
        new GetData().execute();
    }

    public ImageView getFreightImage() {
        return freightImage;
    }

    public EditText getMemoEdit() {
        return memoEdit;
    }

    public void setFinishFreightInfo(FinishFreightInfo finishFreightInfo) {
        this.finishFreightInfo = finishFreightInfo;
    }

    private FinishFreightInfoDialog getFinishFreightInfoDialog(){
        return this;
    }
    public class GetData extends AsyncTask<String,String,String> {

        public GetData(){
        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected String doInBackground(String... params) {
            return null;
        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
            freightImage.setImageBitmap(freightBitmap);

        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }
}
