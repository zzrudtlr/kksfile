package Dialog.SelectList;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.quickbird.quickbird.R;

/**
 * Created by KyoungSik on 2017-03-11.
 * SelectListDialog 리스트뷰 adapter
 */
public class SelectListAdapter extends ArrayAdapter{

    private final String TAG = "SelectListAdapter";

    private int resource;
    private Activity act;
    private LayoutInflater mInflater;
    private String[] listtitle;
    private View[] view;
    private String[] subtitle;

    public SelectListAdapter(Context context, int resource) {
        super(context, resource);
    }

    public SelectListAdapter(Context context, int resource, String[] listtitle){
        super(context, resource);
        this.resource = resource;
        this.act = (Activity)context;
        mInflater = (LayoutInflater)act.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.listtitle = listtitle;
        view = new View[listtitle.length];
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public int getCount(){
        return listtitle.length;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(view[position] == null) {
            View view = mInflater.inflate(resource, null);
            TextView titleText = (TextView)view.findViewById(R.id.listtitle_cell);
            titleText.setText(listtitle[position]);
            if(subtitle != null) {
                TextView subTitleText = (TextView) view.findViewById(R.id.listtilte_sub);
                subTitleText.setText(" " + subtitle[position]);
            }
            this.view[position] = view;
         }
       // convertView.setLayoutParams(layoutParams);
        return view[position];
    }

    public void setSubtitle(String[] subtitle) {
        this.subtitle = subtitle;
    }
}
