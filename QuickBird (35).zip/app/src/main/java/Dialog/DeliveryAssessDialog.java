package Dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.quickbird.quickbird.R;

import Dialog.DeliveryAssess.DeliveryAssessInfo;
import Dialog.DeliveryAssess.DeliveryInfo;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-03-20.
 * 배송자 평가하기
 */
public abstract class DeliveryAssessDialog extends Dialog {

    private final String TAG = "DeliveryAssessDialog";

    public abstract void onClickSelect(DeliveryAssessInfo deliveryAssessInfo, DeliveryAssessDialog deliveryAssessDialog);

    private TextView scoreText;
    private RatingBar ratingBar;
    private EditText memoEdit;
    private ImageView profileImageView;
    private TextView nameText;

    private DeliveryAssessInfo deliveryAssessInfo;

    private Activity act;

    public DeliveryAssessDialog(Context context) {
        super(context);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setCanceledOnTouchOutside(false);
        setContentView(R.layout.dialog_delivery_assessment);
        this.act = (Activity)context;
        init();
    }

    /* 초기화
    *
    * */
    private void init(){
        deliveryAssessInfo = new DeliveryAssessInfo();
        buttonEvent();
        ratingBarinit();
    }

    private void ratingBarinit(){
        ratingBar = (RatingBar)findViewById(R.id.daratingbar);
        scoreText = (TextView)findViewById(R.id.dascoreText);
        memoEdit = (EditText)findViewById(R.id.darmeonEdit);
        profileImageView = (ImageView)findViewById(R.id.daprofileimageView);
        nameText = (TextView)findViewById(R.id.danameText);

        Drawable progress = ratingBar.getProgressDrawable();
        DrawableCompat.setTint(progress, Color.rgb(254, 159, 101));
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                scoreText.setText("" + rating);
                deliveryAssessInfo.setScore("" + rating);
            }
        });
    }

    /* 버튼이벤트
    *
    * */
    private void buttonEvent(){

        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.dacancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        //평가 등록하기
        Button selectbtn = (Button)findViewById(R.id.daselectbtn);
        selectbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(exception()) {
                    deliveryAssessInfo.setMemo(memoEdit.getText().toString());
                    onClickSelect(deliveryAssessInfo, getDeliveryAssessDialog());
                }
            }
        });
    }
    /* 예외처리
    *
    */
    private boolean exception(){
        boolean check = true;
       /* if(memoEdit.getText().toString().matches("")){
            check = false;
            Toast.makeText(act,"후기를 남겨주세요.",Toast.LENGTH_SHORT).show();
        }else*/ if(scoreText.getText().toString().matches("0.0")){
            check = false;
            Toast.makeText(act,"별을 눌러 평가 해주세요.",Toast.LENGTH_SHORT).show();
        }
        return check;
    }

    public TextView getNameText() {
        return nameText;
    }

    public void setNameText(TextView nameText) {
        this.nameText = nameText;
    }

    public ImageView getProfileImageView() {
        return profileImageView;
    }

    private DeliveryAssessDialog getDeliveryAssessDialog(){
        return this;
    }
}
