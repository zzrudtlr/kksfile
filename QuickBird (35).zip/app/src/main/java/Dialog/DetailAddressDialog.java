package Dialog;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.quickbird.quickbird.R;

/**
 * Created by KyoungSik on 2017-07-04.
 * 주소 세부사항 다이얼로그
 */
public abstract class DetailAddressDialog extends Dialog {

    private final String TAG = "FindPwDialog";

    public abstract void onClickConfirm(String detailInfo, DetailAddressDialog detailAddressDialog);
    public abstract void onClickCancel();

    private EditText emailidText;
    private ImageView emailidicon;

    public DetailAddressDialog(Context context) {
        super(context);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setCanceledOnTouchOutside(false);
        setContentView(R.layout.dialog_findpw);
        init();
    }
    private void init(){
        emailidText = (EditText)findViewById(R.id.dfemailidText);
        emailidicon = (ImageView)findViewById(R.id.dfemaliidimage);
        emailidText.setHint("상세정보 ex)퀵버드 건물 609호");
        buttonEvent();
        editTextEvent();
    }

    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
    *
    * */
    private void editTextEvent(){
        emailidText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    emailidicon.setImageResource(R.drawable.icon_map_on);
                } else {
                    emailidicon.setImageResource(R.drawable.icon_map_off);
                }
            }
        });
    }

    //버튼이벤트
    private void buttonEvent(){
        //전송 버튼
        Button confirmbtn = (Button)findViewById(R.id.dfconfirmbtn);
        confirmbtn.setText("확인");
        confirmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "확인");
                onClickConfirm(emailidText.getText().toString(),getDetailAddressDialog());
            }
        });

        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.dfcancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "취소");
                onClickCancel();
                dismiss();
            }
        });
    }

    private DetailAddressDialog getDetailAddressDialog(){
        return this;
    }
}
