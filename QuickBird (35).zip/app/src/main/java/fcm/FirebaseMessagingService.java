package fcm;

/**
 * Created by KyoungSik on 2016-10-11.
 */
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.google.firebase.messaging.RemoteMessage;
import com.quickbird.quickbird.DeliveryInfoDetailActivity;
import com.quickbird.quickbird.DrequestFreightActivity;
import com.quickbird.quickbird.FreightInfoDetailActivity;
import com.quickbird.quickbird.FrequestDeliveryActivity;
import com.quickbird.quickbird.IntroActivity;
import com.quickbird.quickbird.MyRegisteredFreightActivity;
import com.quickbird.quickbird.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import Database.DB_SingleTon;


public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {
    private static final String TAG = "FirebaseMsgService";

    // [START receive_message]
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "onMessageReceived : " + remoteMessage.getData().get("message"));
        if(DB_SingleTon.getInstance(this).getUserInfoTable().getPushOnOff().matches("1")) {
            sendPushNotification(remoteMessage.getData().get("message"));

            Log.d(TAG, "message : " + remoteMessage.getData().get("message"));
            Log.d(TAG, "message : " + remoteMessage.getData().get("message1"));
            Log.d(TAG, "message : " + remoteMessage.getData().get("message2"));
        }


    }

    private void sendPushNotification(String message) {

        System.out.println("received message : " + message);
        String push_message = "";
        String push_value = "";
        try {
            JSONObject jsonObject = new JSONObject(message);
            push_message = (String) jsonObject.get("message");
            push_value = (String)jsonObject.get("values");
        } catch (JSONException e) {
            e.printStackTrace();
            push_message="";
            push_value="";
        }

        Intent intent = setPushIntent(push_value);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.pabicon).setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.pabicon) )
                .setContentTitle("퀵버드 ")
                .setContentText(push_message)
                .setAutoCancel(true)
                .setSound(defaultSoundUri).setLights(000000255,500,2000)
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakelock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "TAG");
        wakelock.acquire(5000);

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }


    public Intent setPushIntent(String value){
        Intent intent = null;
        if(!value.matches("")) {
            getCurrentActivity();
            try {
                JSONObject jsonObject = new JSONObject(value);
                Log.d(TAG,"jsonObject : " + jsonObject.toString());

                String page = jsonObject.getString("page");
                Log.d(TAG,"page : " + page);
                switch(page){
                    case "1"://배송완료
                        intent = new Intent(this, MyRegisteredFreightActivity.class);//내가등록한 화물
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity", getCurrentActivity().getPackageName());
                        Log.d(TAG, "배송완료");
                        break;
                    case"2"://화물이 배송자에게 배송희망을 신청
                        intent = new Intent(this, DrequestFreightActivity.class);//배송을 요청한 화물
                        intent.putExtra("delivery_idx", "" + jsonObject.getString("delivery_idx"));
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                        Log.d(TAG, "화물이 배송자에게 배송희망을 신청");
                        break;
                    case "3"://배송자가 화물에게 배송희망을 신청
                        intent = new Intent(this,FrequestDeliveryActivity.class);//화물이 배송자에게 배송희망을 신청
                        intent.putExtra("freight_idx", "" + jsonObject.getString("freight_idx"));
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity", getCurrentActivity().getPackageName());
                        Log.d(TAG, "배송자가 화물에게 배송희망을 신청");
                        break;
                    case"4"://배송자 지정
                        intent = new Intent(this, DrequestFreightActivity.class);
                        intent.putExtra("delivery_idx", "" + jsonObject.getString("delivery_idx"));
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                        Log.d(TAG, "배송을 요청한 화물");
                        break;
                    case"5"://화물 지정
                        intent = new Intent(this, MyRegisteredFreightActivity.class);//등록한 화물
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity", getCurrentActivity().getPackageName());
                        Log.d(TAG, "화물 지정");
                        break;
                    case"6"://화물 배송신청 취소
                        intent = new Intent(this, FreightInfoDetailActivity.class);//화물 상세정보
                        intent.putExtra("freight_idx", "" + jsonObject.getString("freight_idx"));
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                        Log.d(TAG, "화물 배송신청 취소");
                        break;
                    case"7"://화물 상세정보
                        intent = new Intent(this, FreightInfoDetailActivity.class);
                        intent.putExtra("freight_idx", "" + jsonObject.getString("freight_idx"));
                        intent.putExtra("startState", "push");
                        intent.putExtra("topActivity", getCurrentActivity().getPackageName());
                        break;
                    default:
                        intent = new Intent(this, IntroActivity.class);
                        Log.d(TAG, "화물 상세정보");      /*if (!jsonObject.isNull("delivery_idx")) {//배송자 상세정보
                            intent = new Intent(this, DeliveryInfoDetailActivity.class);
                            intent.putExtra("delivery_idx", "" + jsonObject.getString("delivery_idx"));
                            intent.putExtra("startState", "push");
                            intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                            Log.d(TAG, "배송자 상세정보");
                        } else if (!jsonObject.isNull("freight_idx")) {
                            intent = new Intent(this, FreightInfoDetailActivity.class);
                            intent.putExtra("freight_idx", "" + jsonObject.getString("freight_idx"));
                            intent.putExtra("startState", "push");
                            intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                            Log.d(TAG, "화물 상세정보");
                        }*/
                        break;
                }



            /*    if (!jsonObject.isNull("delivery_idx")) {//배송자 상세정보
                    intent = new Intent(this, DeliveryInfoDetailActivity.class);
                    intent.putExtra("delivery_idx", "" + jsonObject.getString("delivery_idx"));
                    intent.putExtra("startState", "push");
                    intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                    Log.d(TAG, "배송자 상세정보");
                } else if (!jsonObject.isNull("freight_idx")) {
                    intent = new Intent(this, FreightInfoDetailActivity.class);
                    intent.putExtra("freight_idx", "" + jsonObject.getString("freight_idx"));
                    intent.putExtra("startState", "push");
                    intent.putExtra("topActivity",getCurrentActivity().getPackageName());
                    Log.d(TAG, "화물 상세정보");
                }*/
            } catch (JSONException e) {
                e.printStackTrace();
                intent = new Intent(this, IntroActivity.class);
            }
        }else{
            intent = new Intent(this, IntroActivity.class);
        }
        return intent;
    }

    public ComponentName getCurrentActivity() {

        ActivityManager am = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

        ComponentName topActivity = taskInfo.get(0).topActivity;
        Log.d(TAG,"topActivity : " + topActivity.getClassName() + " this class : " + this.getClass().getName() );
        return topActivity ;

    }

}

