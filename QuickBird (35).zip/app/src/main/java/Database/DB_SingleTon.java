package Database;

import android.content.Context;

/**
 * Created by KyoungSik on 2017-03-28.
 * UserInfoTable Database SingleTon
 */
public class DB_SingleTon {

    private static DB_SingleTon single;
    private DbOpenHelper mDbOpenHelper;
    private UserInfoTable userInfoTable;//DB


    private DB_SingleTon(Context act){
        //TODO 디비
        mDbOpenHelper = new DbOpenHelper(act);
        userInfoTable = new UserInfoTable();

        try {
            mDbOpenHelper.open(userInfoTable.CREATE_INTRO);

        } catch (android.database.SQLException e) {
            e.printStackTrace();
        }
    }

    public UserInfoTable getUserInfoTable() {
        return userInfoTable;
    }

    public static DB_SingleTon getInstance(Context act){
        if(single==null){
            single = new DB_SingleTon(act);
        }
        return single;
    }
}
