package Database;

import android.content.ContentValues;
import android.database.Cursor;
import android.provider.BaseColumns;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by KyoungSik on 2017-03-28.
 * 유저정보를 관리하는 테이블
 */
public class UserInfoTable implements BaseColumns{
    public final String TAG = "UserInfoTable";
    public final String TABLE_NAME ="user_info";
    public final String USER_IDX = "user_idx";
    public final String DELIVERY_IDX = "delivery_idx";
    public final String USER_ID = "user_id";
    public final String USER_PW = "user_pw";
    public final String PROFILE_IMG = "profile_img";
    public final String USER_TYPE = "user_type";
    public final String LOGINAUTO_STATE="loginauto_state";//자동로그인 체크 0:자동로그인 아님 1일때 자동로그인
    public final String PUSH_ONOFF = "push_state";//푸시 알람 설정
    public final String CREATE_INTRO =
            "create table "+ TABLE_NAME +"("
                    +_ID+" integer primary key autoincrement, "
                    +USER_IDX+" text not null, "
                    +DELIVERY_IDX+" text, "
                    +PROFILE_IMG+" text, "
                    +USER_ID+" text, "
                    +USER_PW+" text, "
                    +USER_TYPE+" text not null, "
                    +PUSH_ONOFF+" text not null, "
                    +LOGINAUTO_STATE+" text not null);";

    //TODO 데이터 삽입
   /*public void insertColumn(String user_idx,String user_type,String loginauto_state,String profile_img) {
        ContentValues values = new ContentValues();
        values.put(USER_IDX, user_idx);
        values.put(DELIVERY_IDX, "0");
        values.put(USER_TYPE, user_type);
        values.put(PROFILE_IMG, profile_img);
        values.put(PUSH_ONOFF, "1");
        values.put(LOGINAUTO_STATE, loginauto_state);
        DbOpenHelper.m_db.insert(TABLE_NAME, null, values);
    }*/
    //TODO 데이터 삽입
    public void insertColumn(UserInfo userinfo) {
        ContentValues values = new ContentValues();
        values.put(USER_IDX, userinfo.user_idx);
        values.put(DELIVERY_IDX, userinfo.user_delivery_idx);
        values.put(USER_TYPE, userinfo.user_type);
        values.put(PROFILE_IMG, userinfo.profile_img);
        values.put(USER_ID, userinfo.user_id);
        values.put(USER_PW, userinfo.user_pw);
        values.put(PUSH_ONOFF, userinfo.user_pushonoff);
        values.put(LOGINAUTO_STATE, userinfo.loginauto_state);
        DbOpenHelper.m_db.insert(TABLE_NAME, null, values);
    }
    //TODO 데이터 유무 체크
    public boolean getCheck(){
        boolean flag = false;//값이 없으면 false
        Cursor c = DbOpenHelper.m_db.query(TABLE_NAME, null, null, null, null, null, null);
        if (c.getCount()>0){
            Log.d(TAG, "getCount : " + c.getCount());
            flag=true;
        }
        return flag;
    }

    /* 개인 및 사업자 구분
    *
    * */
    public String getLoginState(){
        String loginstate = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + LOGINAUTO_STATE + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                loginstate = c.getString(0);
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return loginstate;
    }

    /* 개인 및 사업자 구분
    *
    * */
    public String getUserIdx(){
        String user_idx = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + USER_IDX + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                user_idx = c.getString(0);
            }
        }else{

            Log.d(TAG,"cursor null");
        }
        c.close();
        return user_idx;
    }

    /* 회원 타입
    *
    * */
    public String getUserTyp(){
        String userType = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + USER_TYPE + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                userType = c.getString(0);
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return userType;
    }

    /* 회원 프로필 이미지
    *
    * */
    public String getProfileImage(){
        String profile_img = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + PROFILE_IMG + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                profile_img = c.getString(0);
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return profile_img;
    }

    /* 배송자 idx
    *
    * */
    public String getDelivery_idx(){
        String delivery_idx = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + DELIVERY_IDX + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                delivery_idx = c.getString(0);
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return delivery_idx;
    }

    /* 배송자 idx
*
* */
    public String getPushOnOff(){
        String push_onoff = "";
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + PUSH_ONOFF + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                push_onoff = c.getString(0);
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return push_onoff;
    }



    //TODO 데이터 조회
    public void selectColumn(){
        Cursor c = DbOpenHelper.m_db.query(TABLE_NAME, null, null, null, null, null, null);
        if (c.getCount() > 0) {
            while (c.moveToNext()) {
                Log.d(TAG, c.getString(c.getColumnIndex(_ID)));
                Log.d(TAG, c.getString(c.getColumnIndex(USER_IDX)));
                Log.d(TAG, c.getString(c.getColumnIndex(DELIVERY_IDX)));
                Log.d(TAG, c.getString(c.getColumnIndex(USER_TYPE)));
                Log.d(TAG, c.getString(c.getColumnIndex(LOGINAUTO_STATE)));
            }
        }
        c.close();
    }

    //TODO 데이터 중복 체크
    public Boolean overLapCheck(String user_idx){
        boolean check = true;
        // Cursor c = DbOpenHelper.m_db.query(TABLE_NAME, new String[]{NAME}, "name=?category=?", new String[]{category, name}, null, null, null);
        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT user_idx FROM "+TABLE_NAME+" WHERE "+USER_IDX+"='"+user_idx+"'", null);
        if (c.getCount() > 0) {
            check = false;
            Log.d(TAG, "중복");
        } else {
            Log.d(TAG, "중복아님");
        }
        return check;
    }


    //TODO 로그인 IDX 값 조회
    public ArrayList<String> userList(){

        ArrayList<String> user_idx = new ArrayList<String>();

        Cursor c = DbOpenHelper.m_db.query(TABLE_NAME, null, null, null, null, null, null);
        while (c.moveToNext()) {
            user_idx.add(c.getString(c.getColumnIndex(_ID)));//0
            user_idx.add(c.getString(c.getColumnIndex(USER_IDX)));//1
            user_idx.add(c.getString(c.getColumnIndex(DELIVERY_IDX)));//4
            user_idx.add(c.getString(c.getColumnIndex(LOGINAUTO_STATE)));//6
        }
        c.close();
        return user_idx;
    }
    //TODO 유저 아이디 비밀번호 값 조회
    public ArrayList<String> useridpw(){

        ArrayList<String> user_info = new ArrayList<String>();

        Cursor c = DbOpenHelper.m_db.rawQuery("SELECT " + USER_ID + "," + USER_PW + " FROM " + TABLE_NAME, null);
        if(c != null && c.getCount()>0) {
            while (c.moveToNext()) {
                user_info.add(c.getString(0));
                user_info.add(c.getString(1));
            }
        }else{
            Log.d(TAG,"cursor null");
        }
        c.close();
        return user_info;
    }

    /* 프로필 이미지 업데이트
   *
   * */
    public void updateProfileImage(String profile_img){
        DbOpenHelper.m_db.execSQL("UPDATE " + TABLE_NAME + " SET " + PROFILE_IMG + " = '" + profile_img + "';");
    }

    /* 배송자 idx 업데이트
    *
    * */
    public void updateDeliveryIdx(String delivery_idx){
        DbOpenHelper.m_db.execSQL("UPDATE " + TABLE_NAME + " SET " + DELIVERY_IDX + " = '" + delivery_idx + "';");
    }

    /* 자동 로그인 업데이트
    *
    * */
    public void updateAutoLogin(String flag){
        DbOpenHelper.m_db.execSQL("UPDATE " + TABLE_NAME + " SET " + LOGINAUTO_STATE + " = '" + flag + "';");
    }

    /* 자동 푸시 설정 업데이트
  *
  * */
    public void updatePushOnOff(String flag){
        DbOpenHelper.m_db.execSQL("UPDATE " + TABLE_NAME + " SET " + PUSH_ONOFF + " = '" + flag + "';");
    }
    //TODO 데이터 조건 삭제
    public void deleteAllColumns(String idx){
        DbOpenHelper.m_db.execSQL("delete from " + TABLE_NAME + " where " + _ID + "=" + idx);
    }

    //TODO 데이터 삭제 로그아웃
    public void deleteAllColumns(){
        DbOpenHelper.m_db.execSQL("delete from " + TABLE_NAME);
    }

    public void dropTable(){
        DbOpenHelper.m_db.execSQL("drop table " + TABLE_NAME);
    }
}
