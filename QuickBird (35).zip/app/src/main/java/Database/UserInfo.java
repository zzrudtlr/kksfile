package Database;

/**
 * Created by KyoungSik on 2017-08-21.
 */
public class UserInfo {

    public String user_idx="";
    public String user_type="";
    public String loginauto_state="";
    public String profile_img="";
    public String user_id="";
    public String user_pw="";
    public String user_delivery_idx="0";
    public String user_pushonoff="1";
}
