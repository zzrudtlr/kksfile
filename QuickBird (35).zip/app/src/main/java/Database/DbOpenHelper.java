package Database;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by KyoungSik on 2017-03-28.
 */
public class DbOpenHelper {

    private static final String DATABASE_NAME ="user_infoss.db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase m_db;
    private DatabaseHelper mDBHelper;
    private Context mCtx;

    public DbOpenHelper(Context context){
        this.mCtx = context;
    }

    public DbOpenHelper open(String create_db) throws SQLException {
        mDBHelper = new DatabaseHelper(mCtx, DATABASE_NAME, null, DATABASE_VERSION,create_db);
        m_db = mDBHelper.getWritableDatabase();
        return this;
    }

    private class DatabaseHelper extends SQLiteOpenHelper {
        String create_db;
        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, String create_db){
            super(context, name, factory, version);
            this.create_db = create_db;
        }

        //TODO 최초 DB생성 한번 호출
        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(create_db);
        }

        //TODO 버전이 업데이트 되었을 경우 DB 삭제후 재생성
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS  " + create_db);
            onCreate(db);
        }
    }

    public void onDestroy() {
        m_db.close();
    }

}
