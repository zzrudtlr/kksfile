package connection;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by KyoungSik on 2017-03-26.
 * json 파싱
 */
public abstract class JsonParse {

    private final String TAG = "JsonParse";
    private Activity act;
    abstract public void startParse();
    abstract public void behavior(String flag, String message, ArrayList<ArrayList<String>> result);//데이터를 받아온뒤 실행되는 함수


    public JsonParse(Activity act){
        this.act = act;
    }

    //get방식 Json파싱
    public void getJsonParse(String urlStr){
        boolean networkcheck = true;
        if(AppNetWrok.networkCheck(act)) {
            networkcheck = true;
        }else{
            networkcheck = false;
        }
        new GetData(urlStr,networkcheck,1).execute();
    }

    //post방식 Json파싱
    public void postJsonParse(String urlStr,String params){
        boolean networkcheck = true;
        if(AppNetWrok.networkCheck(act)) {
            networkcheck = true;
        }else{
            networkcheck = false;
        }
        new GetData(urlStr,networkcheck,params,0).execute();
    }

    //post방식 json파싱
    public ArrayList<String> postJsonData(String urlStr,String params){
        StringBuilder sb = new StringBuilder();
        HttpURLConnection urlConnection=null;
        ArrayList<String> jsonArray = new ArrayList<String>();
        Log.d(TAG, "getJsonData Start : " + urlStr);
        try {
            URL url = new URL(urlStr);
            urlConnection = (HttpURLConnection)url.openConnection();
            urlConnection.setDefaultUseCaches(false);
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");

            OutputStream os = urlConnection.getOutputStream();
            os.write(params.getBytes("UTF-8"));
            os.flush();
            os.close();

            int HttpResult =urlConnection.getResponseCode();
            if(HttpResult ==HttpURLConnection.HTTP_OK){
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream(),"utf-8"));
                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    Log.d(TAG, "readLine : " + line);
                    // arrayList.add(line );
                }
                br.close();
                //JSon형식으로 받아온 데이터를 키값 별로 저장
                String jstr = sb.toString();
                Log.d(TAG,"jstr : " + jstr.toString());
                JSONObject jsonObject = new JSONObject(jstr);
                jsonArray.add(jsonObject.getString("flag"));
                jsonArray.add(jsonObject.getString("message"));
                jsonArray.add(jsonObject.getString("key"));
                jsonArray.add(jsonObject.getString("values"));

            }else{
                System.out.println(urlConnection.getResponseMessage());
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Log.d(TAG, "MalformedURLException");
        }
        catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, "IOException");
        } catch (JSONException e) {
            e.printStackTrace();
        } finally{
            if(urlConnection!=null)
                urlConnection.disconnect();
        }
        Log.d(TAG, "getJsonData END");
        return jsonArray;
    }

    //get방식 Json파싱
    public ArrayList<String> getJsonData(String urlStr){
        StringBuilder sb = new StringBuilder();

        ArrayList<String> jsonArray = new ArrayList<String>();
        Log.d(TAG,"getJsonData Start : " + urlStr);
        HttpURLConnection urlConnection=null;
        try {
            URL url = new URL(urlStr);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("GET");
            urlConnection.setUseCaches(false);
            urlConnection.setConnectTimeout(10000);
            urlConnection.setReadTimeout(10000);
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");
            //  urlConnection.setRequestProperty("Host", "android.schoolportal.gr");
            urlConnection.connect();

            int HttpResult =urlConnection.getResponseCode();
            if(HttpResult ==HttpURLConnection.HTTP_OK){
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        urlConnection.getInputStream(),"utf-8"));
                String line = null;

                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    Log.d(TAG, line);
                    // arrayList.add(line);
                }
                br.close();
                //JSon형식으로 받아온 데이터를 키값 별로 저장
                String jstr = sb.toString();
                JSONObject jsonObject = new JSONObject(jstr);
                jsonArray.add(jsonObject.getString("flag"));
                jsonArray.add(jsonObject.getString("message"));
                jsonArray.add(jsonObject.getString("key"));
                jsonArray.add(jsonObject.getString("values"));

            }else{
                System.out.println(urlConnection.getResponseMessage());
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            Log.d(TAG, "MalformedURLException");
        }
        catch (IOException e) {
            e.printStackTrace();
            Log.d(TAG, "IOException");
        } catch (JSONException e) {
            e.printStackTrace();
        } finally{
            if(urlConnection!=null)
                urlConnection.disconnect();
        }
        Log.d(TAG, "getJsonData END");
        return jsonArray;
    }

    public class GetData extends AsyncTask<String, ArrayList<String>, ArrayList<String>> {
        private String urlStr;
        private boolean networkcheck;
        private String param;
        private int stateParse = 0;

        //post방식
        public GetData(String urlStr,boolean networkcheck,String params,int stateParse){
            this.urlStr = urlStr;
            this.networkcheck = networkcheck;
            this.param = params;
            this.stateParse = stateParse;

        }

        //get방식
        public GetData(String urlStr,boolean networkcheck,int stateParse){
            this.urlStr = urlStr;
            this.networkcheck = networkcheck;
            this.stateParse = stateParse;

        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected ArrayList<String> doInBackground(String... params) {
            //  return rc.node_Value;

            if(stateParse == 0) {
                return postJsonData(urlStr, param);
            }else if(stateParse == 1){//get방식
                return getJsonData(urlStr);
            }
            return null;
        }
        @Override
        protected void onPostExecute(ArrayList<String> result){
            super.onPostExecute(result);
            if(networkcheck) {//네트워크가 가능할떄
                if (result != null && result.size() !=0 ) {//받아오는 값이 있을때
                     Log.d(TAG, "result.size : " + result.size());

                    if (result.get(0).equals("1")) {//flag값이 1일때
                        ArrayList<ArrayList<String>> jsonArray = new ArrayList<ArrayList<String>>();
                        JSONObject jObject;
                        jObject = new JSONObject();
                        try {
                            String str = result.get(2);//키값
                            String str2 = result.get(3);//데이터값
                            Log.d(TAG, str);
                            Log.d(TAG, str2);

                            String[] strarray = str.split(",");//키값들을 분류해서 저장
                            if (!strarray[0].equals("null")) {//받아오는 값이 없을때
                                //데이터 값들을 키값 별로 분류해서 저장
                                ArrayList<String> array;
                                JSONArray jsonObject2 = new JSONArray(str2);
                                for (int i = 0; i < strarray.length; i++) {
                                    array = new ArrayList<String>();
                                    for (int j = 0; j < jsonObject2.length(); j++) {
                                        array.add(jsonObject2.getJSONObject(j).getString(strarray[i]));
                                        Log.d(TAG, array.get(j));
                                    }
                                    jsonArray.add(array);
                                }
                                Log.d(TAG,"not null");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        behavior(result.get(0), result.get(1), jsonArray);//넘겨주는 값도 있고 처리도 정상완료
                    } else {
                        behavior(result.get(0), result.get(1), null);//넘겨주는 값은 없고  처리는 정상 완료
                    }
                } else {
                    behavior("0", "네트워크 오류", null);//처리도 안되고 넘겨주는 값도 못받을 경우우
                }
            }else{
                behavior("0", "네트워크 오류", null);//처리도 안되고 넘겨주는 값도 못받을 경우우
            }
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            startParse();
        }

        @Override
        protected void onProgressUpdate(ArrayList<String>... values) {
            super.onProgressUpdate(values);
        }
    }

}
