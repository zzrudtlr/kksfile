package connection;

/**
 * Created by KyoungSik on 2017-03-26.
 * 웹 주소
 */
public class Conn_Address {
    public static String SERVER_ADDRESS = "http://lbflatform.cafe24.com/quickbird/";
   // public static String SERVER_ADDRESS = "http://lbflatform.cafe24.com/quickbird_test/";
    public static String QBSERVER_ADDRESS = "http://quickbird.dev.wyhil.com/";
    public static String OVERLAP_CHECK = "process/id_overlap_check.php";//아이디 중복확인

    public static String PRIVATE_REGISTER = "process/register.php";//개인 유저 등록
    public static String COMPANY_REGISTER = "process/company_register.php";//사업자 유저 등록
    public static String UPLOADPICTURE = "app/qb_00001.php";//사진전송
    public static String UPLOADVIDEO = "app/qb_00002.php";//동영상전송
    public static String COMPANYUSERINFO_UPDATE = "app/qb_00003.php";//사업자 유저 정보수정
    public static String PRIVATEUSERINFO_UPDATE = "app/qb_00004.php";//개인 유저 정보수정
    public static String REQUEST_COMPANYUSERINFO = "app/qb_00005.php";//사업자 유저 정보 받아오기
    public static String LOGIN = "app/qb_00006.php";//로그인
    public static String REQUEST_PRIVATEUSERINFO = "app/qb_00007.php";//개인 유저 정보 받아오기
    public static String UPDATE_DELIVERYLOCATION = "app/qb_00008.php";//배송자 위치 업데이트
    public static String UPDATEPICTURE = "app/qb_00009.php";//프로필 사진 업데이트
    public static String BOOKMARKSEARCH_UPDATE = "app/qb_00010.php";//즐겨찾기 설정 업데이트
    public static String BOOKMARKSEARCHINFO = "app/qb_00011.php";//즐겨찾기 설정 정보 받아오기
    public static String DELIVERY_FINISH_INFO = "app/qb_00012.php";//배송완료정보보내기
    public static String DELIVERY_ASSESSMENT = "app/qb_00013.php";//배송자 평가하기
    public static String MYFREIGHT_LIST = "app/qb_00014.php";//배송안한 화물리스트
    public static String DELIVERY_FINISH = "app/qb_00015.php";//배송완료
    public static String REQUEST_MYFREIGHT_DELIVERY = "app/qb_00017.php";//화물에게 배송 희망하기
    public static String REQUEST_MYDELIVERY_FREIGHT = "app/qb_00016.php";//배송자에게 내화물 배송 희망하기
    public static String REQUEST_DELIVERY_FINSISHINFO = "app/qb_00018.php";//배송완료 정보 받아오기
    public static String DELIVERY_FCMKEY_UPDATE = "app/qb_00019.php";//배송자 fcm_key업데이트
    public static String DELIVERY_DELETE = "app/qb_00020.php";//배송자 정보 삭제
    public static String FREIGHT_DELETE = "app/qb_00021.php";//화물 정보 삭제
    public static String PICTURE_EDIT = "app/qb_00022.php";//사진수정
    public static String DELIVERY_CHECK = "app/qb_00024.php";//배송자 유무 체크
    public static String ID_CHECK = "app/qb_00025.php";//아이디 유무 체크
    public static String REQUEST_ITEMINFO = "app/qb_00026.php";//화물 품목 정보 받아오기
    public static String PUSHOPTION_UPDATE = "app/qb_00027.php";//알림 설정 업데이트
    public static String REQUEST_PUSHOPTION_ = "app/qb_00028.php";//알림 설정 정보 받아오기
    public static String REQUEST_DELIVERY_IN = "app/qb_00031.php";//배송자 이미지 및 이름 정보 받아오기
    public static String REQUEST_DELIVERY_INFO = "app/qb_00032.php";//배송자 정보 이미지, 이름, 메모, 전화번호 받아오기
    public static String REQUEST_FREIGHT_INFO = "app/qb_00033.php";//화물 정보 이미지, 이름, 메모, 전화번호 받아오기
    public static String FIND_PW = "app/qb_00034.php";//비밀번호 찾기
    public static String CANCEL_DELIVERY = "app/qb_00035.php";//배송자 지정 취소
    public static String NOTICE_COOUNT = "app/qb_00036.php";//공지사항 갯수
/*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/
    //웹뷰
    public static String HOME = "webview/home.php";//홈 페이지
    public static String DELIVERY_WRITE = "webview/delivery_write.php";//배송자 등록하기
    public static String FREIGHT_WRITE = "webview/stuff_write.php";//화물 등록하기
    public static String AGREE = "webview/agree.php";//약관동의
    public static String ADDRESS_MAP = "webview/map.php";//주소 맵
    public static String MYREGISTERED_DELIVERY = "webview/my_delivery.php";//내가등록한 배송자
    public static String MYREGISTERED_FREIGHT = "webview/mystuff.php";//냐가 등록한 화물
    public static String SURROUNDING_SEARCH = "webview/naver_map.php";//주변 검색 페이지
    public static String FRIGHTDETAILINFO = "webview/stuff_detail.php";//화물 상세정보
    public static String DELIVERYDETAILINFO = "webview/delivery_detail.php";//배송자 상세정보
    public static String DELIVERYEDIT = "webview/delivery_edit.php";//배송자 수정하기
    public static String FREIGHTEDIT = "webview/stuff_edit.php";//화물 수정하기
    public static String REQUEST_DELIVERY = "webview/hope_delivery.php";//화물 배송을 요청한 배송자 리스트
    public static String REQUEST_FREIGHT = "webview/hope_freight.php";//배송을 요청한 화물
    public static String BOOKMARK = "webview/book_mark_view.php";//즐겨찾기 페이지
    public static String MYFREIGHT_LOCATION = "webview/freight_view_map.php";//내 화물 위치
    public static String NOTICE ="webview/notice.php";
    /*---------------------------------------------------------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------------------------------------------------------*/
    //이미지 경로
    public static String IMAGEADDRESS = "img/";//홈 페이지
}
