package Picture;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by leejaeyoung on 2016-11-08.
 */
public class PictureLoad {
    private Activity act;
    private String res = null;
    private URL url = null;
    private Bitmap bitmap = null;
    private String uri = null;
    private final String Tag = "PictureLoad";
    public PictureLoad(Activity act){
        this.act = act;
    }

    public Bitmap loadBitmap(String address) {//웹 이미지를 가져와 로드
        this.uri = address;
        Thread thread = new Thread(new Runnable() {
            public void run() {
                try {
                    URL imageURL = new URL(uri);
                    HttpURLConnection conn = (HttpURLConnection)imageURL.openConnection();
                    BufferedInputStream bis = new BufferedInputStream(conn.getInputStream(), 10240);
                    bitmap = BitmapFactory.decodeStream(bis);
                    bis.close();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(Tag, "프로필 이미지 : " + bitmap);
        return bitmap;
    }

    public Bitmap getRealPathFromURI(Uri contentUri,int w, int h) {//실제 경로 반환
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = act.getContentResolver().query(contentUri, proj, null, null, null);
        if(cursor.moveToFirst()){
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);//실제 uri 주소
        }
        cursor.close();
        return reSize(res,w,h);
    }

    public Bitmap reSize(String url,int w,int h){//경로에 있는 비트맵이미지 줄임
        Bitmap resize = null;
        if(Build.VERSION.SDK_INT<5) {
            resize = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(url), w, h);
        }else {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            resize = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(url, options), w, h);
        }
        return resize;
    }

    public String getRealPath(){
        return res;
    }

    public Bitmap getBitmap(Uri imgurl, int w, int h){
        return getRealPathFromURI(imgurl,w,h);
    }
}


