package Picture;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import connection.AppNetWrok;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-04-06.
 */
public abstract class PictureUpload {

    private final String TAG = "PictureUpload";

    public abstract void finishUpload(String pictureName);
    public abstract void errorUpload(String errorCode);

    private final int PICTURE_UPLOAD = 0;
    private final int VIDEO_UPLOAD = 1;

    private String urlStr;
    private String[][] str;
    private HttpResponse httpResponse;
    private Bitmap tempBitamp;
    private String resize_path;
    private String video_path;
    private int uploadState;
    /*
    * tempBitmap bitamp 객체, urlStr:이미지를 보내는 주소 값, str:이미지를 보낼 때 보내는 idx 값들을 받는 생성자
    * */
    public PictureUpload(Bitmap tempBitamp, String urlStr, String[][] str) {
        this.urlStr = urlStr;
        this.str = str;
        this.tempBitamp = tempBitamp;
      //  start();
    }

    public PictureUpload(String urlStr, String path) {
        this.urlStr = urlStr;
        this.video_path = path;
        //  start();
    }
    public HttpResponse getResponse(){
        return httpResponse;
    }

    public String getResizePath(){
        return resize_path;
    }

    public void pictureUploadStart() {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost(urlStr);
        httppost.setHeader("Connection", "Keep-Alive");
        httppost.setHeader("Accept-Charset", "UTF-8");
        httppost.setHeader("ENCTYPE", "multipart/form-data");
        MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);

        if(str!=null) {//데이터 와 함께 전달
            for (int i = 0; i < str.length; i++) {
                String tag = "";
                String value = "";
                for (int j = 0; j < str[i].length; j++) {
                    if (j == 0) {
                        tag = str[i][j];
                    } else if (j == 1) {
                        value = str[i][j];
                    }
                }
                try {
                    reqEntity.addPart(tag, new StringBody(value, Charset.forName("UTF-8")));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                    errorUpload(e.toString());
                }
            }
        }
        /*File file = null; // 사진 경로를 통한 file 객체 생성
        if(dir != null){
            file = new File(dir);
        }else{
            file = new File("");
        }*/

        //화소를 줄인 bitmap 파일을 file 객체로 변경 후 전송
        String tempPath = Environment.getExternalStorageDirectory().toString()+"/quickbird/";
        File tempFolder = new File(tempPath);
        if(!tempFolder.exists()){
            tempFolder.mkdir();
        }

        resize_path=tempFolder.getAbsolutePath();

        File tempFile = new File(resize_path,"temp.jpg");
        tempFile.length();
        tempFile.getPath();
        tempFile.getName();
        Log.d(TAG, " tempFile.length() : " + tempFile.length());
        Log.d(TAG," tempFile.getPath() : " +  tempFile.getPath());
        Log.d(TAG," tempFile.getName() : " +  tempFile.getName());
        try {
            FileOutputStream out = new FileOutputStream(tempFile);
           // tempBitamp.compress(Bitmap.CompressFormat.JPEG,100,out);
            tempBitamp.compress(Bitmap.CompressFormat.JPEG,100,out);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            errorUpload(e.toString());
        } catch (IOException e) {
            e.printStackTrace();
            errorUpload(e.toString());
        }

        reqEntity.addPart("fileToUpload", new FileBody(tempFile, "image/jpeg"));
        httppost.setEntity(reqEntity);

        try {
            httpResponse = httpclient.execute(httppost);

        } catch (IOException e) {
            e.printStackTrace();
            Log.d("error", e.toString());
            errorUpload(e.toString());
        }
    }


    public void fileUploadStart(){
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost(urlStr);
        httppost.setHeader("Connection", "Keep-Alive");
        httppost.setHeader("Accept-Charset", "UTF-8");
        httppost.setHeader("ENCTYPE", "multipart/form-data");

        MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
        Log.d(TAG,"video_path : " + video_path);
        File file = new File(video_path);
        reqEntity.addPart("fileToUpload", new FileBody(file));
        httppost.setEntity(reqEntity);

        try {
            httpResponse = httpclient.execute(httppost);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void filestart2() {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost(urlStr);
        httppost.setHeader("Connection", "Keep-Alive");
        httppost.setHeader("Accept-Charset", "UTF-8");
        httppost.setHeader("ENCTYPE", "multipart/form-data");
        MultipartEntity reqEntity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);

        if(str!=null) {//데이터 와 함께 전달
            for (int i = 0; i < str.length; i++) {
                String tag = "";
                String value = "";
                for (int j = 0; j < str[i].length; j++) {
                    if (j == 0) {
                        tag = str[i][j];
                    } else if (j == 1) {
                        value = str[i][j];
                    }
                }
                try {
                    reqEntity.addPart(tag, new StringBody(value, Charset.forName("UTF-8")));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
            }
        }
        /*File file = null; // 사진 경로를 통한 file 객체 생성
        if(dir != null){
            file = new File(dir);
        }else{
            file = new File("");
        }*/
        //화소를 줄인 bitmap 파일을 file 객체로 변경 후 전송
        String tempPath = Environment.getExternalStorageDirectory().toString()+"/quickbird/";
        File tempFolder = new File(tempPath);
        if(!tempFolder.exists()){
            tempFolder.mkdir();
        }

        resize_path=tempFolder.getAbsolutePath();
        File tempFile = new File("/storage/emulated/0/DCIM/Camera/20170330_124235.mp4");
        tempFile.length();
        tempFile.getPath();
        tempFile.getName();
        Log.d(TAG, " tempFile.length() : " + tempFile.length());
        Log.d(TAG," tempFile.getPath() : " +  tempFile.getPath());
        Log.d(TAG," tempFile.getName() : " +  tempFile.getName());
        Log.d(TAG,"resize_path : " + resize_path);
        try {
            FileOutputStream out = new FileOutputStream(tempFile);

            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        reqEntity.addPart("fileToUpload", new FileBody(tempFile, "video/mp4"));
        httppost.setEntity(reqEntity);

        try {
            httpResponse = httpclient.execute(httppost);
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("error", e.toString());
        }
    }

    public void uploadPicture(){
        new GetData(PICTURE_UPLOAD).execute();
    }

    public static Bitmap reSize(String url,int w,int h){//경로에 있는 비트맵이미지 줄임
        Bitmap resize = null;
        if(Build.VERSION.SDK_INT<5) {
            resize = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(url), w, h);
        }else {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            resize = ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(url, options), w, h);
        }
        return resize;
    }

    public static Bitmap getRealPathFromURI(Uri contentUri,Activity act) {//실제 경로 반환
        String res = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = act.getContentResolver().query(contentUri, proj, null, null, null);
        if(cursor.moveToFirst()){
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);//실제 uri 주소
        }
        cursor.close();
        return BitmapFactory.decodeFile(res);
    }

    public void uploadVideo(){
        new GetData(VIDEO_UPLOAD).execute();
    }

    public class GetData extends AsyncTask<String,String,String> {

        private int uploadState;

        //get방식
        public GetData(int state){
            uploadState = state;

        }

        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected String doInBackground(String... params) {
            if(uploadState == PICTURE_UPLOAD) {
                pictureUploadStart();
            }else if(uploadState == VIDEO_UPLOAD){
                fileUploadStart();
            }
            StringBuilder sb = new StringBuilder();
            try {
                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(getResponse().getEntity().getContent()), 65728);
                String line = null;

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            catch (IOException e) { e.printStackTrace(); }
            catch (Exception e) { e.printStackTrace(); }


            System.out.println("finalResult " + sb.toString());
            return sb.toString();
        }

        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
            //     if(networkcheck) {//네트워크가 가능할떄
            finishUpload(result);
            // }
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }
}
