package Picture.MultiplePicture;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.quickbird.quickbird.R;

import java.util.ArrayList;

public class CustomGalleryAdapter extends BaseAdapter {

	private final String TAG = "CustomGalleryAdapter";

	private final int MAX_PICTURECOUNT = 6;//사진 선택할 수있는 최대 개수
	public final int ANDROID_IMAGE = 0;//안드로이드 url 이미지
	public final int WEB_IMAGE = 1;//웹 이미지 경로

	private Context mContext;
	private LayoutInflater infalter;
	private ArrayList<CustomGallery> data = new ArrayList<CustomGallery>();
	ImageLoader imageLoader;

	private int selectCount = 0;//선택된 사진 수

	private int image_state = ANDROID_IMAGE;
	private boolean isActionMultiplePick;

	public CustomGalleryAdapter(Context c, ImageLoader imageLoader) {
		infalter = (LayoutInflater) c
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mContext = c;
		this.imageLoader = imageLoader;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public CustomGallery getItem(int position) {
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public void setMultiplePick(boolean isMultiplePick) {
		this.isActionMultiplePick = isMultiplePick;
	}

	public void selectAll(boolean selection) {
		for (int i = 0; i < data.size(); i++) {
			data.get(i).isSeleted = selection;
		}

		notifyDataSetChanged();
	}

	public ArrayList<CustomGallery> getSelected() {
		ArrayList<CustomGallery> dataList = new ArrayList<CustomGallery>();

		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).isSeleted) {
                dataList.add(data.get(i));
			}
		}

		return dataList;
	}

	public void addAll(ArrayList<CustomGallery> files) {

		try {
			this.data.clear();
			this.data.addAll(files);

		} catch (Exception e) {
			e.printStackTrace();
		}

		notifyDataSetChanged();
	}

	public void changeSelection(View v, int position) {

		if (data.get(position).isSeleted) {
			data.get(position).isSeleted = false;
			selectCount--;
		} else {
			if(selectCount < MAX_PICTURECOUNT) {
				data.get(position).isSeleted = true;
				selectCount++;
			}else{
				Toast.makeText(mContext,"사진선택은 최대 " + MAX_PICTURECOUNT + "장까지 입니다.",Toast.LENGTH_SHORT).show();
			}
		}
		Log.d(TAG, "changeSelection");
		((ViewHolder) v.getTag()).imgQueueMultiSelected.setSelected(data
				.get(position).isSeleted);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		if(image_state == ANDROID_IMAGE) {

			if (convertView == null) {

				convertView = infalter.inflate(R.layout.gallery_item, null);
				holder = new ViewHolder();
				holder.imgQueue = (ImageView) convertView
						.findViewById(R.id.imgQueue);

				holder.imgQueueMultiSelected = (ImageView) convertView
						.findViewById(R.id.imgQueueMultiSelected);

				if (isActionMultiplePick) {
					holder.imgQueueMultiSelected.setVisibility(View.VISIBLE);
				} else {
					holder.imgQueueMultiSelected.setVisibility(View.GONE);
				}
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			holder.imgQueue.setTag(position);

			try {

				imageLoader.displayImage("file://" + data.get(position).sdcardPath,
						holder.imgQueue, new SimpleImageLoadingListener() {
							@Override
							public void onLoadingStarted(String imageUri, View view) {
								holder.imgQueue
										.setImageResource(R.drawable.no_media);
								super.onLoadingStarted(imageUri, view);
							}
						});

				if (isActionMultiplePick) {

					holder.imgQueueMultiSelected
							.setSelected(data.get(position).isSeleted);

				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}else if(image_state == WEB_IMAGE){
			if(convertView == null){
				convertView = infalter.inflate(R.layout.gallery_item, null);
				holder = new ViewHolder();
				holder.imgQueue = (ImageView) convertView
						.findViewById(R.id.imgQueue);
				holder.imgQueueMultiSelected = (ImageView) convertView
						.findViewById(R.id.imgQueueMultiSelected);
				holder.imgQueueMultiSelected.setVisibility(View.GONE);
				Log.d(TAG, "gridimage : data : " + data.get(position).webImagePath);
				Glide.with(infalter.getContext()).load(data.get(position).webImagePath).into(holder.imgQueue);
				convertView.setTag(holder);
			}else{
				holder = (ViewHolder) convertView.getTag();
			}
//			Glide.with(infalter.getContext()).load(data.get(position).webImagePath).into(holder.imgQueue);
			//holder.imgQueue.setTag(position);
			Log.d(TAG, "gridimage : data : " + data.get(position).webImagePath);

		}
		//Log.d(TAG,"gridimage : data : " + data.get(position).webImagePath);
		return convertView;
	}

	public class ViewHolder {
		ImageView imgQueue;
		ImageView imgQueueMultiSelected;
	}

	public void clearCache() {
		imageLoader.clearDiscCache();
		imageLoader.clearMemoryCache();
	}

	public void clear() {
		data.clear();
		notifyDataSetChanged();
	}

	public void setImage_state(int image_state) {
		this.image_state = image_state;
	}
}
