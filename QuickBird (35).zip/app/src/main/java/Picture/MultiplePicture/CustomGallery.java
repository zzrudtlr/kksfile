package Picture.MultiplePicture;

public class CustomGallery {

	public String sdcardPath;
	public boolean isSeleted = false;
	public String webImagePath;

}
