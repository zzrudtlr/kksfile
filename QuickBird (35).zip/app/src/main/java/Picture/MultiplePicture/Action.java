package Picture.MultiplePicture;

public class Action {

	public static final String ACTION_PICK = "quickbird.ACTION_PICK";
	public static final String ACTION_MULTIPLE_PICK = "quickbird.ACTION_MULTIPLE_PICK";
}
