package Picture;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.io.File;

/**
 * Created by KyoungSik on 2017-03-29.
 * 기기 사진 가져오기
 */
public class DevicePicture {

    private final String TAG = "DevicePicture";

    public final int PICK_FROM_CAMERA = 0;// 카메라로 사진찍어서 가져오기
    public final int PICK_FROM_ALBUM = 1;// 앨범에서 사진 가져오기
    public final int CROP_FROM_iMAGE = 2;//이미지 자르기

    private Uri mImageCaptureUri;
    private Activity act;
    private ImageView imageView;
    private Bitmap bitmap;
    public DevicePicture(Activity act){
        this.act = act;
    }


    /* 카메라에서 사진 촬열
    *
    * */
    public void doTakePhotoAction(){//카메라 촬영 후 이미지 가져오기
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        //임시로 사용할 파일의 경로를 생성
        String url = "tmp_" + String.valueOf(System.currentTimeMillis()) + ".jpg";
        mImageCaptureUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(), url));

        intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageCaptureUri);
        act.startActivityForResult(intent, PICK_FROM_CAMERA);
    }



    /* 앨범에서 이미지 가져오기
    *
    * */
    public void doTakeAlbumAction(){//앨범에서 이미지 가져오기
        //앨범 호출
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        act.startActivityForResult(intent,PICK_FROM_ALBUM);
    }

    //사진 찍은 이미지 자르기
    public void pickFromCamera(){
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(mImageCaptureUri,"image/");

        intent.putExtra("outputX", 200);//CROP한 이미지의 X축 크기
        intent.putExtra("outputY", 200);//CROP한 이미지의 Y축 크기
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        intent.putExtra("scale", true);
        intent.putExtra("return-data", true);
       // act.startActivityForResult(intent, CROP_FROM_iMAGE);
    }

    public void cropFromImage(Intent data,ImageView imabeView){
        final Bundle extras = data.getExtras();
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/SmartWheel/"+System.currentTimeMillis() + ".jpg";

        if(extras != null){
            Bitmap photo = extras.getParcelable("data");
            imabeView.setImageBitmap(photo);
            //storeCropImage
        }

        //임시 파일 삭제
        File f = new File(mImageCaptureUri.getPath());
        if(f.exists()){
            f.delete();
        }
    }

    public void setImageView(ImageView imageView) {
        this.imageView = imageView;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public Uri getmImageCaptureUri() {
        return mImageCaptureUri;
    }

    public void setmImageCaptureUri(Uri mImageCaptureUri) {
        this.mImageCaptureUri = mImageCaptureUri;
    }
}
