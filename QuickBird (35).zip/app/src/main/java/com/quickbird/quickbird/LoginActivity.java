package com.quickbird.quickbird;

import android.app.Activity;
import android.bluetooth.BluetoothClass;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import org.w3c.dom.Text;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import Database.UserInfo;
import Dialog.FindPwDialog;
import Dialog.Loading;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Permission.DevicePermission;
import Register.ImageIcon;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-02
 * 로그인 페이지
 */
public class LoginActivity extends Activity {

    private final String TAG = "LoginActivity";

    private boolean isAutologinState = false;

    public final int ICON_EMAIL = 0;//이메일 아이디
    public final int ICON_PW = 1;//비밀번호

    private Loading loading;

    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();
    private BackPressClose backPressClose;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        try {
            String token = FirebaseInstanceId.getInstance().getToken();
            Log.d(TAG, token);
        }catch (NullPointerException e){
            Log.d(TAG, e.toString());
        }
    }


    private void init(){
        backPressClose = new BackPressClose(this);
        DevicePermission devicePermission = new DevicePermission();
        devicePermission.checkPermissionGps(this);
        loading = new Loading(this);
        imageIconinit();
        buttonEvent();
        editTextEvent();
        setUserInfo();
    }

    /* 로그인 페이지 버튼 이벤트
    *
    * */
    private void buttonEvent(){
        //로그인 버튼
        Button loginbtn = (Button)findViewById(R.id.loginbtn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "login button click");
                JsonParse jsonParse = new JsonParse(getLoginActivity()) {
                    @Override
                    public void startParse() {
                        loading.show();
                    }

                    @Override
                    public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                        Log.d(TAG, "flag : " + flag);
                        Log.d(TAG, "message : " + message);

                        loading.dismiss();
                        if (flag.matches("1")) {
                            Intent intent = new Intent(LoginActivity.this, QB_MainActivity.class);
                            startActivity(intent);
                            Toast.makeText(getLoginActivity(), "로그인 성공", Toast.LENGTH_SHORT).show();
                            storeDatabase(result);
                            finish();
                        } else {
                            Toast.makeText(getLoginActivity(), "로그인 실패", Toast.LENGTH_SHORT).show();
                        }

                    }
                };
                jsonParse.getJsonParse(getUrlStr());
            }
        });

        //회원가입
        TextView register = (TextView)findViewById(R.id.lregisterbtn);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(LoginActivity.this) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {//개인 회원가입 버튼 클릭
                        Log.d(TAG, "개인 회원");
                        //  Intent private_user = new Intent(LoginActivity.this, PrivateUserRegisterActivity.class);
                        // startActivity(private_user);
                        Intent private_user = new Intent(LoginActivity.this, AgreeActivity.class);
                        private_user.putExtra("stateRegister", "0");
                        startActivity(private_user);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {//사업자 회원가입 버튼 클릭
                        Log.d(TAG, "사업자 회원");
                        // Intent company_user = new Intent(LoginActivity.this, CompanyUserRegisterActivity.class);
                        //startActivity(company_user);
                        Intent company_user = new Intent(LoginActivity.this, AgreeActivity.class);
                        company_user.putExtra("stateRegister", "1");
                        startActivity(company_user);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("개인 회원가입");
                selectTwoDialog.getSelectTwoButton().setText("사업자 회원가입");
                selectTwoDialog.show();
            }
        });

        //비밀번호찾기
        TextView findPwText = (TextView)findViewById(R.id.findpwText);
        findPwText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FindPwDialog findPwDialog = new FindPwDialog(LoginActivity.this) {
                    @Override
                    public void onClickConfirm(String emailid, FindPwDialog findPwDialog) {
                        Log.d(TAG, "emaild : " + emailid);
                        findPwDialog.dismiss();
                        findPw(emailid);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                findPwDialog.show();
            }
        });

        Button autobtn = (Button)findViewById(R.id.autologinbtn);
        autobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isAutologinState) {
                    isAutologinState = true;
                    v.setBackgroundResource(R.drawable.icon_check_on);
                } else {
                    isAutologinState = false;
                    v.setBackgroundResource(R.drawable.icon_check_off);
                }
            }
        });
    }
    /* 내부 디비 저장 및 업데이트
    *
    * */
    private void storeDatabase(ArrayList<ArrayList<String>> result){
        UserInfo userInfo = new UserInfo();
        userInfo.user_idx = result.get(0).get(0);
        userInfo.user_type = result.get(1).get(0);
        userInfo.profile_img = result.get(2).get(0);
        userInfo.user_id = imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        userInfo.user_pw = imageIcons.get(ICON_PW).getEditText().getText().toString();
        userInfo.loginauto_state = "0";
        if(isAutologinState){//자동로그인
            userInfo.loginauto_state = "1";
        }

        if(DB_SingleTon.getInstance(this).getUserInfoTable().getCheck()){//로그인 데이터가 있을시
            if(DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx().matches(userInfo.user_idx)){//이전 로그인 했을때와 같은 아이디로 로그인 했을때
                DB_SingleTon.getInstance(this).getUserInfoTable().updateAutoLogin(userInfo.loginauto_state);
                DB_SingleTon.getInstance(this).getUserInfoTable().updateProfileImage(userInfo.profile_img);
                Log.d(TAG,"같은 아이디 로그인");
            }else{// 이전 로그인과 아이디가 다를 시
                Log.d(TAG,"다른 아이디 로그인");
                DB_SingleTon.getInstance(this).getUserInfoTable().deleteAllColumns();//초기화
                DB_SingleTon.getInstance(this).getUserInfoTable().insertColumn(userInfo);//내부 디비에 유저 등록
            }
        }else{
            DB_SingleTon.getInstance(this).getUserInfoTable().insertColumn(userInfo);//내부 디비에 유저 등록
        }
       // DB_SingleTon.getInstance(this).getUserInfoTable().selectColumn();
    }

    /* 내부디비에서 유저 아이디 비밀번호 가져오기
    *
    * */
    private void setUserInfo(){
        if(DB_SingleTon.getInstance(this).getUserInfoTable().getCheck()){
            Log.d(TAG,"setUserInfo");
            ArrayList<String> userinfo = DB_SingleTon.getInstance(this).getUserInfoTable().useridpw();
            Log.d(TAG,"setUserInfo user_id : " + userinfo.get(0));
            Log.d(TAG,"setUserInfo user_pw : " + userinfo.get(1));
            imageIcons.get(ICON_EMAIL).getEditText().setText(userinfo.get(0));
            imageIcons.get(ICON_PW).getEditText().setText(userinfo.get(1));
        }
    }

    /* 로그인 주소 값
   *
   * */
    private String getUrlStr(){
        String urlStr = "";
        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.LOGIN;
        urlStr = urlStr + "?email=" + imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        urlStr = urlStr + "&pw=" + imageIcons.get(ICON_PW).getEditText().getText().toString();
        urlStr = urlStr + "&fcm_key="+ FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }


    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
*
* */
    private void editTextEvent(){
        for(int i=0;i<imageIcons.size();i++) {
            imageIcons.get(i).getEditText().setId(imageIcons.get(i).getImageId());
            imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                    } else {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                    }
                }
            });
        }
    }

    /* 아이콘 초기화
    *
    * */
    private void imageIconinit() {

        //이메일 아이디 아이콘
        ImageIcon emaildIcon = new ImageIcon();
        emaildIcon.setEditText((EditText) findViewById(R.id.lemailidText));
        emaildIcon.setImageId(ICON_EMAIL);
        emaildIcon.setView((ImageView) findViewById(R.id.lemailidImage));
        emaildIcon.setSetOnImage(R.drawable.icon_email_on);
        emaildIcon.setSetOffImage(R.drawable.icon_email_off);
        imageIcons.add(emaildIcon);

        //비밀번호  아이콘
        ImageIcon pwIcon = new ImageIcon();
        ImageView pwImage = (ImageView) findViewById(R.id.lpwImage);
        pwIcon.setView(pwImage);
        pwIcon.setEditText((EditText) findViewById(R.id.lpwText));
        pwIcon.setImageId(ICON_PW);
        pwIcon.setSetOnImage(R.drawable.icon_lock_on);
        pwIcon.setSetOffImage(R.drawable.icon_lock_off);
        imageIcons.add(pwIcon);
    }

    /* 비밀번호 찾기 url
    *`
    * */
    private String getfindPwUrlStr(String email_id){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.FIND_PW;
        urlStr = urlStr + "?email_id="+ email_id;
        Log.d(TAG, "getfindPwUrlStr : " + urlStr);
        return urlStr;
    }

    /* 비밀번호 찾기
    *
    * */
    private void findPw(String email_id){
        JsonParse jsonParse = new JsonParse(getLoginActivity()) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                if (flag.matches("1")) {
                    String sendmailurl = result.get(0).get(0);
                    sendmailurl = sendmailurl + "?mailto=" + result.get(1).get(0);


               /*     try {
                        sendmailurl = sendmailurl + "&subject=" + URLEncoder.encode(result.get(2).get(0), "UTF-8");
                        sendmailurl = sendmailurl + "&content=" +  result.get(3).get(0);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    sendmailurl = sendmailurl + "&mailfrom=" + result.get(4).get(0);
                    sendmailurl = sendmailurl + "&namefrom=" + result.get(5).get(0);*/
                    Log.d(TAG,"sendmailurl : " + sendmailurl);
                    sendMail(sendmailurl);
                }else{
                    loading.dismiss();
                    Toast.makeText(getLoginActivity(),"메일전송에 실패하였습니다.",Toast.LENGTH_SHORT).show();
                }

               /* loading.dismiss();
                if (flag.matches("1")) {
                    Toast.makeText(getLoginActivity(),"비밀번호가 메일로 전송되었습니다.",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getLoginActivity(),"메일전송에 실패하였습니다.",Toast.LENGTH_SHORT).show();
                }*/

            }
        };
        jsonParse.getJsonParse(getfindPwUrlStr(email_id));
    }

    private void sendMail(String mailUrl){

        Log.d(TAG,"mailUrl : " + mailUrl);

        JsonParse jsonParse = new JsonParse(getLoginActivity()) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);

                loading.dismiss();
                if (flag.matches("1")) {
                    Toast.makeText(getLoginActivity(),"비밀번호가 메일로 전송되었습니다.",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getLoginActivity(),"메일전송에 실패하였습니다.",Toast.LENGTH_SHORT).show();
                }

            }
        };

        jsonParse.getJsonParse(mailUrl);

    }

    private LoginActivity getLoginActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "destory");
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
    /*
    * 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
    * */
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Log.d("onBack", "backpress");
        backPressClose.CloseOnBackPressed();
    }
}
