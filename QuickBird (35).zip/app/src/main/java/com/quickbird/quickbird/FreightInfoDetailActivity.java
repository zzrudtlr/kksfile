package com.quickbird.quickbird;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import Dialog.Loading;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 화물 상세보기
 */
public class FreightInfoDetailActivity extends Activity {

    private final String TAG = "FreightInfoDetail";

    private WebViewClass webViewClass;
    private Loading loading;

    private String freight_idx="";
    private String startState="not_push";//푸쉬로인해 켜진건지
    private String home_flag="";//화물 승인 여부 배송중이 아닐시 아무값도 없음 1: 배송중임

    private boolean topActivityCheck = false; //false : topActivity아님

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freightinfo_detail);
        freight_idx = getIntent().getStringExtra("freight_idx");

        try{
            home_flag = getIntent().getStringExtra("home_flag");
        }catch (Exception e){
            home_flag = "";
        }

        try{
            startState = getIntent().getStringExtra("startState");
            if(startState == null){
                startState = "not_push";
            }
        }catch (Exception e){
            startState = "not_push";
            Log.d(TAG,e.toString());
        }
        String topCheck = getIntent().getStringExtra("topActivity");
        try {
            Log.d(TAG,"topCheck : " + topCheck);
            Log.d(TAG,"getSimpleName : " + this.getClass().getSimpleName());
            if (!topCheck.matches(this.getClass().getPackage().getName())) {
                Log.d(TAG,"topCheck2 : " + topCheck);
                topActivityCheck = true;
            }
        }catch (NullPointerException e){
            topActivityCheck = false;
        }

        loading = new Loading(this);

        init();
        eventButton();
    }

    private void init(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.fdwebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                loading.show();
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });
    }

    /* 화물 상세정보 url
    *
    * */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.FRIGHTDETAILINFO;
        urlStr = urlStr + "?freight_idx="+ freight_idx;
        if(home_flag != null) {
            urlStr = urlStr + "&home_flag=" + home_flag;
        }
        Log.d(TAG, "getUrlStr : " + urlStr);
        return urlStr;
    }

    /* 화물에게 배송 희망하기 url
    *
    * */
    private String getRequestDeliveryFreightUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_MYDELIVERY_FREIGHT;
        urlStr = urlStr + "?delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        urlStr = urlStr + "&freight_idx=" + freight_idx;

        Log.d(TAG,"getRequestDeliveryFreightUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송자에게 내화물 배송 신청하기
 *
 * */
    private void updateDeliveryFreight(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Toast.makeText(getFreightInfoDetailActivity(), "화물 배송을 신청하였습니다.", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getFreightInfoDetailActivity(), message, Toast.LENGTH_SHORT).show();
                }


                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestDeliveryFreightUrlStr());
    }

    private void eventButton(){
        //배송자 희망하기
        Button deliveryregisterbtn = (Button)findViewById(R.id.fidregisterbtn);
        deliveryregisterbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "delivery_idx : " + DB_SingleTon.getInstance(getFreightInfoDetailActivity()).getUserInfoTable().getDelivery_idx());
                if(!DB_SingleTon.getInstance(getFreightInfoDetailActivity()).getUserInfoTable().getDelivery_idx().matches("0")){
                    updateDeliveryFreight();
                }else{
                    Toast.makeText(getFreightInfoDetailActivity(),"배송자를 지정해주세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    /*
     *
     * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.dismiss();
            }
        }
    };
    private FreightInfoDetailActivity getFreightInfoDetailActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
        /*
     * 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
     * */
    @Override
    public void onBackPressed() {
        //;
        Log.d("onBack", "backpress");
      if(startState.matches("not_push")){//푸시로 화면이 실행안된경우
          super.onBackPressed();
      }else{//푸시로 실행된경우
          if(topActivityCheck) {
              BackPressClose backPressClose = new BackPressClose(this);
              backPressClose.BackActivity(this, IntroActivity.class);
          }else{
              super.onBackPressed();
          }
      }
    }

}
