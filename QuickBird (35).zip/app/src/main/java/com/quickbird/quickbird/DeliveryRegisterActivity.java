package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

import Database.DB_SingleTon;
import Dialog.ConfirmDialog;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Gps.GpsInfo;
import Permission.DevicePermission;
import Picture.DevicePicture;
import Picture.MultiplePicture.Action;
import Picture.PictureUpload;
import WebView.WebViewClass;
import WebView.KeboardControll;
import connection.AppNetWrok;
import connection.Conn_Address;
import WebView.OnWebViewClientListener;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-29.
 * 배송자 등록하기
 */
public class DeliveryRegisterActivity extends Activity {

    private final String TAG = "DeliveryRegister";

    private final int PICK_FROM_CAMERA = 0;
    private final int PICK_FROM_ALBUM = 1;
    private final int CROP_FROM_iMAGE = 2;
    private final int SELECT_CAPTURE = 3;

    public final int SELECT_ADDRESS_MAP=4;
    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;

    private int spap_state=0;//출발지 도착지 구분

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;

    private DevicePicture devicePicture;

    private Uri mImageCaptureUri;
    private ImageView profileImageView;
    private DevicePermission devicePermission;//접근허용

    private Bitmap profile_img;

    private String profileimage_name="";

    private boolean imageSelect = false;

    private String image_path="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_register);
        init();
    }

    private void init(){
        loading = new Loading(this);
        errorView = (LinearLayout)findViewById(R.id.dr_errorview);
        profileImageView = (ImageView)findViewById(R.id.drprofileImageView);
        devicePicture = new DevicePicture(this);
        devicePermission = new DevicePermission();
        webViewinit();
        buttonEvent();
        keyboardControll();
    }
    /* 배송자 등록하기 입력폼 웹 뷰
    *
    * */
    private void webViewinit(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.drwebview),this,getDeliveryStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void map(int state) {
                spap_state = state;//출발지 도착지 구분
                Log.d(TAG, "map : " + spap_state);
                GpsInfo gpsInfo = new GpsInfo(getDeliveryRegisterActivity());
                if (gpsInfo.isGetLocation()) {
                    SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getDeliveryRegisterActivity()) {
                        @Override
                        public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                            selectInternatinl(DOMESTIC);
                            selectTwoDialog.dismiss();
                        }

                        @Override
                        public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                            selectInternatinl(OVERSEAS);
                            selectTwoDialog.dismiss();
                        }

                        @Override
                        public void clickCancelButton() {

                        }
                    };
                    selectTwoDialog.getSelectOneButton().setText("국내");
                    selectTwoDialog.getSelectTwoButton().setText("국외");
                    selectTwoDialog.show();
                }else{
                    Toast.makeText(getDeliveryRegisterActivity(), "GPS 정보를 켜주세요.", Toast.LENGTH_SHORT).show();
                    gpsInfo.showSettingsAlert();
                }
            }

            @JavascriptInterface
            public void message(String message) {
                Log.d(TAG, "messagev : " + message);
                Toast.makeText(getDeliveryRegisterActivity(), message, Toast.LENGTH_SHORT).show();
            }

            @JavascriptInterface
            public void save_file() {
                Log.d(TAG, "save_file");
            }

            @JavascriptInterface
            public void qb_exeption(boolean flag) {
                Log.d(TAG, "qb_exeption : " + flag);
                if (exception(flag)) {
                    //     pictureUpload();
                    fregithVideoUpload(image_path);
                }
            }

            @JavascriptInterface
            public void result(String result, String message) {
                Log.d(TAG, "result : " + result);
                handler.sendEmptyMessage(4);//pictureUpload에서 로딩 시작
                if (result.matches("1")) {
                    Toast.makeText(getDeliveryRegisterActivity(), message, Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    Toast.makeText(getDeliveryRegisterActivity(), message, Toast.LENGTH_SHORT).show();
                    loading.dismiss();
                }
            }
        }, "quickbird");
    }

    private String getDeliveryStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_WRITE;
        webUrlStr = webUrlStr + "?user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        webUrlStr = webUrlStr + "&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        webUrlStr = webUrlStr + "&fcm=";
        Log.d(TAG, "getDeliveryStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 출발지 정보 웹뷰로 보내기
    *
    * */
    private void sendSPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:sp_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }

    /* 도착지 정보 웹뷰로 보내기
    *
    * */
    private void sendAPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:ap_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }

    /* 등록하기
    *
    * */
    private void sendRegister(){
        webViewClass.getWebView().loadUrl("javascript:register();");
    }

    /* 웹 예외처리
    *
    * */
    private void sendExption(){
        webViewClass.getWebView().loadUrl("javascript:qb_exeption();");
    }


    /* 이미지 이름 보내기
     *
     * */
    private void sendImageName(String imgName){
        webViewClass.getWebView().loadUrl("javascript:img_insert('" + imgName + "');");
    }

    private void keyboardControll(){
        final KeboardControll softKeyboardDecector = new KeboardControll(this);
        addContentView(softKeyboardDecector, new FrameLayout.LayoutParams(-1, -1));

        softKeyboardDecector.setOnShownKeyboard(new KeboardControll.OnShownKeyboardListener() {

            @Override
            public void onShowSoftKeyboard() {
                //키보드 등장할 때
                Log.d(TAG, "onShowSoftKeyboard : ");

            }
        });

        softKeyboardDecector.setOnHiddenKeyboard(new KeboardControll.OnHiddenKeyboardListener() {

            @Override
            public void onHiddenSoftKeyboard() {
                // 키보드 사라질 때
                Log.d(TAG, "onHiddenSoftKeyboard : ");

            }
        });
    }

    /* 버튼 이벤트
    *
    * */
    private void buttonEvent(){
        //웹뷰 재시도 버튼
        Button restartbtn = (Button)findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webViewClass.getWebView().reload();
                errorView.setVisibility(View.GONE);
            }
        });
        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.drcancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getDeliveryRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        getDeliveryRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });
        //종료버튼
        Button exitbtn = (Button)findViewById(R.id.drexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        //카메라버튼
        Button camerabtn = (Button)findViewById(R.id.drcamerabtn);
        camerabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "camerabtn");
             //   devicePicture.doTakeAlbumAction();
                if (devicePermission.checkPermission(getDeliveryRegisterActivity())) {
                    selectPicture();
                }
            }
        });

        /* 등록하기 버튼
        *
        * */
        Button registerbtn = (Button)findViewById(R.id.drregisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  for(int i=0;i<6;i++) {
                 //   new GetData().execute();

               // }
                sendExption();
            }
        });
    }
    //사진 상태 선택하기
    private void selectPicture(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getDeliveryRegisterActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                // doFilmingMovie();
                doImagePicture();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {

                    devicePicture.doTakeAlbumAction();

                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("이미지 촬영");
        selectTwoDialog.getSelectTwoButton().setText("이미지 앨범");
        selectTwoDialog.show();
    }

    //이미지 촬영 후 가져오기
    private void doImagePicture(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, SELECT_CAPTURE);

    }
    private boolean exception(boolean check){

        if(check){
            if(!imageSelect) {
                check = false;
                Toast.makeText(getDeliveryRegisterActivity(), "프로필 이미지를 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
        }
        return check;
    }


    /* 배송자 사진 업로드
    *
    * */
    private void fregithVideoUpload(String path){
        handler.sendEmptyMessage(3);
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(url, path) {
            @Override
            public void finishUpload(String pictureName) {
                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG, "message : " + jsonObject.getString("message"));
                    profileimage_name = jsonObject.getString("message");
                    handler.sendEmptyMessage(2);
                    //  loading.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                loading.dismiss();
                handler.sendEmptyMessage(4);
            }
        };//섬네일 이미지 사진업로드
        pu.uploadVideo();
    }

    private void pictureUpload(){
        loading.show();//result 에서 로딩 종료
        String str[][] = {{"fileName",""},{"target_dir","image/"}};
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(profile_img, url, str) {
            @Override
            public void finishUpload(String pictureName) {
                Log.d(TAG, "pictureName : " + pictureName);

                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG,"message : " + jsonObject.getString("message"));
                    profileimage_name = jsonObject.getString("message");
                  //  sendImageName(profileimage_name);
                  //  sendRegister();

                    handler.sendEmptyMessage(2);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                Log.d(TAG,"pictureuload errorCode : " + errorCode);
               handler.sendEmptyMessage(4);
            }
        };//섬네일 이미지 사진업로드
        pu.uploadPicture();
    }

    /* 국내, 국외 구분 함수
 *
 * */
    private void selectInternatinl(int countryState) {
        if (countryState == DOMESTIC) {
            handler.sendEmptyMessage(0);
        } else if (countryState == OVERSEAS) {
            handler.sendEmptyMessage(1);
        }
    }


    /* 지도 선택 다이얼로그 띄우기
   *
   * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                // btnState = true;
              /*  SelectAddressDialog selectAddressDialog = new SelectAddressDialog(getDeliveryRegisterActivity()) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        if (spap_state == 0) {
                            sendSPpoint(lng, lat, address,DOMESTIC);
                        } else if (spap_state == 1) {
                            sendAPpoint(lng, lat, address,DOMESTIC);
                        }
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();*/
                Intent intent = new Intent(DeliveryRegisterActivity.this,SelectAddressActivity.class);
                startActivityForResult(intent, SELECT_ADDRESS_MAP);
            }else if(msg.what == 1){
                String[] country;
                Locale[] locales = Locale.getAvailableLocales();

                String[] isoCodes = Locale.getISOCountries();
                country = new String[isoCodes.length];

                for (int i = 0; i < isoCodes.length; i++) {
                    Locale locale = new Locale("en", isoCodes[i]);
                    Log.d(TAG, "country : " + locale.getDisplayCountry());
                    country[i] = locale.getDisplayCountry();
                }
                //나라 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(getDeliveryRegisterActivity(), country);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {

                        String address = selectListDialog.getSubTitleText().getText().toString() + selectListDialog.getSubAddressEdit().getText().toString();
                        Log.d(TAG, "address : " + address);
                        if(spap_state == 0) {
                            sendSPpoint("0", "0", address,OVERSEAS);
                        }else if(spap_state == 1){
                            sendAPpoint("0", "0", address,OVERSEAS);
                        }
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);

                    }
                });
                selectListDialog.getTitleImage().setVisibility(View.GONE);
                selectListDialog.getTitleText().setText("나라 선택");
                selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
                selectListDialog.show();
            } else if(msg.what ==2){
               // loading.dismiss();
                sendImageName(profileimage_name);
                sendRegister();
            }else if(msg.what ==3){
               loading.show();
            }else if(msg.what ==4){
                loading.dismiss();
            }
        }
    };

    public DeliveryRegisterActivity getDeliveryRegisterActivity(){
        return this;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK)
            return;
        Log.d(TAG, "onActivityResult : " + requestCode);

       switch (requestCode){
           case SELECT_ADDRESS_MAP:
           {
               try {
                   Log.d(TAG, "lat : " + data.getStringExtra("lat") + "lng : " + data.getStringExtra("lng") + "address : " + data.getStringExtra("address"));
                   if (spap_state == 0) {
                       sendSPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                   } else if (spap_state == 1) {
                       sendAPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                   }
               }catch (NullPointerException e){
                   Log.d(TAG,"주소검색 : " + e.toString());
               }
               break;
           }

            case PICK_FROM_ALBUM:
            {
                devicePicture.setmImageCaptureUri(data.getData());
                image_path = getPath(data.getData());
                profile_img = PictureUpload.reSize(image_path, 200, 200);
                //profileImageView.setImageBitmap(profile_img);
                Bitmap circleBitmap = Bitmap.createBitmap(profile_img.getWidth(), profile_img.getHeight(), Bitmap.Config.ARGB_8888);

                BitmapShader shader = new BitmapShader(profile_img,  Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Paint paint = new Paint();
                paint.setShader(shader);

                Canvas c = new Canvas(circleBitmap);
                c.drawCircle(profile_img.getWidth()/2, profile_img.getHeight()/2, profile_img.getWidth()/2, paint);
                profileImageView.setImageBitmap(circleBitmap);
              //  profile_img.recycle();
              //  circleBitmap.recycle();
                imageSelect = true;
                Log.d(TAG, "PICK_FROM_ALBUM");
            }
           case SELECT_CAPTURE:
           {
               devicePicture.setmImageCaptureUri(data.getData());
               image_path = getPath(data.getData());
               profile_img = PictureUpload.reSize(image_path, 200, 200);
               //profileImageView.setImageBitmap(profile_img);
               Bitmap circleBitmap = Bitmap.createBitmap(profile_img.getWidth(), profile_img.getHeight(), Bitmap.Config.ARGB_8888);

               BitmapShader shader = new BitmapShader(profile_img,  Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
               Paint paint = new Paint();
               paint.setShader(shader);

               Canvas c = new Canvas(circleBitmap);
               c.drawCircle(profile_img.getWidth()/2, profile_img.getHeight()/2, profile_img.getWidth()/2, paint);
               profileImageView.setImageBitmap(circleBitmap);
               //  profile_img.recycle();
               //  circleBitmap.recycle();
               imageSelect = true;
               Log.d(TAG, "SELECT_CAPTURE");
           }
            case PICK_FROM_CAMERA:
            {
                devicePicture.pickFromCamera();
                Log.d(TAG, "PICK_FROM_CAMERA");
            }

            case CROP_FROM_iMAGE:
            {
                Log.d(TAG, "CROP_FROM_iMAGE");
                if(resultCode != RESULT_OK){
                    return;
                }
              //  devicePicture.cropFromImage(data,profileImageView);
            }

        }
    }

    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        cursor.close();
        return cursor.getString(column_index);
    }

    public Bitmap getRealPathFromURI(Uri contentUri) {//실제 경로 반환
        String res = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = this.getContentResolver().query(contentUri, proj, null, null, null);
        if(cursor.moveToFirst()){
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);//실제 uri 주소
        }
        cursor.close();
        return BitmapFactory.decodeFile(res);
    }



    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
