package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import Dialog.Loading;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-04-03.
 * 약관동의
 */
public class AgreeActivity extends Activity{

    private final String TAG = "AgreeActivity";

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;

    private String stateRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_argee);
        stateRegister = getIntent().getStringExtra("stateRegister");
        Log.d(TAG, "stateRegister : " + stateRegister);
        init();
        webinit();
        eventButton();
    }

    private void init(){
        errorView = (LinearLayout)findViewById(R.id.fr_errorview);
        loading = new Loading(this);
        loading.show();
    }

    private void webinit(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.AGREE;
        Log.d(TAG,"urlStr : " + urlStr);
        webViewClass = new WebViewClass((WebView)findViewById(R.id.awebview),this,urlStr);
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void next(int state) {
                Log.d(TAG,"state : " + state);
                if(state == 1){
                    onNextRegister();
                }else{
                    Toast.makeText(AgreeActivity.this,"정보동의를 해주세요.",Toast.LENGTH_SHORT).show();
                }
            }

        }, "quickbird");

    }

    private void eventButton(){
        Button restartbtn = (Button)findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webViewClass.getWebView().reload();
                errorView.setVisibility(View.GONE);
            }
        });

        Button exitbtn = (Button)findViewById(R.id.frdexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void onNextRegister(){
        if(stateRegister.matches("0")) {//개인회원가입
            Intent private_user = new Intent(AgreeActivity.this, PrivateUserRegisterActivity.class);
             startActivity(private_user);
        }else{
            Intent company_user = new Intent(AgreeActivity.this, CompanyUserRegisterActivity.class);
            startActivity(company_user);
        }
        finish();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}

