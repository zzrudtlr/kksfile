package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;

import Database.DB_SingleTon;
import Dialog.ConfirmDialog;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Permission.DevicePermission;
import Picture.CustomBitmapPool;
import Picture.DevicePicture;
import Picture.PictureUpload;
import Register.ImageIcon;
import WebView.WebViewClass;
import WebView.KeboardControll;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropCircleTransformation;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 배송자 정보 수정하기
 */
public class DeliveryEditActivity extends Activity {

    private final String TAG = "DeliveryEditActivity";

    private final int PICK_FROM_CAMERA = 0;
    private final int PICK_FROM_ALBUM = 1;
    private final int CROP_FROM_iMAGE = 2;
    public final int SELECT_ADDRESS_MAP=4;

    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;

    private int spap_state=0;//출발지 도착지 구분

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;

    private DevicePicture devicePicture;

    private Uri mImageCaptureUri;
    private ImageView profileImageView;
    private DevicePermission devicePermission;//접근허용

    private Bitmap profile_img;

    private String profileimage_name="";

    private String image_path="";

    private boolean imageChange = false;

    private String delivery_idx="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deliveryinfo_edit);
        delivery_idx = getIntent().getStringExtra("delivery_idx");
        init();
    }

    private void init(){
        loading = new Loading(this);
        errorView = (LinearLayout)findViewById(R.id.de_errorview);
        profileImageView = (ImageView)findViewById(R.id.deprofileImageView);
        devicePicture = new DevicePicture(this);
        devicePermission = new DevicePermission();
        webViewinit();
        buttonEvent();
        keyboardControll();
    }
    /* 배송자 등록하기 입력폼 웹 뷰
      *
      * */
    private void webViewinit(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.dewebview),this,getDeliveryStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {

            @JavascriptInterface
            public void map(int state) {
                spap_state = state;//출발지 도착지 구분
                Log.d(TAG, "map : " + spap_state);
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getDeliveryRegisterActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                        selectInternatinl(DOMESTIC);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                        selectInternatinl(OVERSEAS);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
            }

            @JavascriptInterface
            public void message(String message) {
                Log.d(TAG, "messagev : " + message);
                Toast.makeText(getDeliveryRegisterActivity(), message, Toast.LENGTH_SHORT).show();
            }

            @JavascriptInterface
            public void save_file() {
                Log.d(TAG, "save_file");
            }

            @JavascriptInterface
            public void complete_del(String result) {
                Log.d(TAG, "result : " + result);
            }


            @JavascriptInterface
            public void qb_exeption(boolean flag) {
                Log.d(TAG, "qb_exeption : " + flag);

                if (flag) {
                    handler.sendEmptyMessage(5);//로딩 시작
                    if(imageChange){//이미지 변경함
                        Log.d(TAG, "qb_exeption 이미지 변경함 ");
                        deliveryPictureUpload(image_path);
                    }else{
                        Log.d(TAG, "qb_exeption 이미지 변경안함 ");
                        handler.sendEmptyMessage(2);
                    }
                }
            }

            @JavascriptInterface
            public void result(String result) {
                Log.d(TAG, "result : " + result);
                //  handler.sendEmptyMessage(3);//pictureUpload에서 로딩 시작
                handler.sendEmptyMessage(4);//로딩 종료
                if (result.matches("1")) {
                    Toast.makeText(getDeliveryRegisterActivity(), "배송자수정을 완료하였습니다.", Toast.LENGTH_SHORT).show();
                    if(imageChange) {//이미지 변경했을경우
                        handler.sendEmptyMessage(6);
                    }
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    Toast.makeText(getDeliveryRegisterActivity(), "배송자수정을 실패하였습니다.", Toast.LENGTH_SHORT).show();

                }
            }

            @JavascriptInterface
            public void setProfile(String profile_img) {
                profileimage_name = profile_img;
                // profile_img = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + profile_img;
                Log.d(TAG, "profile_img : " + profile_img);
                handler.sendEmptyMessage(3);
                //   setProfileImageView(profile_img);
            }

        }, "quickbird");
    }

    private String getDeliveryStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERYEDIT;
        webUrlStr = webUrlStr + "?delivery_idx=" +delivery_idx;

        Log.d(TAG, "getDeliveryStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 출발지 정보 웹뷰로 보내기
    *
    * */
    private void sendSPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:sp_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }

    /* 도착지 정보 웹뷰로 보내기
    *
    * */
    private void sendAPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:ap_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }

    /* 등록하기
    *
    * */
    private void sendRegister(){
        webViewClass.getWebView().loadUrl("javascript:register();");
    }

    /* 웹 예외처리
    *
    * */
    private void sendExption(){
        webViewClass.getWebView().loadUrl("javascript:qb_exeption();");
    }

    /* 기존 이미지 삭제
    *
    * */
    private void deleteImage(){
        webViewClass.getWebView().loadUrl("javascript:delete_img();");
    }

    /* 이미지 이름 보내기
     *
     * */
    private void sendImageName(String imgName){
        webViewClass.getWebView().loadUrl("javascript:img_insert('" + imgName + "');");
    }

    private void keyboardControll(){
        final KeboardControll softKeyboardDecector = new KeboardControll(this);
        addContentView(softKeyboardDecector, new FrameLayout.LayoutParams(-1, -1));

        softKeyboardDecector.setOnShownKeyboard(new KeboardControll.OnShownKeyboardListener() {

            @Override
            public void onShowSoftKeyboard() {
                //키보드 등장할 때
                Log.d(TAG, "onShowSoftKeyboard : ");

            }
        });

        softKeyboardDecector.setOnHiddenKeyboard(new KeboardControll.OnHiddenKeyboardListener() {

            @Override
            public void onHiddenSoftKeyboard() {
                // 키보드 사라질 때
                Log.d(TAG, "onHiddenSoftKeyboard : ");

            }
        });
    }

    /* 버튼 이벤트
   *
   * */
    private void buttonEvent(){
        Button cancelbtn = (Button)findViewById(R.id.decancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getDeliveryRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        getDeliveryRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });

        //카메라버튼
        Button camerabtn = (Button)findViewById(R.id.decamerabtn);
        camerabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "camerabtn");
                //   devicePicture.doTakeAlbumAction();
                if (devicePermission.checkPermission(getDeliveryRegisterActivity())) {
                    devicePicture.doTakeAlbumAction();
                }
            }
        });

        Button exitbtn = (Button)findViewById(R.id.deexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

         /* 등록하기 버튼
        *
        * */
        Button registerbtn = (Button)findViewById(R.id.deregisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  for(int i=0;i<6;i++) {
                //   new GetData().execute();

                // }
                sendExption();
            }
        });
    }


    private boolean exception(boolean check){

        if(check){
            /*if(!imageChange) {//이미지 변경안함
                check = false;
               // Toast.makeText(getDeliveryRegisterActivity(), "프로필 이미지를 선택해주세요.", Toast.LENGTH_SHORT).show();
            }*/
        }
        return check;
    }

    private void setProfileImageView(String imageUrl){
         // Glide.with(this).load(imageUrl).into(profileImageView);
        Glide.with(this).load(imageUrl)
                .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                .into(profileImageView);

    }

    /* 배송자 사진 업로드
  *
  * */
    private void deliveryPictureUpload(String path){
        //loading.show();
        handler.sendEmptyMessage(5);
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(url, path) {
            @Override
            public void finishUpload(String pictureName) {
                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG, "message : " + jsonObject.getString("message"));
                    profileimage_name = jsonObject.getString("message");
                    handler.sendEmptyMessage(2);
                    //  loading.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                loading.dismiss();
            }
        };//섬네일 이미지 사진업로드
        pu.uploadVideo();
    }

  /*  private void pictureUpload(){
        Log.d(TAG,"profileimage_name : " + profileimage_name);
        String str[][] = {{"file_name",profileimage_name}};
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(profile_img, url, str) {
            @Override
            public void finishUpload(String pictureName) {
                Log.d(TAG, "pictureName : " + pictureName);

                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG,"message : " + jsonObject.getString("message"));
                    profileimage_name = jsonObject.getString("message");
                    //  sendImageName(profileimage_name);
                    //  sendRegister();

                    handler.sendEmptyMessage(2);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                Log.d(TAG,"pictureuload errorCode : " + errorCode);
                loading.dismiss();
            }
        };//섬네일 이미지 사진업로드
        pu.uploadPicture();
    }*/

    /* 국내, 국외 구분 함수
 *
 * */
    private void selectInternatinl(int countryState) {
        if (countryState == DOMESTIC) {
            handler.sendEmptyMessage(0);
        } else if (countryState == OVERSEAS) {
            handler.sendEmptyMessage(1);
        }
    }


    /* 지도 선택 다이얼로그 띄우기
   *
   * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                // btnState = true;
              /*  SelectAddressDialog selectAddressDialog = new SelectAddressDialog(getDeliveryRegisterActivity()) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        if (spap_state == 0) {
                            sendSPpoint(lat, lng, address,DOMESTIC);
                        } else if (spap_state == 1) {
                            sendAPpoint(lat, lng, address,DOMESTIC);
                        }
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();*/
                Intent intent = new Intent(DeliveryEditActivity.this,SelectAddressActivity.class);
                startActivityForResult(intent, SELECT_ADDRESS_MAP);
            }else if(msg.what == 1){
                String[] country;
                Locale[] locales = Locale.getAvailableLocales();

                String[] isoCodes = Locale.getISOCountries();
                country = new String[isoCodes.length];

                for (int i = 0; i < isoCodes.length; i++) {
                    Locale locale = new Locale("en", isoCodes[i]);
                    Log.d(TAG, "country : " + locale.getDisplayCountry());
                    country[i] = locale.getDisplayCountry();
                }
                //나라 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(getDeliveryRegisterActivity(), country);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {

                        String address = selectListDialog.getSubTitleText().getText().toString() + selectListDialog.getSubAddressEdit().getText().toString();
                        Log.d(TAG, "address : " + address);
                        if(spap_state == 0) {
                            sendSPpoint("0", "0", address,OVERSEAS);
                        }else if(spap_state == 1){
                            sendAPpoint("0", "0", address,OVERSEAS);
                        }
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);

                    }
                });
                selectListDialog.getTitleImage().setVisibility(View.GONE);
                selectListDialog.getTitleText().setText("나라 선택");
                selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
                selectListDialog.show();
            } else if(msg.what ==2){
                // loading.dismiss();
                Log.d(TAG,"profileimage_name : " + profileimage_name);
                sendImageName(profileimage_name);
                sendRegister();
            }else if(msg.what ==3){
                //   loading.dismiss();f
                String imgaeurl = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + profileimage_name;
                Log.d(TAG,"imgaeurl : " + imgaeurl);
                setProfileImageView(imgaeurl);
            }else if(msg.what ==4){
                loading.dismiss();
            }else if(msg.what==5){
                loading.show();
            }else if(msg.what == 6){
                deleteImage();
            }
        }
    };

    private DeliveryEditActivity getDeliveryRegisterActivity(){
        return this;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK)
            return;
        Log.d(TAG, "onActivityResult : " + requestCode);

        switch (requestCode){
            case SELECT_ADDRESS_MAP:
            {
                try {
                    Log.d(TAG, "lat : " + data.getStringExtra("lat") + "lng : " + data.getStringExtra("lng") + "address : " + data.getStringExtra("address"));
                    if (spap_state == 0) {
                        sendSPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                    } else if (spap_state == 1) {
                        sendAPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                    }
                }catch (NullPointerException e){
                    Log.d(TAG,"주소검색 : " + e.toString());
                }
                break;
            }
            case PICK_FROM_ALBUM:
            {
                devicePicture.setmImageCaptureUri(data.getData());
               // profile_img = getRealPathFromURI(data.getData());
                image_path = getPath(data.getData());
                profile_img = PictureUpload.reSize(image_path, 200, 200);
                //profileImageView.setImageBitmap(profile_img);
                Bitmap circleBitmap = Bitmap.createBitmap(profile_img.getWidth(), profile_img.getHeight(), Bitmap.Config.ARGB_8888);

                BitmapShader shader = new BitmapShader(profile_img,  Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Paint paint = new Paint();
                paint.setShader(shader);

                Canvas c = new Canvas(circleBitmap);
                c.drawCircle(profile_img.getWidth() / 2, profile_img.getHeight() / 2, profile_img.getWidth() / 2, paint);
                Glide.clear(profileImageView);
                profileImageView.setImageBitmap(circleBitmap);
               // profile_img.recycle();
               // circleBitmap.recycle();
                imageChange = true;
                Log.d(TAG, "PICK_FROM_ALBUM");
            }

            case PICK_FROM_CAMERA:
            {
                devicePicture.pickFromCamera();
                Log.d(TAG, "PICK_FROM_CAMERA");
            }

            case CROP_FROM_iMAGE:
            {
                Log.d(TAG, "CROP_FROM_iMAGE");
                if(resultCode != RESULT_OK){
                    return;
                }
                //  devicePicture.cropFromImage(data,profileImageView);
            }
        }
    }

    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public Bitmap getRealPathFromURI(Uri contentUri) {//실제 경로 반환
        String res = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = this.getContentResolver().query(contentUri, proj, null, null, null);
        if(cursor.moveToFirst()){
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);//실제 uri 주소
        }
        cursor.close();
        return BitmapFactory.decodeFile(res);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
