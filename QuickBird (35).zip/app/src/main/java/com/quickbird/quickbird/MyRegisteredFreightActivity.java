package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import Dialog.ConfirmDialog;
import Dialog.DeliveryAssess.DeliveryAssessInfo;
import Dialog.DeliveryAssess.DeliveryInfo;
import Dialog.DeliveryAssessDialog;
import Dialog.FinishFreightInfo.FinishFreightInfo;
import Dialog.FinishFreightInfoDialog;
import Dialog.Loading;
import Dialog.SelectFourDialog;
import Dialog.SelectThreeDialog;
import Dialog.SelectTwoDialog;
import Picture.CustomBitmapPool;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import jp.wasabeef.glide.transformations.CropCircleTransformation;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-15.
 * 내가 등록한 화물
 */
public class MyRegisteredFreightActivity extends Activity {

    private final String TAG = "MyRegisteredFreight";

    private final int RELOAD_WEBVIEW=3;

    private WebViewClass webViewClass;
    private Loading loading;

    private String freight_idx="";//내 배송자로 지정할 때 저장할 배송자 idx
    private String delivery_idx="";//내화물의 배송자 idx

    private DeliveryAssessInfo deliveryAssessInfo;//배송자 평가하기 정보
    private FinishFreightInfo finishFreightInfo;//배송완료 정보
    private DeliveryInfo deliveryInfo;//배송자 정보

    private boolean changeinfo = false;//정보 수정 체크
    private int cancel_flag = 0;//화물이 배송중 상태 취소권한 여부 1 : 취소가능 0 : 불가능

    private String startState="not_push";//푸쉬로인해 켜진건지
    private boolean topActivityCheck = false; //false : topActivity아님
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myregistered_freight);

        try{
            startState = getIntent().getStringExtra("startState");
            if(startState == null){
                startState = "not_push";
            }
        }catch (Exception e){
            startState = "not_push";
            Log.d(TAG,e.toString());
        }
        String topCheck = getIntent().getStringExtra("topActivity");
        try {
            Log.d(TAG,"topCheck : " + topCheck);
            Log.d(TAG,"getSimpleName : " + this.getClass().getSimpleName());
            if (!topCheck.matches(this.getClass().getPackage().getName())) {
                Log.d(TAG,"topCheck2 : " + topCheck);
                topActivityCheck = true;
            }
        }catch (NullPointerException e){
            topActivityCheck = false;
        }


        loading = new Loading(getMyRegisteredFreightActivity());
        loading.show();
        init();



    }
    
    //내가 등록한 화물 웹뷰 셋팅
    private void init(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.mrfwebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {

            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void my_freight_more(int state, int freightidx, int deliveryidx, int cancelflag) {
                Log.d(TAG, "state : " + state + " freight_idx : " + freightidx + " delivery_idx : " + deliveryidx);
                cancel_flag = cancelflag;
                freight_idx = "" + freightidx;
                delivery_idx = "" + deliveryidx;
                showStateDialog(state);
            }

            @JavascriptInterface
            public void h_list(int state, int view_idx) {
                Log.d(TAG, "view_idx : " + view_idx + " state : " + state);
                Intent intent = new Intent(MyRegisteredFreightActivity.this, FreightInfoDetailActivity.class);
                intent.putExtra("freight_idx", "" + view_idx);
                intent.putExtra("home_flag","1");
                startActivity(intent);
            }
        }, "quickbird");

    }

    /* 내가등록한 화물 url
  *
  * */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.MYREGISTERED_FREIGHT;
        urlStr = urlStr + "?user_type="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        Log.d(TAG, "getUrlStr :" + urlStr);
        return urlStr;
    }

    /* 배송자 평가하기 url
    *
    * */
    private String getDeliveryAssessmentUrlStr(DeliveryAssessInfo deliveryAssessInfo){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_ASSESSMENT;
        urlStr = urlStr + "?delivery_idx="+delivery_idx;
        urlStr = urlStr + "&freight_idx="+freight_idx;
        urlStr = urlStr + "&score="+deliveryAssessInfo.getScore();
        try {
            urlStr = urlStr + "&comment="+URLEncoder.encode(deliveryAssessInfo.getMemo(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return urlStr;
    }

    /* 배송완료 정보 받아오기 url
    *
    * */
    private String getRequestFinishDeliveryinfoUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_DELIVERY_FINSISHINFO;
        urlStr = urlStr + "?freight_idx="+ freight_idx;
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }

    /* 화물 삭제하기 url
    *
    * */
    private String getFreightDeleteUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.FREIGHT_DELETE;
        urlStr = urlStr + "?user_idx="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&freight_idx="+ freight_idx;
        return urlStr;
    }

    /* 배송자 정보 받아오기 url
   *
   * */
    private String getDeliveryInfoUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS +  Conn_Address.REQUEST_DELIVERY_IN;
        urlStr = urlStr + "?delivery_idx=" + delivery_idx;
        return urlStr;
    }

    /* 배송자 지정 취소하기 url
    *
    * */
    private String getCancelDelivery(){
        String urlStr = Conn_Address.SERVER_ADDRESS +  Conn_Address.CANCEL_DELIVERY;
        urlStr = urlStr + "?delivery_idx=" + delivery_idx;
        urlStr = urlStr + "&freight_idx=" + freight_idx;
        Log.d(TAG, " urlStr : " + urlStr);
        return urlStr;
    }

    private void cancelDelivery(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                handler.sendEmptyMessage(5);
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
//                Log.d(TAG, "result : " + result.toString());
                if(flag.matches("1")){
                    //  Log.d(TAG, "DeliveryInfo : " + result.toString());
                    webViewClass.getWebView().reload();
                    Toast.makeText(getMyRegisteredFreightActivity(), "배송자 지정이 취소되었습니다.", Toast.LENGTH_SHORT).show();
                }else{

                }

                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getCancelDelivery());
    }

    /* 배송자 받아오기
    *
    * */
    private void DeliveryInfo(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                handler.sendEmptyMessage(5);
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                deliveryInfo = new DeliveryInfo();
                if(flag.matches("1")){
                  //  Log.d(TAG, "DeliveryInfo : " + result.toString());
                    deliveryInfo.setDelivery_img(result.get(0).get(0));
                    deliveryInfo.setDelivery_name(result.get(1).get(0));
                }else{

                }
                handler.sendEmptyMessage(4);
                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getDeliveryInfoUrlStr());
    }

    /*화물 삭제하기
    *
    * */
    private void freightDelete(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                if(flag.matches("1")){
                    Toast.makeText(getMyRegisteredFreightActivity(),"화물을 삭제하였습니다.",Toast.LENGTH_SHORT).show();
                    changeinfo = true;//정보 바뀜
                    webViewClass.getWebView().reload();

                }else{
                    webViewClass.getWebView().reload();
                    Toast.makeText(getMyRegisteredFreightActivity(),message,Toast.LENGTH_SHORT).show();
                }
                loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getFreightDeleteUrlStr());
    }

    /* 배송완료 정보 받아오기
    *
    * */
    private void requestFinishDeliveryInfo(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                finishFreightInfo = new FinishFreightInfo();
                if(flag.matches("1")){
                    finishFreightInfo.setFreight_image(result.get(0).get(0));
                    finishFreightInfo.setFreight_memo(result.get(1).get(0));
                    finishFreightInfo.setInfo_check(true);
                }else{
                    Toast.makeText(getMyRegisteredFreightActivity(),message,Toast.LENGTH_SHORT).show();
                }
                loading.dismiss();

                showFreightFinishDialog(finishFreightInfo);
            }
        };
        jsonParse.getJsonParse(getRequestFinishDeliveryinfoUrlStr());
    }

    /* 배송완료하기
   *
   * */
    private void updateDeliveryAssessMent(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    Toast.makeText(getMyRegisteredFreightActivity(), "등록되었습니다.", Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(getMyRegisteredFreightActivity(),"실패하였습니다.",Toast.LENGTH_SHORT).show();
                }
               loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getDeliveryAssessmentUrlStr(deliveryAssessInfo));
    }

    /* 배송완료 정보 다이얼로그
    *
    * */
    private void showFreightFinishDialog(FinishFreightInfo finishFreightInfo){
        FinishFreightInfoDialog finishFreightInfoDialog = new FinishFreightInfoDialog(this) {
            @Override
            public void onClickSelect(FinishFreightInfoDialog finishFreightInfoDialog) {

            }

            @Override
            public void onClickCamera(ImageView imageView) {

            }

        };
        // finishFreightInfoDialog.getMemoEdit().setFocusable(false);
        //  finishFreightInfoDialog.getMemoEdit().setClickable(false);
        if(finishFreightInfo.isInfo_check()) {
            finishFreightInfoDialog.getMemoEdit().setText(finishFreightInfo.getFreight_memo());
            String profile_img = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + finishFreightInfo.getFreight_image();
            Log.d(TAG, "profile_img : " + profile_img);
            Glide.with(this).load(profile_img).into(finishFreightInfoDialog.getFreightImage());
        }else{
            finishFreightInfoDialog.getMemoEdit().setText("화물 배송완료 정보가 없습니다.");
        }
        finishFreightInfoDialog.show();
    }

    /* 배송자 평가 다이얼로그
    *
    * */
    private void showDeliveryAssessDialog(){
        DeliveryAssessDialog deliveryAssessDialog = new DeliveryAssessDialog(getMyRegisteredFreightActivity()) {
            @Override
            public void onClickSelect(DeliveryAssessInfo deliveryAssessInfos, DeliveryAssessDialog deliveryAssessDialog) {
                deliveryAssessDialog.dismiss();
                deliveryAssessInfo = deliveryAssessInfos;
                handler.sendEmptyMessage(1);

            }
        };
        String imageurlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + deliveryInfo.getDelivery_img();
        Log.d(TAG,"imageurlStr : " + imageurlStr);
        Log.d(TAG,"delivery_name  : " + deliveryInfo.getDelivery_name());
        Log.d(TAG, "delivery_img  : " + deliveryInfo.getDelivery_img());
        Glide.with(this).load(imageurlStr)
                .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                .into(deliveryAssessDialog.getProfileImageView());
        deliveryAssessDialog.getNameText().setText(deliveryInfo.getDelivery_name());
        deliveryAssessDialog.show();
    }

    /* 배송중 30분지나도 안 받았을 때
    *
    * */
    private void ingDeliveryOver(){
        SelectFourDialog deliveryafter  = new SelectFourDialog(getMyRegisteredFreightActivity()) {
            @Override
            public void clickOneButton(SelectFourDialog selectFourDialog) {
                Intent intent = new Intent(MyRegisteredFreightActivity.this,DeliveryInfoDetailActivity.class);
                intent.putExtra("delivery_idx",""+delivery_idx);
                startActivity(intent);
                selectFourDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectFourDialog selectFourDialog) {
                Log.d(TAG,"내 화물 위치");
                Intent intent = new Intent(MyRegisteredFreightActivity.this,FreightManagementActivity.class);
                intent.putExtra("freight_idx",freight_idx);
                startActivity(intent);
                selectFourDialog.dismiss();
            }

            @Override
            public void clickThreeButton(SelectFourDialog selectFourDialog) {
                DeliveryInfo();
                selectFourDialog.dismiss();
            }

            @Override
            public void clickFourButton(SelectFourDialog selectFourDialog) {
                cancelDelivery();
                selectFourDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        deliveryafter.getSelectOneButton().setText("배송자정보");
        deliveryafter.getSelectTwoButton().setText("내 화물 위치 보기");
        deliveryafter.getSelectThreeButton().setText("배송자평가");
        deliveryafter.getSelectFourButton().setText("배송자 지정 취소");
       // deliveryafter.getSelectFourButton().setVisibility(View.GONE);
        deliveryafter.show();
    }

    private void ingDelivery(){
          SelectThreeDialog deliveryafter = new SelectThreeDialog(this) {
                    @Override
                    public void clickOneButton(SelectThreeDialog selectThreeDialog) {
                        Intent intent = new Intent(MyRegisteredFreightActivity.this,DeliveryInfoDetailActivity.class);
                        intent.putExtra("delivery_idx",""+delivery_idx);
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectThreeDialog selectThreeDialog) {
                        Log.d(TAG,"화물관제");
                        Intent intent = new Intent(MyRegisteredFreightActivity.this,FreightManagementActivity.class);
                        intent.putExtra("freight_idx",freight_idx);
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickThreeButton(SelectThreeDialog selectThreeDialog) {
                        DeliveryInfo();
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                deliveryafter.getSelectOneButton().setText("배송자정보");
                deliveryafter.getSelectTwoButton().setText("내 화물 위치 보기");
                deliveryafter.getSelectThreeButton().setText("배송자평가");
                deliveryafter.show();
    }

    /* 배송 상태에 따라 띄우는 다이얼로그 함수
    *
    * */
    private void showStateDialog(int state){
        switch (state){
            case 0://배송대기
                SelectThreeDialog deliverybefore = new SelectThreeDialog(getMyRegisteredFreightActivity()) {
                    @Override
                    public void clickOneButton(SelectThreeDialog selectThreeDialog) {
                        Intent intent = new Intent(MyRegisteredFreightActivity.this, FreightEditActivity.class);
                        intent.putExtra("freight_idx",freight_idx);

                        startActivityForResult(intent, RELOAD_WEBVIEW);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectThreeDialog selectThreeDialog) {
                        selectThreeDialog.dismiss();
                        ConfirmDialog confirmDialog = new ConfirmDialog(getMyRegisteredFreightActivity()) {
                            @Override
                            public void onClickConfirm(ConfirmDialog confirmDialog) {
                                confirmDialog.dismiss();
                                handler.sendEmptyMessage(3);
                            }

                            @Override
                            public void onClickCancel() {

                            }
                        };
                        confirmDialog.getConfirmBtn().setText("확인");
                        confirmDialog.getCancelBtn().setText("취소");
                        confirmDialog.getTitleText().setText("정말로 삭제를 하시겠습니까?");
                        confirmDialog.show();

                    }

                    @Override
                    public void clickThreeButton(SelectThreeDialog selectThreeDialog) {
                        Intent intent = new Intent(MyRegisteredFreightActivity.this,FrequestDeliveryActivity.class);
                        intent.putExtra("freight_idx",freight_idx);
                        startActivityForResult(intent, RELOAD_WEBVIEW);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                deliverybefore.getSelectOneButton().setText("수정");
                deliverybefore.getSelectTwoButton().setText("삭제");
                deliverybefore.getSelectThreeButton().setText("배송자 선택하기");
                deliverybefore.show();
                break;
            case 1://배송중
                if(cancel_flag == 0) {
                    ingDelivery();//배송자 지정 취소 권한없음
                }else{
                    ingDeliveryOver();//배송자 지정취소 권한 있음
                }
                break;
            case 2://배송완료
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(this) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                        selectTwoDialog.dismiss();
                        handler.sendEmptyMessage(2);
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        DeliveryInfo();
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("배송상태확인");
                selectTwoDialog.getSelectTwoButton().setText("배송자 평가");
                selectTwoDialog.show();
                /*SelectOneDialog selectOneDialog = new SelectOneDialog(this) {
                    @Override
                    public void clickOneButton(SelectOneDialog selectOneDialog) {
                        selectOneDialog.dismiss();
                        handler.sendEmptyMessage(2);
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectOneDialog.getSelectOneButton().setText("화물 배송완료 정보");
                selectOneDialog.show();*/
                break;
        }
    }

    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.dismiss();
            }else if(msg.what==1){
                updateDeliveryAssessMent();
            }else if(msg.what == 2) {
                requestFinishDeliveryInfo();
            }else if(msg.what == 3){
                freightDelete();
            }else if(msg.what == 4){
                showDeliveryAssessDialog();
            }else if(msg.what == 5){
                loading.show();
            }
        }
    };

    private MyRegisteredFreightActivity getMyRegisteredFreightActivity(){
        return this;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult : " + requestCode);
        if(resultCode != RESULT_OK)
            return;

        switch (requestCode) {
            case RELOAD_WEBVIEW:{
                changeinfo = true;//정보 바뀜
                webViewClass.getWebView().reload();
                break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if(startState.matches("not_push")){//푸시로 화면이 실행안된경우
            super.onBackPressed();
        }else{//푸시로 실행된경우
            if(topActivityCheck) {
                BackPressClose backPressClose = new BackPressClose(this);
                backPressClose.BackActivity(this, IntroActivity.class);
            }else{

            }
        }

        if(changeinfo) {
            setResult(RESULT_OK);
        }else{
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
}
