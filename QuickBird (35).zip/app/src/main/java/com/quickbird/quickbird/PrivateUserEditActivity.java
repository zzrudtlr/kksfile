package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import Database.DB_SingleTon;
import Dialog.Loading;
import Filter.Filter;
import Register.ImageIcon;
import UserInfo.PrivateUserInfo;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-13.
 * 개인 회원 정보수정
 */
public class PrivateUserEditActivity extends Activity {

    private final String TAG = "PrivateUserEditActivity";

    public final int ICON_EMAIL = 0;
    public final int ICON_NAME = 1;
    public final int ICON_PHONE = 2;
    public final int ICON_CERTIFY = 3;
    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();//아이콘 및 텍스트정보를 담고있는 변수

    private PrivateUserInfo privateUserInfo;//유저 정보
    private Loading loading;

    private boolean phone_overlap = false;//휴대폰 중복 체크


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_userinfo_edit);
        init();
    }

    private void init(){
        loading = new Loading(this);
        privateUserInfo = new PrivateUserInfo();
        imageIconinit();
        buttonEvent();//버튼 이벤트
        editTextEvent();//edtidText focus 이벤트
        requestUserInfo();//유저정보 받아오기
    }

    private void buttonEvent(){
        //정보수정 버튼
        Button infoeditbtn = (Button)findViewById(R.id.pueInfoeditbtn);
        infoeditbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(exception()){
                    Log.d(TAG, "정보수정");
                    updateUserInfo();
                }
            }
        });

        //휴대폰 번호 인증
        Button phonebtn = (Button)findViewById(R.id.pueCertifiiybtn);
        phonebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone_overlap = true;
                Toast.makeText(PrivateUserEditActivity.this,"본인인증을 하였습니다.",Toast.LENGTH_SHORT).show();
            }
        });

        //취소 버튼
        Button cancelbtn = (Button)findViewById(R.id.pueCancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "취소");
                finish();
            }
        });
    }

    /* 아이콘 초기화
  *
  * */
    private void imageIconinit(){

        //이메일 아이디 아이콘
        ImageIcon emaildIcon = new ImageIcon();
        emaildIcon.setEditText((EditText) findViewById(R.id.pueEmailidText));
        emaildIcon.getEditText().setFilters(new InputFilter[]{Filter.filterAlphaNum});
        emaildIcon.setView((ImageView) findViewById(R.id.pueEmailidImage));
        emaildIcon.setImageId(ICON_EMAIL);
        emaildIcon.setSetOnImage(R.drawable.icon_email_on);
        emaildIcon.setSetOffImage(R.drawable.icon_email_off);
        imageIcons.add(emaildIcon);

        //이름  아이콘
        ImageIcon nameIcon = new ImageIcon();
        ImageView nameImage = (ImageView)findViewById(R.id.pueNameImage);
        nameIcon.setView(nameImage);
        nameIcon.setEditText((EditText) findViewById(R.id.pueNameText));
        nameIcon.setImageId(ICON_NAME);
        nameIcon.setSetOnImage(R.drawable.icon_user_on);
        nameIcon.setSetOffImage(R.drawable.icon_user_off);
        imageIcons.add(nameIcon);

        //폰 아이콘
        ImageIcon imageIcon = new ImageIcon();
        ImageView phoneIconImage = (ImageView)findViewById(R.id.puePhoneImage);
        imageIcon.setView(phoneIconImage);
        imageIcon.setEditText((EditText) findViewById(R.id.puePhoneText));
        imageIcon.setImageId(ICON_PHONE);
        imageIcon.setSetOnImage(R.drawable.icon_phone_on);
        imageIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(imageIcon);

        //폰 인증 아이콘
        ImageIcon phonecertifyIcon = new ImageIcon();
        ImageView phonecertifyIconImage = (ImageView)findViewById(R.id.pCertifyIconimage);
        phonecertifyIcon.setView(phonecertifyIconImage);
        phonecertifyIcon.setEditText((EditText) findViewById(R.id.pCertifiyNumberText));
        phonecertifyIcon.setImageId(ICON_CERTIFY);
        phonecertifyIcon.setSetOnImage(R.drawable.icon_phone_on);
        phonecertifyIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(phonecertifyIcon);

    }

    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
    *
    * */
    private void editTextEvent(){

        for(int i=0;i<imageIcons.size();i++) {
            try {
                imageIcons.get(i).getEditText().setId(imageIcons.get(i).getImageId());
                imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        if (hasFocus) {
                            imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                        } else {
                            imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                        }
                    }
                });
            }catch (NullPointerException e){
                Log.d(TAG,"i : " + i);
            }
        }
    }

    /* 회원 정보 수정
    *
    * */
    private void updateUserInfo(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    Toast.makeText(getPrivateUserEditActivity(),"회원정보가 수정 되었습니다.",Toast.LENGTH_SHORT).show();
                } else {
                    Log.d(TAG,"회원정보 수정에 실패 했습니다");
                    Toast.makeText(getPrivateUserEditActivity(),"회원정보 수정에 실패 했습니다.",Toast.LENGTH_SHORT).show();
                }
            }
        };
        jsonParse.getJsonParse(getUpdateUserUrlStr());
    }

    /* 유저정보 받아오기
    *
    * */
    private void requestUserInfo(){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    imageIcons.get(ICON_EMAIL).getEditText().setHint(result.get(0).get(0));//이메일
                    imageIcons.get(ICON_NAME).getEditText().setText(result.get(1).get(0));//이름
                    imageIcons.get(ICON_PHONE).getEditText().setText(result.get(2).get(0));//휴대폰
                    privateUserInfo.setEmailid(result.get(0).get(0));
                    privateUserInfo.setName(result.get(1).get(0));
                    privateUserInfo.setPhone_number(result.get(2).get(0));
                    privateUserInfo.setProfile_img(result.get(3).get(0));
                    privateUserInfo.setUser_type(result.get(4).get(0));
                } else {
                    Log.d(TAG,"정보를 받아오는데 실패했습니다.");
                }
            }
        };
        jsonParse.getJsonParse(getRegisterUrlStr());
    }



    /* 회원정보 받아오기 주소 값
    *
    * */
    private String getRegisterUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.REQUEST_PRIVATEUSERINFO;
        urlStr = urlStr + "?user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();

        return urlStr;
    }

    /* 회원정보 수정 주소 값
    *
    * */
    private String getUpdateUserUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.PRIVATEUSERINFO_UPDATE;
        urlStr = urlStr + "?name=" + imageIcons.get(ICON_NAME).getEditText().getText().toString();
        urlStr = urlStr + "&phone=" +imageIcons.get(ICON_PHONE).getEditText().getText().toString();
        urlStr = urlStr + "&profile_img=" + privateUserInfo.getProfile_img();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();

        return urlStr;
    }

    /* EditText 예외처리
    *
    * */
    private boolean exception(){
        boolean check = true;
        for(int i=0;i<imageIcons.size();i++){
            if(imageIcons.get(i).getEditText().getText().toString().matches("")){//빈공간 예외처리
                check = false;
                imageIcons.get(i).getEditText().requestFocus();
                Toast.makeText(this, "빈 공간을 채워주세요.", Toast.LENGTH_SHORT).show();
                break;
            }
        }

        if(check){
            if(!phoneExecption()){
                check = false;
            }
        }
        return check;
    }

    //휴대폰 예외
    private boolean phoneExecption(){
        boolean check = true;
        Log.d(TAG," ICON_PHONE : " + imageIcons.get(ICON_PHONE).getEditText().getText().toString());
        if(!imageIcons.get(ICON_PHONE).getEditText().getText().toString().equals(privateUserInfo.getPhone_number()) && !phone_overlap){
            Toast.makeText(this, "휴대폰 인증을 해주세요.", Toast.LENGTH_SHORT).show();
            check = false;
        }
        return check;
    }

    private PrivateUserEditActivity getPrivateUserEditActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
