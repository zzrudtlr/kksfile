package com.quickbird.quickbird;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ActionMenuView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewSwitcher;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import Database.DB_SingleTon;
import Dialog.ConfirmDialog;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Gps.GpsInfo;
import Permission.DevicePermission;
import Picture.DevicePicture;
import Picture.MultiplePicture.Action;
import Picture.MultiplePicture.CustomGallery;
import Picture.MultiplePicture.CustomGalleryAdapter;
import Picture.PictureUpload;
import WebView.WebViewClass;
import WebView.KeboardControll;
import connection.AppNetWrok;
import connection.Conn_Address;
import WebView.OnWebViewClientListener;

/**
 * Created by KyoungSik on 2017-03-30.
 * 화물 등록
 */
public class FreightRegisterActivity extends Activity {

    private final String TAG = "FreightRegisterActivity";

    private final int galleryItemWidth = 300;//그리드 뷰 아이템 기본 크기

    private final int APP_PERMISSION_STORAGE = 0;
    private final int SELECT_PICTURE=1;
    private final int SELECT_MOVIE = 2;
    private final int SELECT_CAPTURE = 3;

    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;
    public final int SELECT_ADDRESS_MAP=4;
    private final int MAXVIDEOSECONDS = 5;

    private int spap_state=0;//출발지 도착지 구분

    private int statePv;//이미지 동영상 구분
    private boolean pm_permission = false;//이미지 및 동영상 업로드 가능 여부


    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;
    private LinearLayout no_select_linear;//사진 및 동영상 첨무 안되 있을떄 보여주는 view

    private GridView gridGallery;
    private CustomGalleryAdapter adapter;
    private ArrayList<String> imagePaths;

    private ViewSwitcher viewSwitcher;//이미지뷰들과와 동영상뷰를 담은 뷰
    private VideoView videoView;//동영상보여주는 view
    private ImageLoader imageLoader;

    private String uploadImageName="";
    private int imageUploadCount = 0;

    private LinearLayout pvLienar;

    private String video_path;
    private boolean imgvideoSelected = false;

    private DevicePermission devicePermission;//접근허용

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freight_register);
        initImageLoader();
        init();
    }

    private void init(){
        loading = new Loading(this);
        imagePaths = new ArrayList<String>();
        errorView = (LinearLayout)findViewById(R.id.fr_errorview);
        no_select_linear = (LinearLayout)findViewById(R.id.no_select_linear);
      //  devicePicture = new DevicePicture(this);

        gridGallery = (GridView) findViewById(R.id.gridGallery);
        gridGallery.setFastScrollEnabled(true);
        adapter = new CustomGalleryAdapter(getApplicationContext(), imageLoader);
        adapter.setMultiplePick(false);

        gridGallery.setAdapter(adapter);

      /*  gridGallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(FreightRegisterActivity.this, "" + imagePaths.get(i), Toast.LENGTH_LONG).show();

            }
        });*/

        viewSwitcher = (ViewSwitcher) findViewById(R.id.viewSwitcher);

        pvLienar = (LinearLayout)findViewById(R.id.pvlienar);
        viewSwitcher.setDisplayedChild(0);

        devicePermission = new DevicePermission();
        videoViewinit();
        webViewinit();
        buttonEvent();
        keyboardControll();

    }

    private MediaPlayer.OnVideoSizeChangedListener onVideoSizeChangedListener =
            new MediaPlayer.OnVideoSizeChangedListener() {
        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                    500);
            lp.gravity = Gravity.CENTER;
              videoView.setLayoutParams(lp);

            }
        };


    /* 비디오 뷰 초기화
    *
    * */
    private void videoViewinit(){
        videoView = (VideoView)findViewById(R.id.frvideoView);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setOnVideoSizeChangedListener(onVideoSizeChangedListener);

                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                        500);
                lp.gravity = Gravity.CENTER;
                videoView.setLayoutParams(lp);

                // 재생시간표시...msec
                Log.d("test", "onPrepared getDuration = " + mp.getDuration());
                int totalSeconds = mp.getDuration() / 1000;
                int seconds = totalSeconds % 60;
                if (MAXVIDEOSECONDS < seconds) {
                    Toast.makeText(getFreightRegisterActivity(), "동영상 길이는 최대 5초입니다.", Toast.LENGTH_SHORT).show();
                    pm_permission = false;
                } else {
                    pm_permission = true;
                }
            }
        });
        /*viewSwitcher.setDisplayedChild(1);
        String video_url = "http://lbcontents.com/quickbird/img/146153008242143.avi";
        Uri uri = Uri.parse(video_url);
        videoView.setVideoURI(uri);
        videoView.requestFocus();
        videoView.start();*/
    }

    private void initImageLoader() {
        // for universal image loader
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisc().imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
                .bitmapConfig(Bitmap.Config.RGB_565).build();
        ImageLoaderConfiguration.Builder builder = new ImageLoaderConfiguration.Builder(
                this).defaultDisplayImageOptions(defaultOptions).memoryCache(
                new WeakMemoryCache());

        ImageLoaderConfiguration config = builder.build();
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(config);
    }

    //동영상 상태 선택
    private void selectMovie(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                doFilmingMovie();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                doSelectMovie();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("동영상 촬영");
        selectTwoDialog.getSelectTwoButton().setText("동영상 앨범");
        selectTwoDialog.show();
    }

    //동영상 촬영하기
    private void doFilmingMovie(){
        //내장카메라 호출
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        //동영상 품질
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        //동영상 시간 제한
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 5);// 시간
        //동영상 용량 제한
        intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, (long) (1024 * 1024 * 4));// 용량
        //동영상 저장 경로
        String mImageMovieUri = "/sdcard/Download/exam/";
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
                mImageMovieUri);
        startActivityForResult(intent, SELECT_MOVIE);
    }

    //동영상선택
    private void doSelectMovie(){
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try{
            startActivityForResult(i, SELECT_MOVIE);
        }catch (android.content.ActivityNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    //이미지 촬영 후 가져오기
    private void doImagePicture(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, SELECT_CAPTURE);

    }

    //사진 상태 선택하기
    private void selectPicture(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
               // doFilmingMovie();
                doImagePicture();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                startActivityForResult(i, 200);
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("이미지 촬영");
        selectTwoDialog.getSelectTwoButton().setText("이미지 앨범");
        selectTwoDialog.show();
    }

    private void keyboardControll(){
        final KeboardControll softKeyboardDecector = new KeboardControll(this);
        addContentView(softKeyboardDecector, new FrameLayout.LayoutParams(-1, -1));

        softKeyboardDecector.setOnShownKeyboard(new KeboardControll.OnShownKeyboardListener() {

            @Override
            public void onShowSoftKeyboard() {
                //키보드 등장할 때
                Log.d(TAG, "onShowSoftKeyboard : ");

            }
        });

        softKeyboardDecector.setOnHiddenKeyboard(new KeboardControll.OnHiddenKeyboardListener() {

            @Override
            public void onHiddenSoftKeyboard() {
                // 키보드 사라질 때
                Log.d(TAG, "onHiddenSoftKeyboard : ");

            }
        });
    }

    /* 버튼 이벤트
   *
   * */
    private void buttonEvent(){
        Button cancelbtn = (Button)findViewById(R.id.frcancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getFreightRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        Intent intent = new Intent();
                        setResult(RESULT_OK, intent);
                        getFreightRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });
        Button exitbtn = (Button)findViewById(R.id.frexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //사진 및 동영상 선택 버튼
        Button picturemovebtn = (Button)findViewById(R.id.frpvbtn);
        picturemovebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       // viewSwitcher.setDisplayedChild(0);
                    if (devicePermission.checkPermission(getFreightRegisterActivity())) {
                            statePv = SELECT_PICTURE;//사진 업로드 상태
                            //Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                            //startActivityForResult(i, 200);
                            selectPicture();

                        }

                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        if (devicePermission.checkPermission(getFreightRegisterActivity())) {
                            statePv = SELECT_MOVIE;//동영상 업로드 상태
                            selectMovie();//동영상 상태 선택
                        }
                      //  viewSwitcher.setDisplayedChild(1);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("이미지");
                selectTwoDialog.getSelectTwoButton().setText("동영상");
                selectTwoDialog.show();
            }
        });

        /* 등록하기 버튼
        *
        * */
        Button registerbtn = (Button)findViewById(R.id.frregisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  sendRegister();
                sendExption();
            }
        });

    }
    /* 배송자 등록하기 입력폼 웹 뷰
   *
   * */
    private void webViewinit(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.frwebview),this,getFreightStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });


        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void map(int state) {
                spap_state = state;//출발지 도착지 구분
                Log.d(TAG, "map");
                GpsInfo gpsInfo = new GpsInfo(getFreightRegisterActivity());
                if (gpsInfo.isGetLocation()) {
                    SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
                        @Override
                        public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                            selectInternatinl(DOMESTIC);
                            selectTwoDialog.dismiss();
                        }

                        @Override
                        public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                            selectInternatinl(OVERSEAS);
                            selectTwoDialog.dismiss();
                        }

                        @Override
                        public void clickCancelButton() {

                        }
                    };
                    selectTwoDialog.getSelectOneButton().setText("국내");
                    selectTwoDialog.getSelectTwoButton().setText("국외");
                    selectTwoDialog.show();
                }else {
                    Toast.makeText(getFreightRegisterActivity(), "GPS 정보를 켜주세요.", Toast.LENGTH_SHORT).show();
                    gpsInfo.showSettingsAlert();
                }
                //  handler.sendEmptyMessage(0);

            }

            @JavascriptInterface
            public void message(String message) {
                Log.d(TAG, "messagev : " + message);
                Toast.makeText(getFreightRegisterActivity(), message, Toast.LENGTH_SHORT).show();
            }

            @JavascriptInterface
            public void save_file() {
                Log.d(TAG, "save_file");
            }

            @JavascriptInterface
            public void qb_exeption(boolean flag) {
                Log.d(TAG, "qb_exeption : " + flag);
                if (exception(flag)) {
                    if (AppNetWrok.networkCheck(getFreightRegisterActivity())) {
                        if (statePv == SELECT_PICTURE) {
                            Log.d(TAG, "SELECT_PICTURE : ");
                            fregithPitureUpload();
                        } else if (statePv == SELECT_MOVIE) {
                            fregithVideoUpload(video_path);
                        }
                    } else {
                        Toast.makeText(getFreightRegisterActivity(), "네트워크를 확인해주세요.", Toast.LENGTH_SHORT).show();
                    }
                }
            }


            @JavascriptInterface
            public void result(String result) {
                Log.d(TAG, "result : " + result);

                  handler.sendEmptyMessage(3);//pictureUpload에서 로딩 시작
                if (result.contains("1")) {
                    Toast.makeText(getFreightRegisterActivity(), "화물등록을 완료하였습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    Toast.makeText(getFreightRegisterActivity(), "화물등록을 실패하였습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        }, "quickbird");
    }

    //이미지 및 동영상 예외처리 여부부
   private boolean exception(boolean check){

        if(check){
            if(!imgvideoSelected) {
                check = false;
                Toast.makeText(getFreightRegisterActivity(), "이미지 및 동영상을 선택해 주세요", Toast.LENGTH_SHORT).show();
            }else if((statePv == SELECT_MOVIE) && !pm_permission){
                check = false;
                Toast.makeText(getFreightRegisterActivity(), "동영상은 최대 5초입니다.", Toast.LENGTH_SHORT).show();
            }
        }
        return check;
    }

    /* 국내, 국외 구분 함수
  *
  * */
    private void selectInternatinl(int countryState) {
        if (countryState == DOMESTIC) {
            handler.sendEmptyMessage(0);
        } else if (countryState == OVERSEAS) {
            handler.sendEmptyMessage(1);
        }
    }

    private String getFreightStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.FREIGHT_WRITE;
        webUrlStr = webUrlStr + "?user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        webUrlStr = webUrlStr + "&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        Log.d(TAG,"getFreightStr : " + webUrlStr);
        return webUrlStr;
    }

    public FreightRegisterActivity getFreightRegisterActivity(){
        return this;
    }


    /* 출발지 정보 웹뷰로 보내기
    *
    * */
    private void sendSPpoint(String lng, String lat, String address,int state) {
        webViewClass.getWebView().loadUrl("javascript:sp_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }


    /* 도착지 정보 웹뷰로 보내기
    *
    * */
    private void sendAPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:ap_point(" + lng + "," + lat + ",'" + address + "',"+state+");");
    }

    /* 등록하기
     *
     * */
    private void sendRegister(){
        webViewClass.getWebView().loadUrl("javascript:register();");
    }

    /* 웹 예외처리
    *
    * */
    private void sendExption(){
        webViewClass.getWebView().loadUrl("javascript:qb_exeption();");
    }

    /* 이미지 이름 보내기
   *
   * */
    private void sendImageName(String imgName){
        webViewClass.getWebView().loadUrl("javascript:img_insert('"+imgName+"');");
    }

    /* 동영상 이름 보내기
   *
   * */
    private void sendVideoName(String videoName){
        webViewClass.getWebView().loadUrl("javascript:video_insert('" + videoName + "');");
    }


    /* 지도 선택 다이얼로그 띄우기
    *
    * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            // btnState = true;
            if(msg.what == 0) {
              /*  SelectAddressDialog selectAddressDialog = new SelectAddressDialog(getFreightRegisterActivity()) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        if (spap_state == 0) {
                            sendSPpoint(lng, lat, address,DOMESTIC);
                        } else if (spap_state == 1) {
                            sendAPpoint(lng, lat, address,DOMESTIC);
                        }
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();*/
                Intent intent = new Intent(FreightRegisterActivity.this,SelectAddressActivity.class);
                startActivityForResult(intent, SELECT_ADDRESS_MAP);
            }else if(msg.what == 1){
                String[] country;
                Locale[] locales = Locale.getAvailableLocales();

                String[] isoCodes = Locale.getISOCountries();
                country = new String[isoCodes.length];

                for (int i = 0; i < isoCodes.length; i++) {
                    Locale locale = new Locale("en", isoCodes[i]);
                    Log.d(TAG, "country : " + locale.getDisplayCountry());
                    country[i] = locale.getDisplayCountry();
                }
                //나라 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(getFreightRegisterActivity(), country);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                        String address = selectListDialog.getSubTitleText().getText().toString()+" "+selectListDialog.getSubAddressEdit().getText().toString();
                        if(spap_state == 0) {
                            sendSPpoint("0","0",address,OVERSEAS);
                        }else if(spap_state == 1){
                            sendAPpoint("0","0",address,OVERSEAS);
                        }
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);

                    }
                });
                selectListDialog.getTitleImage().setVisibility(View.GONE);
                selectListDialog.getTitleText().setText("나라 선택");
                selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
                selectListDialog.show();
            }else if(msg.what ==2){
                loading.show();
            }else if(msg.what == 3){
                loading.dismiss();
            }
        }
    };

    /* 화물 이미지들 업로드
    *
    * */
    private void fregithPitureUpload(){
       // loading.show();

        handler.sendEmptyMessage(2);
        uploadImageName = "";//이미지 이름 초기화
        imageUploadCount = 0;//이미지 업로드 카운트 초기화
        if(imagePaths.size() <= 0){
          //  loading.dismiss();

            handler.sendEmptyMessage(3);//pictureUpload에서 로딩 시작
            return;
        }
        Iterator<String> itr = imagePaths.iterator();
        Log.d(TAG, "Iterator : " + imagePaths.size());
        while(itr.hasNext()){
            String str[][] = {{"fileName", ""},{"target_dir","image/"}};
            String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
            Log.d(TAG, "url : " + url);
            PictureUpload pu = new PictureUpload(url,itr.next()) {
                @Override
                public void finishUpload(String pictureName) {
                    try {
                        Log.d(TAG, "pictureName : " + pictureName);
                        JSONObject jsonObject = new JSONObject(pictureName);
                        Log.d(TAG, "flag : " + jsonObject.getString("flag"));
                        Log.d(TAG, "message : " + jsonObject.getString("message"));
                        if(jsonObject.getString("flag").matches("1")){
                            makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                        }
                        uploadCount();//업로드된 이미지 갯수 체크
                        Log.d(TAG, "imageUploadCount : " + imageUploadCount + " imagePaths.size() : " + imagePaths.size());
                        if(imageUploadCount == imagePaths.size()){//모든 이미지 업로드 완료
                            Log.d(TAG, "imageUploadCount : " + imageUploadCount + " imagePaths.size() : " + imagePaths.size());
                            Log.d(TAG, "uploadImageName : " + uploadImageName);
                            sendImageName(uploadImageName);
                            sendRegister();
                       //   loading.dismiss();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG, "finishUpload : ");
                }

                @Override
                public void errorUpload(String errorCode) {
                  //  loading.dismiss();
                    handler.sendEmptyMessage(3);
                }
            };//섬네일 이미지 사진업로드
            pu.uploadVideo();
        }
    }

    /* 화물 이미지들 업로드
    *
    * */
    /*private void fregithPitureUpload(){
        loading.show();
        uploadImageName = "";//이미지 이름 초기화
        imageUploadCount = 0;//이미지 업로드 카운트 초기화
        Iterator<String> itr = imagePaths.iterator();
        while(itr.hasNext()){
            String str[][] = {{"fileName", ""},{"target_dir","image/"}};
            String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
            PictureUpload pu = new PictureUpload(PictureUpload.reSize(itr.next(), 100, 100), url, str) {
                @Override
                public void finishUpload(String pictureName) {
                    try {
                        JSONObject jsonObject = new JSONObject(pictureName);
                        Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                        Log.d(TAG, "message : " + jsonObject.getString("message"));
                        if(jsonObject.getString("flag").matches("1")){
                            makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                        }
                        uploadCount();//업로드된 이미지 갯수 체크
                        if(imageUploadCount == imagePaths.size()){//모든 이미지 업로드 완료
                            sendImageName(uploadImageName);
                            sendRegister();
                       //     loading.dismiss();

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void errorUpload(String errorCode) {
                    loading.dismiss();
                }
            };//섬네일 이미지 사진업로드
            pu.uploadPicture();
        }
    }*/

    /* 화물 동영상 업로드
    *
    * */
    private void fregithVideoUpload(String path){
           // loading.show();
        handler.sendEmptyMessage(2);
            String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADVIDEO;
            PictureUpload pu = new PictureUpload(url, path) {
                @Override
                public void finishUpload(String pictureName) {
                    try {
                        JSONObject jsonObject = new JSONObject(pictureName);
                        Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                        Log.d(TAG, "message : " + jsonObject.getString("message"));
                        if(jsonObject.getString("flag").matches("1")){
                            makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                        }
                        Log.d(TAG,"uploadImageName : " + uploadImageName);
                        sendVideoName(uploadImageName);
                        sendRegister();
                      //  loading.dismiss();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void errorUpload(String errorCode) {
                   // loading.dismiss();
                    handler.sendEmptyMessage(3);
                }
            };//섬네일 이미지 사진업로드
            pu.uploadVideo();

    }

    /* 업로드된 이미지 카운트
    *
    * */
    private void uploadCount(){
        imageUploadCount++;
    }
    /* 이미지 이름 스플릿으로 만들기
    *
    * */
    private void makeSplitImageName(String profileName){
        if(uploadImageName.equals("")){
            uploadImageName = profileName;
        }else{
            uploadImageName = uploadImageName + "/" + profileName;
        }
        Log.d(TAG,"uploadImageName : " + uploadImageName);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

         if (requestCode == 200 && resultCode == Activity.RESULT_OK) {

            String[] all_path = data.getStringArrayExtra("all_path");
            float scale = this.getBaseContext().getResources().getDisplayMetrics().density;
            int dp = (int)(300/scale)*all_path.length;

             //그리드 뷰 아이템 개수에 따라 크기 설정
          //  LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(galleryItemWidth*all_path.length, LinearLayout.LayoutParams.WRAP_CONTENT);
            //gridGallery.setNumColumns(all_path.length);
            //gridGallery.setLayoutParams(gridParams);

            imagePaths.clear();

            ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
            for (String string : all_path) {
                CustomGallery item = new CustomGallery();
                item.sdcardPath = string;
                imagePaths.add(string);

                dataT.add(item);
            }
             if(imagePaths.size()!=0) {
                 viewSwitcher.setDisplayedChild(0);
                 no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                 adapter.addAll(dataT);
                 imgvideoSelected = true;
                 Log.d(TAG, "imagePaths : " + imagePaths.size());
             }
        }else if(requestCode == SELECT_CAPTURE){//사진 촬영후 이미지 가져오기
             imagePaths.clear();
             try {
                 Uri uri = data.getData();
                 String imagePath = getPath(uri);
                 ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
                 CustomGallery item = new CustomGallery();
                 item.sdcardPath = imagePath;
                 imagePaths.add(imagePath);
                 dataT.add(item);
                 viewSwitcher.setDisplayedChild(0);
                 no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                 adapter.addAll(dataT);
                 imgvideoSelected = true;
             }catch (NullPointerException e){
                 Log.d(TAG,e.toString());
             }
         } else if(requestCode == APP_PERMISSION_STORAGE){
            Log.d(TAG, "APP_PERMISSION_STORAGE");
             if(statePv == SELECT_PICTURE) {
                 Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                 startActivityForResult(i, 200);
             }else{
                 doSelectMovie();
             }
        }else if(requestCode == SELECT_MOVIE){
            try {
                Uri uri = data.getData();
              /*  String path2 = Environment.getExternalStorageDirectory()
                        + "/TestVidio6.mp4";*/

                Log.d(TAG, "video url : " + uri.toString());
                Log.d(TAG, "video path : " + getPath(uri));
                video_path = "";
                if (getPath(uri) == null) {
                    Toast.makeText(this, "동영상은 갤러리에서 선택을 해주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    video_path = getPath(uri);
                    videoView.setVideoURI(uri);
                    viewSwitcher.setDisplayedChild(1);
                    no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                    imgvideoSelected = true;
                }


//content://com.android.providers.media.documents/document/video%3A17383
                videoView.start();
            }catch (NullPointerException e){
                Log.d(TAG,e.toString());
            }

        }else if(requestCode == SELECT_ADDRESS_MAP) {//국내 주소 선택
             try {
                 Log.d(TAG, "lat : " + data.getStringExtra("lat") + "lng : " + data.getStringExtra("lng") + "address : " + data.getStringExtra("address"));
                 if (spap_state == 0) {
                     sendSPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                 } else if (spap_state == 1) {
                     sendAPpoint(data.getStringExtra("lng"), data.getStringExtra("lat"), data.getStringExtra("address"), DOMESTIC);
                 }
             }catch (NullPointerException e){
                 Log.d(TAG,"주소검색 : " + e.toString());
             }
         }

    }
    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        cursor.close();
        return cursor.getString(column_index);
    }

}
