package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import Dialog.ConfirmDialog;
import Dialog.Loading;
import Filter.Filter;
import Register.ImageIcon;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-06.
 * 개인 회원가입
 */
public class PrivateUserRegisterActivity extends Activity {

    private final String TAG = "PrivateUserRegister";

    public final int ICON_EMAIL = 0;
    public final int ICON_PW = 1;
    public final int ICON_CHECKPW = 2;
    public final int ICON_NAME = 3;
    public final int ICON_PHONE = 4;
    public final int ICON_CERTIFY = 5;

    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();

    private Loading loading;

    private boolean emailid_overlap = false;//아이디 중복 체크
    private boolean phone_overlap = false;//휴대폰 중복 체크
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privateuser_register);
        init();
    }

    private void init(){

        loading = new Loading(this);
        imageIconinit();
        buttonEvent();
        editTextEvent();
    }

    /* 아이콘 초기화
    *
    * */
    private void imageIconinit(){

        //이메일 아이디 아이콘
        ImageIcon emaildIcon = new ImageIcon();
        emaildIcon.setEditText((EditText)findViewById(R.id.pEmailidText));
        emaildIcon.setImageId(ICON_EMAIL);
        emaildIcon.getEditText().setFilters(new InputFilter[]{Filter.filterAlphaNum});
        emaildIcon.setView((ImageView)findViewById(R.id.pEmailIconimage));
        emaildIcon.setSetOnImage(R.drawable.icon_email_on);
        emaildIcon.setSetOffImage(R.drawable.icon_email_off);
        imageIcons.add(emaildIcon);

        //비밀번호  아이콘
        ImageIcon pwIcon = new ImageIcon();
        ImageView pwImage = (ImageView)findViewById(R.id.pPwIconimage);
        pwIcon.setView(pwImage);
        pwIcon.setEditText((EditText) findViewById(R.id.pPwText));
        pwIcon.setImageId(ICON_PW);
        pwIcon.setSetOnImage(R.drawable.icon_lock_on);
        pwIcon.setSetOffImage(R.drawable.icon_lock_off);
        imageIcons.add(pwIcon);


        //비밀번호 확인  아이콘
        ImageIcon checkpwIcon = new ImageIcon();
        ImageView checkpwImage = (ImageView)findViewById(R.id.pCheckPwIconimage);
        checkpwIcon.setView(checkpwImage);
        checkpwIcon.setEditText((EditText)findViewById(R.id.pCheckPwText));
        checkpwIcon.setImageId(ICON_CHECKPW);
        checkpwIcon.setSetOnImage(R.drawable.icon_lock_on);
        checkpwIcon.setSetOffImage(R.drawable.icon_lock_off);
        imageIcons.add(checkpwIcon);

        //이름  아이콘
        ImageIcon nameIcon = new ImageIcon();
        ImageView nameImage = (ImageView)findViewById(R.id.pNameIconimage);
        nameIcon.setView(nameImage);
        nameIcon.setEditText((EditText)findViewById(R.id.pNameText));
        nameIcon.setImageId(ICON_NAME);
        nameIcon.setSetOnImage(R.drawable.icon_user_on);
        nameIcon.setSetOffImage(R.drawable.icon_user_off);
        imageIcons.add(nameIcon);

        //폰 아이콘
        ImageIcon imageIcon = new ImageIcon();
        ImageView phoneIconImage = (ImageView)findViewById(R.id.pPhoneIconImage);
        imageIcon.setView(phoneIconImage);
        imageIcon.setEditText((EditText)findViewById(R.id.pPhoneText));
        imageIcon.setImageId(ICON_PHONE);
        imageIcon.setSetOnImage(R.drawable.icon_phone_on);
        imageIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(imageIcon);

        //인증번호  아이콘
        ImageIcon certifyIcon = new ImageIcon();
        ImageView certifyImage = (ImageView)findViewById(R.id.pCertifyIconimage);
        certifyIcon.setView(certifyImage);
        certifyIcon.setEditText((EditText)findViewById(R.id.pCertifiyNumberText));
        certifyIcon.setImageId(ICON_CERTIFY);
        certifyIcon.setSetOnImage(R.drawable.icon_phone_on);
        certifyIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(certifyIcon);
    }

    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
    *
    * */
    private void editTextEvent(){
        for(int i=0;i<imageIcons.size();i++) {
            imageIcons.get(i).getEditText().setId(imageIcons.get(i).getImageId());
            imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                    } else {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                    }
                }
            });
        }
    }

    /* EditText 예외처리
    *
    * */
    private boolean exception(){
        boolean check = true;
        for(int i=0;i<imageIcons.size();i++){
            if(imageIcons.get(i).getEditText().getText().toString().matches("")){//빈공간 예외처리
                check = false;
                imageIcons.get(i).getEditText().requestFocus();
                Toast.makeText(getPrivateUserRegisterActivity(), "가입양식을 입력해주세요.", Toast.LENGTH_SHORT).show();
                break;
            }else if(!phone_overlap){
                check = false;
               Toast.makeText(getPrivateUserRegisterActivity(),"휴대폰 인증확인을 해주세요.",Toast.LENGTH_SHORT).show();
                break;
            } else{
                if(!editTextException(imageIcons.get(i).getEditText(),imageIcons.get(i).getImageId())){//형식 에외처리
                    check = false;
                    break;
                }
            }
        }
        return check;
    }

    private boolean emailException(EditText editText,int stateExcept){
        boolean check = true;
        switch (stateExcept){
            case ICON_EMAIL:
                if(editText.getText().toString().matches("")){
                    check = false;
                    Log.d(TAG,"아이디를 입력해 주세요.");
                    Toast.makeText(getPrivateUserRegisterActivity(),"아이디를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                }else if(!Filter.checkEmailForm(editText.getText().toString())){
                    check = false;
                    Log.d(TAG,"이메일 형식에 맞지않습니다.");
                    Toast.makeText(getPrivateUserRegisterActivity(),"이메일 형식에 맞지않습니다.",Toast.LENGTH_SHORT).show();
                }
                break;
        }

        return check;
    }

    /* editText 형식 예외처리
    *
    * */
    private boolean editTextException(EditText editText,int stateExcept){
        boolean check = true;
       switch (stateExcept){
           case ICON_EMAIL:
                if(!editText.getText().toString().contains("@")){
                    check = false;
                    Log.d(TAG,"이메일 형식에 맞지않습니다.");
                    Toast.makeText(getPrivateUserRegisterActivity(),"이메일 형식에 맞지않습니다.",Toast.LENGTH_SHORT).show();
                }else if(!emailid_overlap){
                    check = false;
                    Log.d(TAG,"이메일 중복 체크를 해주세요.");
                    Toast.makeText(getPrivateUserRegisterActivity(),"이메일 중복 체크를 해주세요.",Toast.LENGTH_SHORT).show();
                }
               break;
           case ICON_CHECKPW:
               if(!editText.getText().toString().matches(imageIcons.get(ICON_PW).getEditText().getText().toString())){
                   check = false;
                   Log.d(TAG,"비밀번호가 일치하지 않습니다.");
                   editText.requestFocus();
                   Toast.makeText(getPrivateUserRegisterActivity(),"비밀번호가 일치하지 않습니다.",Toast.LENGTH_SHORT).show();

               }
               break;
       }
        return check;
    }

    /* 회원가입 주소 값
    *
    * */
    private String getRegisterUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.PRIVATE_REGISTER;
        urlStr = urlStr + "?email=" + imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        urlStr = urlStr + "&pw=" + imageIcons.get(ICON_PW).getEditText().getText().toString();
        try {
            urlStr = urlStr + "&name=" + URLEncoder.encode(imageIcons.get(ICON_NAME).getEditText().getText().toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        urlStr = urlStr + "&phone=" + imageIcons.get(ICON_PHONE).getEditText().getText().toString();
        urlStr = urlStr + "&fcm="+ FirebaseInstanceId.getInstance().getToken();
        urlStr = urlStr + "&profile_img=null";
        Log.d(TAG,"");
        return urlStr;
    }

    /* 아이디 중복확인 주소 값
    *
    * */
    private String getOverLapUrlStr(){
        String urlStr = "";
        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.OVERLAP_CHECK;
        urlStr = urlStr + "?email=" + imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        return urlStr;
    }

    /* 버튼 이벤트
    *
    * */
    public void buttonEvent(){
        //아이디 중복확인
        Button overlabbtn = (Button)findViewById(R.id.pOverlapbtn);
        overlabbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(emailException(imageIcons.get(ICON_EMAIL).getEditText(),ICON_EMAIL)) {
                    JsonParse overlabJson = new JsonParse(getPrivateUserRegisterActivity()) {
                        @Override
                        public void startParse() {
                            loading.show();
                        }

                        @Override
                        public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                            if (flag.matches("1")) {//아이디 중복 안됨
                                emailid_overlap = true;
                                Toast.makeText(getPrivateUserRegisterActivity(), "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                emailid_overlap = false;
                                Toast.makeText(getPrivateUserRegisterActivity(), "아이디가 중복됩니다.", Toast.LENGTH_SHORT).show();
                            }
                            Log.d(TAG, "flag : " + flag);
                            Log.d(TAG, "message : " + message);
                            loading.dismiss();
                        }
                    };
                    overlabJson.getJsonParse(getOverLapUrlStr());
                }
            }
        });

        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.pCancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getPrivateUserRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();

                        getPrivateUserRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });

        //회원가입 버튼
        Button registerbtn = (Button)findViewById(R.id.pRegisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exception()) {
                    JsonParse jsonParse = new JsonParse(getPrivateUserRegisterActivity()) {
                        @Override
                        public void startParse() {
                            loading.show();
                        }

                        @Override
                        public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                            Log.d(TAG, "flag : " + flag);
                            Log.d(TAG, "message : " + message);
                            if(flag.matches("1")){
                                Toast.makeText(getPrivateUserRegisterActivity(), "회원가입이 되었습니다.", Toast.LENGTH_SHORT).show();
                                finish();
                            }else{
                                Toast.makeText(getPrivateUserRegisterActivity(), "회원가입에 실패했습니다.", Toast.LENGTH_SHORT).show();
                            }
                            loading.dismiss();
                        }
                    };
                    jsonParse.getJsonParse(getRegisterUrlStr());
                }
            }
        });


        //휴대폰 인증
        Button pOverlap = (Button)findViewById(R.id.pCertifiiybtn);
        pOverlap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone_overlap = true;
                Toast.makeText(PrivateUserRegisterActivity.this,"본인인증을 하였습니다.",Toast.LENGTH_SHORT).show();
            }
        });
    }


    public PrivateUserRegisterActivity getPrivateUserRegisterActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
