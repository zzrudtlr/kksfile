package com.quickbird.quickbird;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;

import Database.DB_SingleTon;
import Dialog.Loading;
import Register.ImageIcon;
import UserInfo.CompanyUserInfo;
import UserInfo.PrivateUserInfo;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-13.
 * 사업자 회원 정보수정
 */
public class CompanyUserEditActivity extends Activity {

    private final String TAG = "CompanyUserEditActivity";

    public final int ICON_EMAIL = 0;//이메일 아이디
    public final int ICON_CNAME = 1;//업체명
    public final int ICON_CEO = 2;//대표자
    public final int ICON_TYPE = 3;//업종
    public final int ICON_BUSINESS = 4;//업태
    public final int ICON_ADRESS = 5;//사업장 주소
    public final int ICON_PHONE = 6;//휴대폰
    public final int ICON_COMPANYNUMBER = 7;//사무실전화번호

    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();//이미지 아이콘 관리 구조체

    private Loading loading;

    private CompanyUserInfo companyUserInfo;//사업자 회원정보

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_userinfo_edit);
        init();
    }

    private void init(){
        loading = new Loading(this);
        companyUserInfo = new CompanyUserInfo();
        imageIconinit();
        buttonEvent();
        editTextEvent();
        requestUserInfo();
    }

    /* 이미지 아이콘 구조체 초기화
    *
    * */
    private void imageIconinit(){

        //이메일 아이디
        ImageIcon emaildIcon = new ImageIcon();
        emaildIcon.setEditText((EditText)findViewById(R.id.cueEmailidText));
        emaildIcon.setView((ImageView) findViewById(R.id.cueEmailidImage));
        emaildIcon.setImageId(ICON_EMAIL);
        emaildIcon.setSetOnImage(R.drawable.icon_email_on);
        emaildIcon.setSetOffImage(R.drawable.icon_email_off);
        imageIcons.add(emaildIcon);

        //업체명
        ImageIcon companyNameIcon = new ImageIcon();
        companyNameIcon.setEditText((EditText)findViewById(R.id.cueCampanyNameText));
        companyNameIcon.setView((ImageView) findViewById(R.id.cueCampanyNameImage));
        companyNameIcon.setImageId(ICON_CNAME);
        companyNameIcon.setSetOnImage(R.drawable.icon_doc_on);
        companyNameIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(companyNameIcon);

        //대표자
        ImageIcon ceoIcon = new ImageIcon();
        ceoIcon.setEditText((EditText) findViewById(R.id.cueCeoText));
        ceoIcon.setView((ImageView) findViewById(R.id.cueCeoImage));
        ceoIcon.setImageId(ICON_CEO);
        ceoIcon.setSetOnImage(R.drawable.icon_user_on);
        ceoIcon.setSetOffImage(R.drawable.icon_user_off);
        imageIcons.add(ceoIcon);

        //업종
        ImageIcon typeIcon = new ImageIcon();
        typeIcon.setEditText((EditText)findViewById(R.id.cuetypeText));
        typeIcon.setView((ImageView) findViewById(R.id.cuetypeImage));
        typeIcon.setImageId(ICON_TYPE);
        typeIcon.setSetOnImage(R.drawable.icon_doc_on);
        typeIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(typeIcon);

        //업태
        ImageIcon businessIcon = new ImageIcon();
        businessIcon.setEditText((EditText)findViewById(R.id.cueBusinessText));
        businessIcon.setView((ImageView) findViewById(R.id.cueBusinessImage));
        businessIcon.setImageId(ICON_BUSINESS);
        businessIcon.setSetOnImage(R.drawable.icon_doc_on);
        businessIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(businessIcon);

        //사업장 주소
        ImageIcon addressIcon = new ImageIcon();
        addressIcon.setEditText((EditText)findViewById(R.id.cueAddressText));
        addressIcon.setView((ImageView) findViewById(R.id.cueAddressImage));
        addressIcon.setImageId(ICON_ADRESS);
        addressIcon.setSetOnImage(R.drawable.icon_map_on);
        addressIcon.setSetOffImage(R.drawable.icon_map_off);
        imageIcons.add(addressIcon);

        //휴대폰
        ImageIcon phoneIcon = new ImageIcon();
        phoneIcon.setEditText((EditText)findViewById(R.id.cuePhoneText));
        phoneIcon.setView((ImageView) findViewById(R.id.cuePhoneImage));
        phoneIcon.setImageId(ICON_PHONE);
        phoneIcon.setSetOnImage(R.drawable.icon_phone_on);
        phoneIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(phoneIcon);

        //사업장 전화번호
        ImageIcon companyIcon = new ImageIcon();
        companyIcon.setEditText((EditText)findViewById(R.id.cueCompanyNumberText));
        companyIcon.setView((ImageView) findViewById(R.id.cueCompanyNumbeImage));
        companyIcon.setImageId(ICON_COMPANYNUMBER);
        companyIcon.setSetOnImage(R.drawable.icon_phone_on);
        companyIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(companyIcon);

    }

    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
*
* */
    private void editTextEvent(){

        for(int i=0;i<imageIcons.size();i++) {
            imageIcons.get(i).getEditText().setId(imageIcons.get(i).getImageId());
            imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                    } else {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                    }
                }
            });
        }

    }

    /* 회원정보 수정하기
   *
   * */
    private void updateUserInfo(){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    Toast.makeText(getCompanyUserEditActivity(),"회원정보가 수정 되었습니다.",Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Log.d(TAG,"회원정보 수정에 실패 했습니다");
                    Toast.makeText(getCompanyUserEditActivity(),"회원정보 수정에 실패 했습니다.",Toast.LENGTH_SHORT).show();
                }
            }
        };
        jsonParse.getJsonParse(getUpdateUrlStr());
    }

    /* 유저정보 받아오기
    *
    * */
    private void requestUserInfo(){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    companyUserInfo.setEailid(result.get(0).get(0));
                    companyUserInfo.setCompanyName(result.get(1).get(0));
                    companyUserInfo.setCompanyCeoName(result.get(2).get(0));
                    companyUserInfo.setCompanyBusinessNumber(result.get(3).get(0));
                    companyUserInfo.setCompanyType(result.get(4).get(0));
                    companyUserInfo.setCompanyBusiness(result.get(5).get(0));
                    companyUserInfo.setPhoneNumver(result.get(6).get(0));
                    companyUserInfo.setCompanyAddress(result.get(7).get(0));
                    companyUserInfo.setProfile_img(result.get(8).get(0));
                    companyUserInfo.setCompanyPhoneNumber(result.get(9).get(0));
                    setInfo();
                } else {
                    Log.d(TAG, "정보를 받아오는데 실패했습니다.");
                }
            }
        };
        jsonParse.getJsonParse(getRegisterUrlStr());
    }

    private void setInfo(){
        imageIcons.get(ICON_EMAIL).getEditText().setHint(companyUserInfo.getEailid());
        imageIcons.get(ICON_CNAME).getEditText().setText(companyUserInfo.getCompanyName());
        imageIcons.get(ICON_CEO).getEditText().setText(companyUserInfo.getCompanyCeoName());
        imageIcons.get(ICON_TYPE).getEditText().setText(companyUserInfo.getCompanyType());
        imageIcons.get(ICON_BUSINESS).getEditText().setText(companyUserInfo.getCompanyBusiness());
        imageIcons.get(ICON_ADRESS).getEditText().setText(companyUserInfo.getCompanyAddress());
        imageIcons.get(ICON_PHONE).getEditText().setText(companyUserInfo.getPhoneNumver());
        imageIcons.get(ICON_COMPANYNUMBER).getEditText().setText(companyUserInfo.getCompanyPhoneNumber());

        TextView businessText = (TextView)findViewById(R.id.cueCompanyIdentityText);
        businessText.setText(companyUserInfo.getCompanyBusinessNumber());
    }

    /* 회원정보 수정하기 주소 값
    *
    * */
    private String getUpdateUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.COMPANYUSERINFO_UPDATE;
        try {
            urlStr = urlStr + "?company_name=" +   URLEncoder.encode(imageIcons.get(ICON_CNAME).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&ceo_name=" +  URLEncoder.encode(imageIcons.get(ICON_CEO).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&b_num=" +  imageIcons.get(ICON_COMPANYNUMBER).getEditText().getText().toString();
            urlStr = urlStr + "&sectors=" +  URLEncoder.encode(imageIcons.get(ICON_TYPE).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&business=" +  URLEncoder.encode(imageIcons.get(ICON_BUSINESS).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&phone=" +  imageIcons.get(ICON_PHONE).getEditText().getText().toString();
            urlStr = urlStr + "&call_num=" +  imageIcons.get(ICON_COMPANYNUMBER).getEditText().getText().toString();
            urlStr = urlStr + "&profile_img=" + companyUserInfo.getProfile_img();
            urlStr = urlStr + "&address=" +   URLEncoder.encode(imageIcons.get(ICON_ADRESS).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


        Log.d(TAG,"getUpdateUrlStr : " + urlStr);
        return urlStr;
    }


    /* 회원정보 받아오기 주소 값
   *
   * */
    private String getRegisterUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.REQUEST_COMPANYUSERINFO;
        urlStr = urlStr + "?user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();

        return urlStr;
    }

    /* EditText 예외처리
    *
    * */
    private boolean exception(){
        boolean check = true;
        for(int i=0;i<imageIcons.size();i++){
            if(imageIcons.get(i).getEditText().getText().toString().matches("")){//빈공간 예외처리
                check = false;
                imageIcons.get(i).getEditText().requestFocus();
                Toast.makeText(this, "빈 공간을 채워주세요.", Toast.LENGTH_SHORT).show();
                break;
            }
        }
        return check;
    }

    /* 버튼 이벤트
    *
    * */
    private void buttonEvent(){
        Button infoeditbtn = (Button)findViewById(R.id.cueinfoEditbtn);
        infoeditbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(exception()){
                    Log.d(TAG, "정보수정");
                    updateUserInfo();
                }
            }
        });

        Button cancelbtn = (Button)findViewById(R.id.cueCancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "취소");
                finish();
            }
        });
    }

    private CompanyUserEditActivity getCompanyUserEditActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
}
