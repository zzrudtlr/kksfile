package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import DeliveryDetail.FreightInfo;
import Dialog.ConfirmDialog;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Gps.GpsInfo;
import Gps.GpsUpdate;
import Permission.DevicePermission;
import Picture.CustomBitmapPool;
import Picture.DevicePicture;
import Picture.MultiplePicture.Action;
import Picture.MultiplePicture.CustomGallery;
import Picture.PictureUpload;
import QB_MainVIewPager.BookMarkPage.OnBookMarkPageListener;
import QB_MainVIewPager.HomePage.OnHomePageListener;
import QB_MainVIewPager.MyPage.MyPageListView;
import QB_MainVIewPager.MyPage.OnMyListInfoListener;
import QB_MainVIewPager.OptionPage.OnOptionListener;
import QB_MainVIewPager.QB_ViewPageAdapter;
import QB_MainVIewPager.Qb_ViewPageTab;
import QB_MainVIewPager.SurroundingDeliveryPage.OnSurroundingDeliveryListener;
import QB_MainVIewPager.SurroundingDeliveryPage.SurroundingDeliveryPageView;
import SearchLayout.SearchLayout;
import SearchLayout.OnSearchLayoutListener;
import SearchLayout.SearchInfo;
import ShareLink.KaKaoLineShare;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import jp.wasabeef.glide.transformations.CropCircleTransformation;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-03.
 * 메인 페이지
 */
public class QB_MainActivity extends Activity {

    private final String TAG = "QB_MainActivity";

    private final int PICK_FROM_CAMERA = 0;
    private final int PICK_FROM_ALBUM = 1;
    private final int CROP_FROM_iMAGE = 2;
    private final int RELOAD_WEBVIEW=3;

    private ViewPager pager;//메인 뷰 페이지
    private QB_ViewPageAdapter qb_viewPageAdapter;//메인 뷰 페이지 어뎁터
    private Qb_ViewPageTab qb_viewPageTab;//메인 뷰페이지 탭

    private DevicePicture devicePicture;

    private DrawerLayout drawerLayout;//홈 페이지 레이아웃
    private LinearLayout leftRL;//홈페이지 검색 필터 레이아웃

    private LinearLayout rightRL;//즐겨찾기 검색 필터 레이아웃

    private int statePage;//현재 페이지 상태
    private boolean startgetData = true;

    private Loading loading;//로딩 다이얼로그

    private KaKaoLineShare kaKaoLineShare;//카카오톡, 라인 공유하기

    private DevicePermission devicePermission;//기기 접근 허가

    private SearchLayout searchLayout;//홈 페이지의 검색 사이드메뉴
    private SearchLayout filterLayout;//즐겨찾기 페이지 필터 사이트메뉴

    private GpsInfo gps;//gps 위치 정보
    private GpsUpdate gpsUpdate;

    private ArrayList<FreightInfo> freightInfos;
    private String delivery_idx="";
    private String freight_idx="";//희망 화물로 등록할 화물 idx

    private BackPressClose backPressClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qb_main);

       // loading.show();
        init();
        Log.d(TAG,"deliverty_idx : " + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx());
        //if(DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx().matches("0")){
        //    Log.d(TAG,"선택된 배송자 없음");
      //  }else{
            gpsUpdate = new GpsUpdate(this);
            gpsUpdate.startGps();
      //  }
      //  gpsUpdate = new GpsUpdate(this);
     //   gpsUpdate.startGps();
    }

    /*초기화
    *
    * */
    private void init(){
        backPressClose = new BackPressClose(this);
        //로딩 시작
        loading = new Loading(this);
        devicePermission = new DevicePermission();
        devicePicture = new DevicePicture(this);
        kaKaoLineShare = new KaKaoLineShare();
        leftRL = (LinearLayout)findViewById(R.id.searchLayout);
        rightRL = (LinearLayout)findViewById(R.id.filterLayout);
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        freightInfos = new ArrayList<>();
        qb_viewPageTab = new Qb_ViewPageTab(this) {
            @Override
            public void touchListenear(int underbtn, Qb_ViewPageTab qb_viewpageTab) {
                pager.setCurrentItem(underbtn);
                qb_viewpageTab.setBtnImage(underbtn);
            }
        };
        initViewPager();
        qb_viewPageTab.setBtnImage(pager.getCurrentItem());

        //홈 페이지의 검색 사이드메뉴
        searchLayout = new SearchLayout(leftRL,this);
        searchLayout.setOnSearchLayoutListener(new OnSearchLayoutListener() {
            @Override
            public void onClickSearchState(int state) {
                Log.d(TAG,"onClickSearchState : " + state);
            }

            @Override
            public void onClickItem(int position, String[] titlelist) {
                Log.d(TAG, "titllist : " + titlelist[position]);
            }

            @Override
            public void onClickAreaInfo(String lat, String lng, String address, int state) {

            }

            @Override
            public void onClickCancel() {
                Log.d(TAG,"Home onClickCancelBtn");
                onCloseLeftDrawer();//홈페이지 검색 창 닫기
            }

            @Override
            public void onClickSelect(SearchInfo searchInfo) {
                Log.d(TAG,"home : " + searchInfo.getEnd_address());
                if (gps.isGetLocation()) {
                    searchInfo.setMyLng(String.valueOf(gps.getLongitude()));
                    searchInfo.setMyLat(String.valueOf(gps.getLatitude()));
                } else {
                    // GPS 를 사용할수 없으므로
                    searchInfo.setMyLng("0");
                    searchInfo.setMyLat("0");
                }
                qb_viewPageAdapter.getHomePageView().reloadWebview(searchInfo);
                onCloseLeftDrawer();//홈페이지 검색 창 닫기
            }
        });

        //즐겨찾기 페이지 필터 사이트메뉴
        filterLayout = new SearchLayout(rightRL,this);
        filterLayout.setOnSearchLayoutListener(new OnSearchLayoutListener() {
            @Override
            public void onClickSearchState(int state) {
                Log.d(TAG,"onClickSearchState : " + state);
            }

            @Override
            public void onClickItem(int position, String[] titlelist) {
                Log.d(TAG, "titllist : " + titlelist[position]);
            }

            @Override
            public void onClickAreaInfo(String lat, String lng, String address, int state) {

            }

            @Override
            public void onClickCancel() {
                Log.d(TAG,"BookMark onClickCancelBtn");
                onCloseRightDrawer();// 즐겨찾기 페이지 검색 창 닫기
            }

            @Override
            public void onClickSelect(SearchInfo searchInfo) {
                Log.d(TAG, "bookmark : " + searchInfo.getEnd_address());
                if (gps.isGetLocation()) {
                    searchInfo.setMyLng(String.valueOf(gps.getLongitude()));
                    searchInfo.setMyLat(String.valueOf(gps.getLatitude()));
                } else {
                    // GPS 를 사용할수 없으므로
                    searchInfo.setMyLng("0");
                    searchInfo.setMyLat("0");
                }
                updateBookMarkSearch(searchInfo);//즐겨찾기 검색 조건 저장

                onCloseRightDrawer();// 즐겨찾기 페이지 검색 창 닫기
            }
        });

          gps = new GpsInfo(this);

        if (gps.isGetLocation()) {

        } else {
            // GPS 를 사용할수 없으므로
            gps.showSettingsAlert();
        }
    }



    /*뷰페이지 초기화
    *
    * */
    private void initViewPager(){
        pager = (ViewPager)findViewById(R.id.pager);
        qb_viewPageAdapter = new QB_ViewPageAdapter(getLayoutInflater(),this);
        pager.setAdapter(qb_viewPageAdapter);
        pager.setOffscreenPageLimit(4);
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                // underbar.setStateUnderbar(position);
                if (startgetData) {
                    statePage = qb_viewPageAdapter.pageState(0);
                    startgetData = false;
                    initHomePageEvent();//홈 페이지뷰 이벤트
                    initBookMarkPageEvent();//즐겨찾기 페이지뷰 이벤트
                    initMyPageEvent();//마이페이지 이벤트
                    initSurroundingDeliveryPageEvent();//주변 검색 페이지 이벤트
                    initOptionPageEvent();//옵션 페이지 이벤트
                    searchState(position);//사이드 레이아웃 상태

                }
               // checkMyPage(position);
            }

            @Override
            public void onPageSelected(int position) {
                qb_viewPageTab.setBtnImage(position);
                statePage = qb_viewPageAdapter.pageState(position);
                searchState(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
              //  checkMyPage(state);
            }
        });
    }

    /* 현재 페이지 상태가 마이페이지 일떄
    *  position : 현재 뷰페이지의 페이지
    * */
   /* public void checkMyPage(int position){
        if(qb_viewPageAdapter.myPage == position){// 마이페이지 상태일떄
            qb_viewPageAdapter.getMyPageView().getMyListInfoView().setChangedinit();//버튼 배경 초기화
        }
    }*/

    /* 마이페이지 이벤트
    *
    * */
    private void initMyPageEvent(){

        qb_viewPageAdapter.getMyPageView().getMyPageListView().setOnMyListInfoListener(new OnMyListInfoListener() {
            @Override
            public void onClickListItem(View v, int state, MyPageListView myPageListView) {
                //  v.setBackgroundColor(Color.rgb(185,195,194));
                if (myPageListView.USER_INFO_EDIT == state) {
                    if (DB_SingleTon.getInstance(QB_MainActivity.this).getUserInfoTable().getUserTyp().matches("0")) {
                        Log.d(TAG, "사업자 회원 수정");
                        Intent intent = new Intent(QB_MainActivity.this, CompanyUserEditActivity.class);
                        startActivity(intent);
                    } else {
                        Log.d(TAG, "개인 회원 수정");
                        Intent intent = new Intent(QB_MainActivity.this, PrivateUserEditActivity.class);
                        startActivity(intent);
                    }

                } else if (myPageListView.MY_REGISTERED_FREIGHT == state) {
                    Intent intent = new Intent(QB_MainActivity.this, MyRegisteredFreightActivity.class);
                    startActivityForResult(intent, RELOAD_WEBVIEW);
                } else if (myPageListView.MY_REGISTERED_DELIVERY == state) {
                    Intent intent = new Intent(QB_MainActivity.this, MyRegisteredDeliveryActivity.class);
                    startActivityForResult(intent, RELOAD_WEBVIEW);
                } else if (myPageListView.LOGOUT == state) {
                    logout();
                }
            }

            @Override
            public void onClickCamera() {
                if (devicePermission.checkPermission(getQb_mainActivity())) {
                    devicePicture.doTakeAlbumAction();
                }
            }
        });

       /* qb_viewPageAdapter.getMyPageView().getMyListInfoView().setOnMyListInfoListener(new OnMyListInfoListener() {
            @Override
            public void onClickListUp(View v, int state) {
                if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().USER_INFO_EDIT == state) {
                    Log.d(TAG, "USER_INFO_EDIT");
                    v.setBackgroundColor(Color.WHITE);
                } else if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().MY_REGISTERED_FREIGHT == state) {
                    Log.d(TAG, "MY_REGISTERED_FREIGHT");
                    v.setBackgroundColor(Color.WHITE);
                } else if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().MY_REGISTERED_DELIVERY == state) {
                    Log.d(TAG, "MY_REGISTERED_DELIVERY");
                    v.setBackgroundColor(Color.WHITE);
                }
            }

            @Override
            public void onClickListDown(View v, int state) {
                if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().USER_INFO_EDIT == state) {
                    Log.d(TAG, "USER_INFO_EDIT");
                    v.setBackgroundColor(Color.rgb(185, 195, 194));
                } else if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().MY_REGISTERED_FREIGHT == state) {
                    Log.d(TAG, "MY_REGISTERED_FREIGHT");
                    v.setBackgroundColor(Color.rgb(185, 195, 194));
                } else if (qb_viewPageAdapter.getMyPageView().getMyListInfoView().MY_REGISTERED_DELIVERY == state) {
                    Log.d(TAG, "MY_REGISTERED_DELIVERY");
                    v.setBackgroundColor(Color.rgb(185, 195, 194));
                }
            }
        });*/
    }

    /* 즐겨찾기 이벤트
    *
    * */
    private void initBookMarkPageEvent(){
        qb_viewPageAdapter.getBookMarkPageView().setOnBookMarkPageListener(new OnBookMarkPageListener() {
            @Override
            public void onClickfilter() {
                getBookMarkSearchInfo();
                onOpenRightDrawer();
            }

            @Override
            public void onRestartView(WebView webView) {
                webView.reload();
                qb_viewPageAdapter.getBookMarkPageView().getErrorView().setVisibility(View.GONE);
            }
        });

        qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().setWebLoadFinish(false);
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().setWebLoadFinish(true);//즐겨찾기 웹 페이지 load 완료
                if (finishLoadPage()) {
                    loading.dismiss();
                    loading.setLoadingState(false);
                }
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                qb_viewPageAdapter.getBookMarkPageView().getErrorView().setVisibility(View.VISIBLE);
                loading.setLoadingState(false);
                Log.d(TAG, "errorWebClient");
            }
        });

        qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void h_list(String state, String view_idx) {
                Log.d(TAG, "h_list state : " + state + " view_idx : " + view_idx);
                if (state.matches("1")) {//화물
                    Intent intent = new Intent(getQb_mainActivity(), FreightInfoDetailActivity.class);
                    intent.putExtra("freight_idx", "" + view_idx);
                    startActivity(intent);
                } else if (state.matches("0")) {//배송자
                    Intent intent = new Intent(getQb_mainActivity(), DeliveryInfoDetailActivity.class);
                    intent.putExtra("delivery_idx", "" + view_idx);
                    startActivity(intent);
                }
            }
        }, "quickbird");
    }

    /* 홈 페이지 이벤트
    *
    * */
    private void initHomePageEvent(){
        qb_viewPageAdapter.getHomePageView().setOnHomePageListener(new OnHomePageListener() {
            @Override
            public void onClickSearch() {
                onOpenLeftDrawer();
            }

            @Override
            public void onClickWrite() {
                //화물등록 및 배송자등록 선택 다이얼로그
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(QB_MainActivity.this) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                        Log.d(TAG, "화물 등록하기");
                        Intent private_user = new Intent(QB_MainActivity.this, FreightRegisterActivity.class);
                        startActivityForResult(private_user, RELOAD_WEBVIEW);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        Log.d(TAG, "배송자 등록하기");
                        Intent company_user = new Intent(QB_MainActivity.this, DeliveryRegisterActivity.class);
                        startActivityForResult(company_user, RELOAD_WEBVIEW);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("화물 등록하기");
                selectTwoDialog.getSelectTwoButton().setText("배송자 등록하기");
                selectTwoDialog.show();
            }

            @Override
            public void onRestartView(WebView webView) {
                webView.reload();
                qb_viewPageAdapter.getHomePageView().getErrorView().setVisibility(View.GONE);
            }
        });

        qb_viewPageAdapter.getHomePageView().getHomePageWebView().getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                Log.d(TAG, "homePageWebView start");
                if (!loading.isLoadingState()) {
                    qb_viewPageAdapter.getHomePageView().getHomePageWebView().setWebLoadFinish(false);
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                qb_viewPageAdapter.getHomePageView().getHomePageWebView().setWebLoadFinish(true);//홈 페이지의 웹 뷰 load 완료
                if (finishLoadPage()) {
                    loading.dismiss();
                    loading.setLoadingState(false);
                }
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                qb_viewPageAdapter.getHomePageView().getErrorView().setVisibility(View.VISIBLE);
                loading.setLoadingState(false);
                Log.d(TAG, "errorWebClient");
            }
        });
        qb_viewPageAdapter.getHomePageView().getHomePageWebView().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void h_list(int state, int view_idx) {
                Log.d(TAG, "h_list state : " + state + " view_idx : " + view_idx);
                if (state == 1) {//화물
                    Intent intent = new Intent(getQb_mainActivity(), FreightInfoDetailActivity.class);
                    intent.putExtra("freight_idx", "" + view_idx);
                    startActivity(intent);
                } else if (state == 0) {//배송자
                    Intent intent = new Intent(getQb_mainActivity(), DeliveryInfoDetailActivity.class);
                    intent.putExtra("delivery_idx", "" + view_idx);
                    startActivity(intent);
                }
            }
        }, "quickbird");
    }

    /* 주변 검색 이벤트
    *
    * */
    public void initSurroundingDeliveryPageEvent(){
        qb_viewPageAdapter.getSurroundingDeliveryPageView().setOnSurroundingDeliveryListener(new OnSurroundingDeliveryListener() {
            @Override
            public void onClickSearch(SurroundingDeliveryPageView surroundingDeliveryPageView) {
                Log.d(TAG, "initSurroundingDeliveryPageEvent onClickSearch");
                surroundingDeliveryPageView.changeSearch();//검색

            }

            @Override
            public void onClickReturn(SurroundingDeliveryPageView surroundingDeliveryPageView) {
                Log.d(TAG, "initSurroundingDeliveryPageEvent onClickReturn");
                //surroundingDeliveryPageView.initWebView();//갱신
                surroundingDeliveryPageView.reLoadWebPage();//주변검색 페이지 갱신
            }

            @Override
            public void onClickCall(String phoneNumber) {//전화걸기
                // Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
                //  startActivity(intent);
                devicePermission.checkPermissionCall(QB_MainActivity.this, phoneNumber);
            }

            @Override
            public void onClickDetailInfo(String idx, String search_falg) {//상세정보
                if (search_falg.matches("" + qb_viewPageAdapter.getSurroundingDeliveryPageView().SEARCH_DELIVERY)) {
                    Intent intent = new Intent(QB_MainActivity.this, DeliveryInfoDetailActivity.class);
                    intent.putExtra("delivery_idx", idx);
                    startActivity(intent);
                } else if (search_falg.matches("" + qb_viewPageAdapter.getSurroundingDeliveryPageView().SEARCH_FREIGHT)) {
                    Intent intent = new Intent(QB_MainActivity.this, FreightInfoDetailActivity.class);
                    intent.putExtra("freight_idx", idx);
                    startActivity(intent);
                }

            }


            @Override
            public void onClickSelect(SurroundingDeliveryPageView surroundingDeliveryPageView) {
                //화물 및 배송자 선택 다이얼로그
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(QB_MainActivity.this) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                        Log.d(TAG, "화물");
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().setSearchFlag(qb_viewPageAdapter.getSurroundingDeliveryPageView().SEARCH_FREIGHT);
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().changeSearch();
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        Log.d(TAG, "배송자");
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().setSearchFlag(qb_viewPageAdapter.getSurroundingDeliveryPageView().SEARCH_DELIVERY);
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().changeSearch();
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("화물");
                selectTwoDialog.getSelectTwoButton().setText("배송자");
                selectTwoDialog.show();
            }

            @Override
            public void onClickRequestDelivery(String search_idx, String search_falg) {
                if (search_falg.equals("0")) {
                    delivery_idx = search_idx;
                    RequestFreightList();
                } else {
                    freight_idx = search_idx;
                    if(!DB_SingleTon.getInstance(getQb_mainActivity()).getUserInfoTable().getDelivery_idx().matches("0")){
                        updateDeliveryFreight();
                    }else{
                        Toast.makeText(getQb_mainActivity(),"배송자를 지정해주세요.",Toast.LENGTH_SHORT).show();
                    }
                }
                Log.d(TAG, "search_falg : " + search_falg);
            }

            @Override
            public void onRestartView(WebView webView) {
                webView.reload();
                qb_viewPageAdapter.getSurroundingDeliveryPageView().getErrorView().setVisibility(View.GONE);
            }
        });

        qb_viewPageAdapter.getSurroundingDeliveryPageView().getSurroundingDeliveryWebView().getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getSurroundingDeliveryWebView().setWebLoadFinish(false);
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                qb_viewPageAdapter.getSurroundingDeliveryPageView().getSurroundingDeliveryWebView().setWebLoadFinish(true);//즐겨찾기 웹 페이지 load 완료
                if (finishLoadPage()) {
                    loading.dismiss();
                    loading.setLoadingState(false);
                }
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                qb_viewPageAdapter.getSurroundingDeliveryPageView().getErrorView().setVisibility(View.VISIBLE);
                loading.setLoadingState(false);
                Log.d(TAG, "errorWebClient");
            }
        });

        qb_viewPageAdapter.getSurroundingDeliveryPageView().getSurroundingDeliveryWebView().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void clickMarker(String idx) {
                Log.d(TAG, "marker_click idx : " + idx);
                qb_viewPageAdapter.getSurroundingDeliveryPageView().search_idx = idx;
                handler.sendEmptyMessage(2);
            }

            @JavascriptInterface
            public void error(String message) {
                Log.d(TAG, "error message : " + message);
                Toast.makeText(getQb_mainActivity(), message, Toast.LENGTH_SHORT).show();
            }
        }, "quickbird");
    }

    /* 옵션페이지 이븐트
    *
    * */
    public void initOptionPageEvent(){
        qb_viewPageAdapter.getOptionPageView().setOnOptionListener(new OnOptionListener() {
            @Override
            public void onClickState(int state) {
                if (qb_viewPageAdapter.getOptionPageView().KAKAO_SHARE == state) {//카카오톡 공유하기
                    kaKaoLineShare.shareKakao(QB_MainActivity.this);//카카오톡 공유하기
                } else if (qb_viewPageAdapter.getOptionPageView().LINE_SHARE == state) {//라인 공유하기
                    kaKaoLineShare.shareLine(QB_MainActivity.this);
                }
            }

            @Override
            public void onClickPushState(int state) {//알림 설정 끄고 켜기
                Log.d(TAG, "push state : " + state);
                DB_SingleTon.getInstance(getQb_mainActivity()).getUserInfoTable().updatePushOnOff("" + state);
                if (state == 0) {
                    Toast.makeText(getQb_mainActivity(), "알람을 껐습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getQb_mainActivity(), "알람을 켰습니다.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onClickStoreage(SearchInfo searchInfo) {//알림 설정 저장
                Log.d(TAG, "storeagebtn startAddress : " + searchInfo.getStart_address() + " endAddress : " + searchInfo.getEnd_address() + " searchState : " + searchInfo.getSearchState() + " itemidx : " + searchInfo.getItemidx() + " keyword " + searchInfo.getKeyword());
                if (!DB_SingleTon.getInstance(getQb_mainActivity()).getUserInfoTable().getDelivery_idx().matches("0")) {
                    optionUpdate(searchInfo);
                } else {
                    Toast.makeText(getQb_mainActivity(), "배송자를 지정해주세요.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onClickNotice() {
                Intent intent = new Intent(QB_MainActivity.this, NoticeActivity.class);
                startActivity(intent);
            }

            @Override
            public void onStartInfo() {
                if (!loading.isLoadingState()) {
                    qb_viewPageAdapter.getOptionPageView().setOptionFinish(false);
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void onNoticeCount(int noticeCount) {
                Log.d(TAG,"noticeCount : " + noticeCount);
                if(noticeCount > 0){
                    qb_viewPageAdapter.getOptionPageView().getNoticebadgeText().setVisibility(View.VISIBLE);
                    qb_viewPageTab.setBadgeView(qb_viewPageTab.under_option,""+noticeCount);
                }else{
                    qb_viewPageAdapter.getOptionPageView().getNoticebadgeText().setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onEndInfo() {
                qb_viewPageAdapter.getOptionPageView().setOptionFinish(true);//알람 설정 페이지 load 완료
                if (finishLoadPage()) {
                    loading.dismiss();
                    loading.setLoadingState(false);
                    Log.d(TAG, "옵션 페이지 완료");
                }
            }
        });
    }

    /* 왼쪽 사이드 검색 레이아웃 홈 페이지일때만 적용
    *
    * */
    public void searchState(int position){
        if(qb_viewPageAdapter.homePage==position){//홈페이지일 겡우
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.LEFT);//홈 페이지 왼쪽 사이드 필터 레이아웃 이용
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED,Gravity.RIGHT);//즐겨찾기 오른쪽 사이드 필터 레이아웃 이용하지 못함
        }else if(qb_viewPageAdapter.bookmarkPage == position){//즐겨찾기일 경우
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, Gravity.RIGHT);//즐겨찾기 오른쪽 사이드 필터 레이아웃 이용
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED,Gravity.LEFT);//홈 페이지 왼쪽 사이드 필터 레이아웃 이용하지 못함
        }else{//나머지 페이지일 경우
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);//오른쪽, 왼쪽 사이드 필터 다이용 못함
        }
    }

    //로그아웃
    public void logout(){
        ConfirmDialog confirmDialog = new ConfirmDialog(getQb_mainActivity()) {
            @Override
            public void onClickConfirm(ConfirmDialog confirmDialog) {
                confirmDialog.dismiss();
               // DB_SingleTon.getInstance(getQb_mainActivity()).getUserInfoTable().deleteAllColumns();
                DB_SingleTon.getInstance(getQb_mainActivity()).getUserInfoTable().updateAutoLogin("0");
                Intent intent = new Intent(QB_MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onClickCancel() {

            }
        };
        confirmDialog.getConfirmBtn().setText("확인");
        confirmDialog.getCancelBtn().setText("취소");
        confirmDialog.getTitleText().setText("정말로 로그아웃을 하시겠습니까?");
        confirmDialog.show();
    }

    public boolean finishLoadPage(){
        boolean finishLoad = false;
        if(!qb_viewPageAdapter.getHomePageView().getHomePageWebView().isWebLoadFinish()){
            Log.d(TAG, "홈 페이지 load 안됨");
            finishLoad = false;
        }else if(!qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().isWebLoadFinish()){
            Log.d(TAG, "즐겨찾기 페이지 load 안됨");
            finishLoad = false;
        }else if(!qb_viewPageAdapter.getSurroundingDeliveryPageView().getSurroundingDeliveryWebView().isWebLoadFinish()){
            Log.d(TAG,"주변배송자 페이지 load 안됨");
            finishLoad = false;
        }else if(!qb_viewPageAdapter.getOptionPageView().isOptionFinish()){
            Log.d(TAG,"옵션 페이지 load 안됨");
            finishLoad = false;
        }else{
            finishLoad = true;// 모든 웹 load 완료료
        }
       return finishLoad;
    }

    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    /* 마이페이지 프로필 사진 업데이트
    *
    */
    private void pictureUpload(String path){
        loading.show();//result 에서 로딩 종료
        String str[][] = {{"profile_img",DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx()}};
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(url, path) {
            @Override
            public void finishUpload(String pictureName) {
                Log.d(TAG, "pictureName : " + pictureName);

                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG, "message : " + jsonObject.getString("message"));
                    userProfilePictureUpdate(jsonObject.getString("message"));

                   // profileimage_name = jsonObject.getString("message");
                    //  sendImageName(profileimage_name);
                    //  sendRegister();

                   // handler.sendEmptyMessage(2);
                    //loading.dismiss();


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                Log.d(TAG,"pictureuload errorCode : " + errorCode);
                loading.dismiss();
            }
        };//섬네일 이미지 사진업로드
        pu.uploadVideo();
    }

    /* 즐겨찾기 검색 설정 저장 url
    *
    * */
    private String getBookMarkSearchUpdateUrlStr(SearchInfo searchInfo){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.BOOKMARKSEARCH_UPDATE;
        urlStr = urlStr + "?user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&search_flag=" + searchInfo.getSearchState();
        urlStr = urlStr + "&my_distance=" + searchInfo.getMyarea_name();
        try {
            urlStr = urlStr + "&sp_address=" + URLEncoder.encode(searchInfo.getStart_address(), "UTF-8");
            urlStr = urlStr + "&ap_address=" + URLEncoder.encode(searchInfo.getEnd_address(), "UTF-8");
            if(searchInfo.getSearchState() == filterLayout.getSearchState().SEARCH_DELIVERY) {
                searchInfo.setItemidx("");
            }
            urlStr = urlStr + "&item_idx=" + searchInfo.getItemidx();
            urlStr = urlStr + "&key_word=" + URLEncoder.encode(searchInfo.getKeyword(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        Log.d(TAG, "getBookMarkSearchUpdateUrlStr : " + urlStr);
        return urlStr;
    }


    /* 즐겨찾기 검색 설정 저장
    *
    * */
    private void updateBookMarkSearch(SearchInfo searchInfo){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().getWebView().reload();
                } else {
                    Toast.makeText(getQb_mainActivity(), "실패", Toast.LENGTH_SHORT).show();
                }

            }
        };
        jsonParse.getJsonParse(getBookMarkSearchUpdateUrlStr(searchInfo));
    }


    /* 즐겨찾기 검색 설정 정보 가져오기 url
    *
    * */
    private String getBookMarkSearchInfoUpdateUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.BOOKMARKSEARCHINFO;
        urlStr = urlStr + "?user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        Log.d(TAG, "getBookMarkSearchInfoUpdateUrlStr : " + urlStr);
        return urlStr;
    }


    /* 즐겨찾기 검색 설정 정보 불러오기
    *
    * */
    private void getBookMarkSearchInfo(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "getBookMarkSearchInfo flag : " + flag);
                Log.d(TAG, "getBookMarkSearchInfo message : " + message);
              // Log.d(TAG, "getBookMarkSearchInfo result : " + result.toString());
                loading.dismiss();
                if (flag.matches("1")) {
                    SearchInfo searchInfo = new SearchInfo();
                    Log.d(TAG, "setSearchState : " + Integer.parseInt(result.get(1).get(0)));
                    searchInfo.setSearchState(Integer.parseInt(result.get(1).get(0)));
                    if(result.get(2).get(0).matches("0")){
                        searchInfo.setMyarea_name("전국");
                    }else {
                        searchInfo.setMyarea_name(result.get(2).get(0));
                    }
                    searchInfo.setStart_address(result.get(3).get(0));
                    searchInfo.setEnd_address(result.get(4).get(0));
                    searchInfo.setItemidx(result.get(5).get(0));

                    searchInfo.setItemName(result.get(7).get(0));
                    searchInfo.setKeyword(result.get(6).get(0));
                    filterLayout.setSearchInfoData(searchInfo);
                } else {
                    Toast.makeText(getQb_mainActivity(), message, Toast.LENGTH_SHORT).show();
                }

            }
        };
        jsonParse.getJsonParse(getBookMarkSearchInfoUpdateUrlStr());
    }

    /* 프로필 사진 업데이트 url
    *
    * */
    private String getUserProfilePictureUpdateUrlStr(String updateImage){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.UPDATEPICTURE;
        urlStr = urlStr + "?profile_new=" + updateImage;
        urlStr = urlStr + "&profile_old=" + DB_SingleTon.getInstance(this).getUserInfoTable().getProfileImage();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        Log.d(TAG, "getUserProfilePictureUpdateUrlStr : " + urlStr);
        return urlStr;
    }

    /* 유저 프로필 이미지 업데이트
    *
    * */
    private void userProfilePictureUpdate(String updateImage){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                if (flag.matches("1")) {
                    Log.d(TAG, "userProfilePictureUpdate : " + result.get(0).get(0));
                    DB_SingleTon.getInstance(QB_MainActivity.this).getUserInfoTable().updateProfileImage(result.get(0).get(0));
                } else {
                    Toast.makeText(getQb_mainActivity(), message, Toast.LENGTH_SHORT).show();
                }
                handler.sendEmptyMessage(3);//마이페이지 유저 프로필 갱신
                handler.sendEmptyMessage(0);

            }
        };
        jsonParse.getJsonParse(getUserProfilePictureUpdateUrlStr(updateImage));
    }
    /* 푸시 알림 설정 저장 url
    *
    * */
    private String getOptionUrlStr(SearchInfo searchInfo){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.PUSHOPTION_UPDATE;
        urlStr = urlStr + "?distance=" + searchInfo.getMyarea_name();
        try {
            urlStr = urlStr + "&sp_address=" + URLEncoder.encode(searchInfo.getStart_address(), "UTF-8");
            urlStr = urlStr + "&ap_address=" + URLEncoder.encode(searchInfo.getEnd_address(), "UTF-8");
            urlStr = urlStr + "&item_idx=" + searchInfo.getItemidx();
            urlStr = urlStr + "&keyword=" + URLEncoder.encode(searchInfo.getKeyword(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        urlStr = urlStr + "&delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        Log.d(TAG, "getOptionUrlStr : " + urlStr);
        return urlStr;
    }

    /* 푸시 알람 설정 저장
    *
    * */
    private void optionUpdate(SearchInfo searchInfo){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "optionUpdate flag : " + flag);
                Log.d(TAG, "optionUpdate message : " + message);
                loading.dismiss();
                if (flag.matches("1")) {
                    Toast.makeText(getQb_mainActivity(), "알람 설정을 저장하였습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getQb_mainActivity(), message, Toast.LENGTH_SHORT).show();
                }
            }
        };
        jsonParse.getJsonParse(getOptionUrlStr(searchInfo));
    }

    /* 주변검색 마커클릭시 받아오는 배송자 정보 받아오기 url
    *
    * */
    private String getDeliveryInfo(String delivery_idx){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_DELIVERY_INFO;
        urlStr = urlStr + "?delivery_idx="+delivery_idx;
        Log.d(TAG, "getDeliveryInfo : " + urlStr);
        return urlStr;
    }

    /* 주변검색 배송자 마커클릭시 받아오는 배송자정보
    *
    * */
    private void deliveryInfo(String delivery_idx){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                handler.sendEmptyMessage(1);
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "DeliveryInfo flag : " + flag);
                Log.d(TAG, "DeliveryInfo message : " + message);
                handler.sendEmptyMessage(0);
                if (flag.matches("1")) {
                    Log.d(TAG, "DeliveryInfo message : " + result.toString());
                    String profile = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + result.get(1).get(0);
                    //Glide.with(getQb_mainActivity()).load(profile).into(qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView());
                    Glide.with(getQb_mainActivity()).load(profile)
                            .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                            .into(qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView());
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getNameText().setText("이 름 : " + result.get(0).get(0));
                    if(!result.get(2).get(0).matches("null")){
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText("메 모 : " + result.get(2).get(0));
                    }else{
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText("메 모 : " + "없음");
                    }
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().phoneNumber = result.get(3).get(0);
                } else {
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView().setImageResource(R.drawable.profile_man);
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getNameText().setText("이 름 : 없음");
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText("메 모 : " + "없음");
                    //qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText(memoStr);
                }
            }
        };
        jsonParse.getJsonParse(getDeliveryInfo(delivery_idx));
    }

    /* 주변 검색 화물 마커 클릭시 화물정보 받아오기 url
    *
    * */
    private String getFreightnfo(String freight_idx){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_FREIGHT_INFO;
        urlStr = urlStr + "?freight_idx=" + freight_idx;
        Log.d(TAG, "getFreightnfo : " + urlStr);
        return urlStr;
    }

    /* 주변 검색 화물 마커 클릭시 화물정보 받아오기기
   *
    * */
    private void freightInfo(String freight_idx){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                handler.sendEmptyMessage(1);
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "freightInfo flag : " + flag);
                Log.d(TAG, "freightInfo message : " + message);
                handler.sendEmptyMessage(0);
                if (flag.matches("1")) {

                    String sprofile[] = result.get(2).get(0).split("/");
                    if(sprofile[0].contains(".jpg")){//사진일 경우
                        String profile = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + sprofile[0];
                      //  Glide.with(getQb_mainActivity()).load(profile).into(qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView());
                        Glide.with(getQb_mainActivity()).load(profile)
                                .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                                .into(qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView());
                    }else{//동영상일 경우
                        qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView().setImageResource(R.drawable.profile_stuff);
                    }

                    qb_viewPageAdapter.getSurroundingDeliveryPageView().phoneNumber = result.get(0).get(0);
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getNameText().setText(result.get(1).get(0));
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getNameText().setText("품 목 : " + result.get(5).get(0) + "\n");
                    String memo = "없음";
                    if(!result.get(3).get(0).matches("null")) {
                       memo = result.get(3).get(0);
                    }
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText("메 모 : " + memo);
                   //
                } else {
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getProfileImageView().setImageResource(R.drawable.profile_stuff);
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getNameText().setText("품 목 : 없음\n");
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getMemoText().setText("메 모 : 없음");
                }
            }
        };
        jsonParse.getJsonParse(getFreightnfo(freight_idx));
    }


    private QB_MainActivity getQb_mainActivity(){
        return this;
    }

    /* 홈 페이지의 왼쪽 사이드 검색 필터 레이아웃 열리는 에니메이션
 *
 * */
    public void onOpenLeftDrawer()
    {
        drawerLayout.openDrawer(leftRL);
    }

    /* 홈 페이지의 왼쪽 사이드 검색 필터 레이아웃 닫히는 애니메이션
*
* */
    public void onCloseLeftDrawer(){
        drawerLayout.closeDrawer(leftRL);
    }

    /* 즐겨찾기 페이지의 오른쪽 검색 필터 레이아웃 열리는 애니메이션
    *
   * */
    public void onOpenRightDrawer(){
        drawerLayout.openDrawer(rightRL);
    }
    /* 즐겨찾기 페이지의 오른쪽 검색 필터 레이아웃 닫히는 애니메이션
  *
 * */
    public void onCloseRightDrawer(){
        drawerLayout.closeDrawer(rightRL);
    }


    /* 배송안한 화물리스트 가져오기
*
* */
    private void RequestFreightList(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    if(result.size()>0) {
                        setFreightInfos(result);
                    }
                }else{
                    Log.d(TAG,"대기중인 화물 없음");
                    Toast.makeText(getQb_mainActivity(),"배송대기중인 화물이 없습니다.",Toast.LENGTH_SHORT).show();
                }
                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestFreightList());
    }
    /* 배송안한 화물리스트 url
    *
    * */
    private String getRequestFreightList(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.MYFREIGHT_LIST;
        urlStr = urlStr+"?user_idx="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr +"&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        return urlStr;
    }
    private String getRequestFreightDeliveryUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_MYFREIGHT_DELIVERY;
        urlStr = urlStr + "?delivery_idx=" + delivery_idx;
        urlStr = urlStr + "&freight_idx=" + freight_idx;
        Log.d(TAG, "getRequestFreightDeliveryUrlStr : " + urlStr);
        return urlStr;
    }
    /* 화물리스트 정보 분류하기
    *
    * */
    private void setFreightInfos(ArrayList<ArrayList<String>> result){
        freightInfos.clear();
        String freightName[] = new String[result.get(0).size()];
        for(int i=0;i<result.get(0).size();i++){
            Log.d(TAG, "freight_idx : " + result.get(0).get(i));
            Log.d(TAG, "freight_name : " + result.get(1).get(i));
            FreightInfo freightInfo = new FreightInfo();
            freightInfo.setFreight_idx(result.get(0).get(i));
            freightInfo.setFreight_name(result.get(1).get(i));
            freightName[i] = freightInfo.getFreight_name();
            freightInfos.add(freightInfo);
        }
        showFreightList(freightName);
    }
    /** 화물리스트 다이얼로그 보여주기
     *
     */
    private void showFreightList(String freightName[]){
        SelectListDialog selectListDialog = new SelectListDialog(this, freightName);
        selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
            @Override
            public void onClickCancel() {

            }

            @Override
            public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                freight_idx = freightInfos.get(position).getFreight_idx();

                selectListDialog.dismiss();
                Log.d(TAG, "position : " + titlelist[position] + " freight_idx : " + freight_idx);
                updateFreightDelivery();
            }

            @Override
            public void onClickList(int position, View view, String[] titlelist) {
                //  view.setBackgroundColor(Color.BLUE);


            }
        });
        selectListDialog.getTitleImage().setImageResource(R.drawable.icon_car_white);
        selectListDialog.getTitleText().setText("화물선택");
        selectListDialog.show();
    }
    /* 배송자에게 내화물 배송 신청하기
*
* */
    private void updateFreightDelivery(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag + " message : " + message);
                if(flag.matches("1")){
                    Toast.makeText(getQb_mainActivity(),"배송자에게 배송을 신청하였습니다.",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getQb_mainActivity(),message,Toast.LENGTH_SHORT).show();
                }

                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestFreightDeliveryUrlStr());
    }


    /* 화물에게 배송 희망하기 url
    *
    * */
    private String getRequestDeliveryFreightUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_MYDELIVERY_FREIGHT;
        urlStr = urlStr + "?delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        urlStr = urlStr + "&freight_idx=" + freight_idx;
        Log.d(TAG, "getRequestDeliveryFreightUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송자에게 내화물 배송 신청하기
 *
 * */
    private void updateDeliveryFreight(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Toast.makeText(getQb_mainActivity(), "화물 배송을 신청하였습니다.", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getQb_mainActivity(), message, Toast.LENGTH_SHORT).show();
                }


                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestDeliveryFreightUrlStr());
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK)
            return;
        Log.d(TAG, "onActivityResult : " + requestCode);

        switch (requestCode) {
            case PICK_FROM_ALBUM: {
                devicePicture.setmImageCaptureUri(data.getData());

             //  qb_viewPageAdapter.getMyPageView().setProfile_img(PictureUpload.reSize(getPath(data.getData()), 100, 100));
                Log.d(TAG,"mypage profile path : " + getPath(data.getData()));
             /*   Bitmap profile = PictureUpload.reSize(getPath(data.getData()), 100, 100);
                Bitmap circleBitmap = Bitmap.createBitmap(profile.getWidth(), profile.getHeight(), Bitmap.Config.ARGB_8888);

                BitmapShader shader = new BitmapShader(profile,  Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
                Paint paint = new Paint();
                paint.setShader(shader);

                Canvas c = new Canvas(circleBitmap);
                c.drawCircle(profile.getWidth()/2, profile.getHeight()/2, profile.getWidth()/2, paint);*/
              //  qb_viewPageAdapter.getMyPageView().setImage_path(getPath(data.getData()));
               // qb_viewPageAdapter.getMyPageView().setProfileImage(circleBitmap);
                pictureUpload(getPath(data.getData()));
                Log.d(TAG, "PICK_FROM_ALBUM");
            }

            case PICK_FROM_CAMERA: {
                devicePicture.pickFromCamera();
                Log.d(TAG, "PICK_FROM_CAMERA");
            }

            case CROP_FROM_iMAGE: {
                Log.d(TAG, "CROP_FROM_iMAGE");
                if (resultCode != RESULT_OK) {
                    return;
                }
                break;
                //  devicePicture.cropFromImage(data,profileImageView);
            }
            case RELOAD_WEBVIEW:{
                try {
                    int point = Integer.parseInt(qb_viewPageAdapter.getMyPageView().getPointText().getText().toString()) + Integer.parseInt(data.getStringExtra("point"));
                    qb_viewPageAdapter.getMyPageView().getPointText().setText(""+point);
                    qb_viewPageAdapter.getHomePageView().getHomePageWebView().getWebView().reload();
                    qb_viewPageAdapter.getBookMarkPageView().getBookMarkPageWebView().getWebView().reload();
                }catch (NullPointerException e){
                    Log.d(TAG,e.toString());
                }catch (NumberFormatException e){
                    Log.d(TAG,e.toString());
                }

                break;
            }

        }
    }
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
              loading.dismiss();
            }else if(msg.what == 1){
                loading.show();
            }else if(msg.what == 2){

                if(qb_viewPageAdapter.getSurroundingDeliveryPageView().getSearchFlag() == qb_viewPageAdapter.getSurroundingDeliveryPageView().SEARCH_DELIVERY){
                    deliveryInfo(qb_viewPageAdapter.getSurroundingDeliveryPageView().search_idx);//주변검색 배송자 정보 가져오기
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getLinelinear().setBackgroundColor(qb_viewPageAdapter.getSurroundingDeliveryPageView().deliveryColor);
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getRequestDeliverybtn().setText("배송신청");
                }else{
                    freightInfo(qb_viewPageAdapter.getSurroundingDeliveryPageView().search_idx);//주변검색 화물정보가져오기
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getLinelinear().setBackgroundColor(qb_viewPageAdapter.getSurroundingDeliveryPageView().freightColor);
                    qb_viewPageAdapter.getSurroundingDeliveryPageView().getRequestDeliverybtn().setText("배송신청");
                }

                qb_viewPageAdapter.getSurroundingDeliveryPageView().upAniMove(qb_viewPageAdapter.getSurroundingDeliveryPageView().getDelivery_plinear());
                qb_viewPageAdapter.getSurroundingDeliveryPageView().setDpState(true);
            }else if(msg.what ==3){
                qb_viewPageAdapter.getMyPageView().profileReload();
            }
        }
    };


    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "destory");
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
    /*
 * 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
 * */
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Log.d("onBack", "backpress");
        backPressClose.CloseOnBackPressed();
    }
}
