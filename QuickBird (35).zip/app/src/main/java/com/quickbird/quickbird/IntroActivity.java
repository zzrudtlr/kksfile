package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Display;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import Database.DB_SingleTon;
import Dialog.Loading;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-02.
 * 인트로 페이지
 */
public class IntroActivity extends Activity {
    private final String TAG = "IntroActivity";

    private LinearLayout logo_linear;//움직이는 로고
    private ImageView introimageView;
    private ImageView logoimageView;//배경 로고

    private int fromWidth = 0;

    private TimerTask mTask;
    private Timer mTimer;

    private int logoAlpha = 0;//배경로고 현재 알파값
    private final int MAXAlpha = 200;//배경 로고 최대 알파값

    private Loading loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        loading = new Loading(this);
        //initAnimation();
        initAnimation();
        initLogoAnimation();
//      Log.d(TAG, "Activity size : " + introimageView.getMaxWidth());
      // onNextPage();
    }

    /* 배경로고가 점점보이는 애니메이션
    *
    * */
    private void initLogoAnimation(){
        logoimageView = (ImageView)findViewById(R.id.background_logo);
        /*Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.alpha_anim);
        logoimageView.startAnimation(anim);*/
        mTask = new TimerTask() {
            @Override
            public void run() {
                new GetData().execute();

            }
        };
        mTimer = new Timer();
        mTimer.schedule(mTask, 0, 100);//0.1초당 한번씩 이미지 바꿈*/

    }

    /* 움직이는 로고가 움직이는 에니메이션
    *
    * */
    private void initAnimation(){
        logo_linear = (LinearLayout)findViewById(R.id.logo_layout);
        introimageView = (ImageView)findViewById(R.id.introImageView);


        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        fromWidth = size.x;

        movewAnimation(logo_linear);
    }

    /* 다음 페이지로 넘어감
    *
    * */
    private void onNextPage(){
        Handler hd = new Handler();
        hd.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().getCheck()) {
                    Log.d(TAG, "getLoginState : " + DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().getLoginState());
                    idCheck();
                    Log.d(TAG, "유저 정보 있음");
                } else {
                    IntroActivity.this.startActivity(new Intent(IntroActivity.this, OptionGuideActivity.class));
                    IntroActivity.this.finish();
                    Log.d(TAG, "유저 정보 없음");
                }

            }
        }, 1000);
    }

    /* 레이아웃 에니메이션 효과
    *
    * */
    public void movewAnimation(LinearLayout linearLayout){
        TranslateAnimation move = new TranslateAnimation
                (0,   // fromXDelta
                        fromWidth+100,  // toXDelta
                        0,    // fromYDelta
                        0);// toYDelta
        move.setDuration(1000);
        move.setFillAfter(true);
        linearLayout.startAnimation(move);

    }

    /* 아이디 유무 체크 url
    *
    * */
    private String getIdCheckUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.ID_CHECK;
        urlStr = urlStr + "?idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&fcm_key="+ FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG,"getIdCheckUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송자 유무 체크 url
    *
    * */
    private String getDeliveryCheckUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_CHECK;
        urlStr = urlStr + "?delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        return urlStr;
    }
    /* 아이디  유무 체크
    *
    * */
    private void idCheck(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                handler.sendEmptyMessage(1);//로딩 시작
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);

                if (flag.matches("1")) {
                    Log.d(TAG,"profile_img : " + result.get(0).get(0));
                    DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().updateProfileImage(result.get(0).get(0));
                    handler.sendEmptyMessage(0);//배송자 유무 체크
                } else {
                    DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().deleteAllColumns();
                    IntroActivity.this.startActivity(new Intent(IntroActivity.this, LoginActivity.class));
                    IntroActivity.this.finish();
                 //  Toast.makeText(getIntroActivity(), "로그인 실패", Toast.LENGTH_SHORT).show();
                }

            }
        };
        jsonParse.getJsonParse(getIdCheckUrlStr());
    }

    /* 배송자 유무 체크
    *
    * */
    private void deliveryCheck(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                if (flag.matches("1")) {
                } else {
                    DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().updateDeliveryIdx("0");
                }

                handler.sendEmptyMessage(2);//로딩 종료

                if (DB_SingleTon.getInstance(getIntroActivity()).getUserInfoTable().getLoginState().matches("1")) {//자동로그인일 경우
                    Log.d(TAG, "");
                    Toast.makeText(getIntroActivity(), "로그인 성공", Toast.LENGTH_SHORT).show();
                    IntroActivity.this.startActivity(new Intent(IntroActivity.this, QB_MainActivity.class));
                    IntroActivity.this.finish();
                } else {
                    //  DB_SingleTon.getInstance(IntroActivity.this).getUserInfoTable().deleteAllColumns();
                    IntroActivity.this.startActivity(new Intent(IntroActivity.this, LoginActivity.class));
                    IntroActivity.this.finish();
                }


            }
        };
        jsonParse.getJsonParse(getDeliveryCheckUrlStr());
    }

    private IntroActivity getIntroActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "destory");
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
      //  unregisterReceiver(mPackageReceiver);

    }

    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            // btnState = true;
            if(msg.what == 0) {
                deliveryCheck();
            }else if(msg.what==1){
                loading.show();
            }else if(msg.what == 2){
                loading.dismiss();
            }
        }
    };

    /*
  * 서버의 정보를 받아오기 위한 비동기 스레드 inner클래스
  * */
    public class GetData extends AsyncTask<String, ArrayList<String>, String> {


        public GetData(){

        }
        public GetData(String urlStr,String body){

        }
        @Override
        protected void onCancelled() {
            super.onCancelled();
        }


        @Override
        protected String doInBackground(String... params) {
            String data = "";
            logoAlpha = logoAlpha + 10;
            if(logoAlpha >= MAXAlpha){
                logoAlpha = MAXAlpha;
            }
            return data;
        }
        @Override
        protected void onPostExecute(String result){
            super.onPostExecute(result);
            try {
                Drawable logoAlphaD = logoimageView.getBackground();
                logoAlphaD.setAlpha(logoAlpha);
                if (logoAlpha == MAXAlpha) {
                    mTimer.cancel();
                    onNextPage();
                }
                Log.d(TAG, "logoAlpha : " + logoAlpha);
            }catch (Exception e){
                Log.d(TAG, "Exception : " + e.toString());
            }
        }
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(ArrayList<String>... values) {
            super.onProgressUpdate(values);
        }
    }
}
