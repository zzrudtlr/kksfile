package com.quickbird.quickbird;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;

import Database.DB_SingleTon;
import Dialog.Loading;
import WebView.WebViewClass;
import connection.Conn_Address;
import WebView.OnWebViewClientListener;
/**
 * Created by KyoungSik on 2017-09-03.
 * 공지사항
 */
public class NoticeActivity extends Activity {

    private final String TAG = "NoticeActivity";

    private WebViewClass webViewClass;
    private Loading loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);
        loading = new Loading(getNoticeActivity());
        loading.show();
        init();

    }
    //내가 등록한 화물 웹뷰 셋팅
    private void init() {
        webViewClass = new WebViewClass((WebView) findViewById(R.id.noticewebview), this, getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {

            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });
    }

    /* 내가등록한 화물 url
*
* */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.NOTICE;
        Log.d(TAG, "getUrlStr :" + urlStr);
        return urlStr;
    }

    private NoticeActivity getNoticeActivity(){
        return this;
    }
}
