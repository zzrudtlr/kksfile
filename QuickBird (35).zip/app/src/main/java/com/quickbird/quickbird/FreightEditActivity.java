package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewSwitcher;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import Dialog.ConfirmDialog;
import Dialog.Loading;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Permission.DevicePermission;
import Picture.MultiplePicture.Action;
import Picture.MultiplePicture.CustomGallery;
import Picture.MultiplePicture.CustomGalleryAdapter;
import Picture.PictureUpload;
import WebView.KeboardControll;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.AppNetWrok;
import connection.Conn_Address;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 화물 정보 수정하기
 */
public class FreightEditActivity extends Activity {

    private final String TAG = "FreightEditActivity";

    private final int galleryItemWidth = 300;//그리드 뷰 아이템 기본 크기

    private final int APP_PERMISSION_STORAGE = 0;
    private final int SELECT_PICTURE=1;
    private final int SELECT_MOVIE = 2;
    private final int SELECT_CAPTURE = 3;
    public final int SELECT_ADDRESS_MAP=4;

    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;

    private final int MAXVIDEOSECONDS = 5;

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;
    private LinearLayout no_select_linear;//사진 및 동영상 첨무 안되 있을떄 보여주는 view

    private GridView gridGallery;
    private CustomGalleryAdapter adapter;
    private ArrayList<String> imagePaths;

    private ViewSwitcher viewSwitcher;//이미지뷰들과와 동영상뷰를 담은 뷰
    private VideoView videoView;//동영상보여주는 view
    private ImageLoader imageLoader;

    private String uploadImageName="";
    private int imageUploadCount = 0;

    private LinearLayout pvLienar;

    private String video_path;
    private boolean imgvideoSelected = false;

    private DevicePermission devicePermission;//접근허용
    private boolean pm_permission = false;//이미지 및 동영상 업로드 가능 여부
    private int statePv;//이미지 동영상 구분
    private int spap_state=0;//출발지 도착지 구분
    private String freight_idx="";
    private boolean image_video_change = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freightinfo_edit);
        freight_idx = getIntent().getStringExtra("freight_idx");
        init();
    }

    private void init(){
        initImageLoader();
        loading = new Loading(this);
        errorView = (LinearLayout)findViewById(R.id.fe_errorview);
        no_select_linear = (LinearLayout)findViewById(R.id.no_select_linear);
        //  devicePicture = new DevicePicture(this);

        gridGallery = (GridView) findViewById(R.id.gridGallery);
        gridGallery.setFastScrollEnabled(true);
        adapter = new CustomGalleryAdapter(getApplicationContext(), imageLoader);
        adapter.setMultiplePick(false);

        gridGallery.setAdapter(adapter);



        viewSwitcher = (ViewSwitcher) findViewById(R.id.viewSwitcher);

        pvLienar = (LinearLayout)findViewById(R.id.pvlienar);
        viewSwitcher.setDisplayedChild(0);
        devicePermission = new DevicePermission();
        videoViewinit();
        webViewinit();
        buttonEvent();
        keyboardControll();
    }


    private MediaPlayer.OnVideoSizeChangedListener onVideoSizeChangedListener =
            new MediaPlayer.OnVideoSizeChangedListener() {
                public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                            500);
                    lp.gravity = Gravity.CENTER;
                    videoView.setLayoutParams(lp);

                }
            };


    private void videoViewinit(){
        videoView = (VideoView)findViewById(R.id.frvideoView);
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setOnVideoSizeChangedListener(onVideoSizeChangedListener);

                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                        500);
                lp.gravity = Gravity.CENTER;
                videoView.setLayoutParams(lp);
                // 재생시간표시...msec
                Log.d("test", "onPrepared getDuration = " + mp.getDuration());
                int totalSeconds = mp.getDuration() / 1000;
                int seconds = totalSeconds % 60;
                if (MAXVIDEOSECONDS < seconds) {
                    Toast.makeText(getFreighEditActivity(), "동영상 길이는 최대 5초입니다.", Toast.LENGTH_SHORT).show();
                    pm_permission = false;
                } else {
                    pm_permission = true;
                }
            }
        });
      /*  viewSwitcher.setDisplayedChild(1);
        String video_url = "http://lbcontents.com/quickbird/img/146152667797028.avi";
        Uri uri = Uri.parse(video_url);
        videoView.setVideoURI(uri);
        videoView.requestFocus();
        videoView.start();*/

    }

    private void initImageLoader() {
        // for universal image loader
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisc().imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
                .bitmapConfig(Bitmap.Config.RGB_565).build();
        ImageLoaderConfiguration.Builder builder = new ImageLoaderConfiguration.Builder(
                this).defaultDisplayImageOptions(defaultOptions).memoryCache(
                new WeakMemoryCache());

        ImageLoaderConfiguration config = builder.build();
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(config);
    }


    //동영상선택
    private void doSelectMovie(){
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try{
            startActivityForResult(i, SELECT_MOVIE);
        }catch (android.content.ActivityNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    private void keyboardControll(){
        final KeboardControll softKeyboardDecector = new KeboardControll(this);
        addContentView(softKeyboardDecector, new FrameLayout.LayoutParams(-1, -1));

        softKeyboardDecector.setOnShownKeyboard(new KeboardControll.OnShownKeyboardListener() {

            @Override
            public void onShowSoftKeyboard() {
                //키보드 등장할 때
                Log.d(TAG, "onShowSoftKeyboard : ");

            }
        });

        softKeyboardDecector.setOnHiddenKeyboard(new KeboardControll.OnHiddenKeyboardListener() {

            @Override
            public void onHiddenSoftKeyboard() {
                // 키보드 사라질 때
                Log.d(TAG, "onHiddenSoftKeyboard : ");

            }
        });
    }

    /* 버튼 이벤트
  *
  * */
    private void buttonEvent(){
        Button cancelbtn = (Button)findViewById(R.id.fecancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getFreighEditActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });

        Button exitbtn = (Button)findViewById(R.id.feexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button picturemovebtn = (Button)findViewById(R.id.fepvbtn);
        picturemovebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreighEditActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                        viewSwitcher.setDisplayedChild(0);
                        if (devicePermission.checkPermission(getFreighEditActivity())) {
                            statePv = SELECT_PICTURE;//사진 업로드 상태
                           // Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                         //   startActivityForResult(i, 200);
                            selectPicture();

                        }
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        if (devicePermission.checkPermission(getFreighEditActivity())) {
                            statePv = SELECT_MOVIE;//동영상 업로드 상태
                            selectMovie();
                        }
                       // viewSwitcher.setDisplayedChild(1);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("이미지");
                selectTwoDialog.getSelectTwoButton().setText("동영상");
                selectTwoDialog.show();
            }
        });

        /* 수정하기 버튼
        *
        * */
        Button registerbtn = (Button)findViewById(R.id.feregisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //  sendRegister();
                sendExption();
            }
        });
    }

    /* 배송자 등록하기 입력폼 웹 뷰
      *
      * */
    private void webViewinit(){
        webViewClass = new WebViewClass((WebView)findViewById(R.id.fewebview),this,getFreightStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });


        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void map(int state) {
                spap_state = state;//출발지 도착지 구분
                Log.d(TAG, "map");
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreighEditActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                        selectInternatinl(DOMESTIC);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                        selectInternatinl(OVERSEAS);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
                //  handler.sendEmptyMessage(0);

            }

            @JavascriptInterface
            public void message(String message) {
                Log.d(TAG, "messagev : " + message);
                Toast.makeText(getFreighEditActivity(), message, Toast.LENGTH_SHORT).show();
            }

            @JavascriptInterface
            public void save_file() {
                Log.d(TAG, "save_file");
            }

            @JavascriptInterface
            public void qb_exeption(boolean flag) {
                Log.d(TAG, "qb_exeption test : " + flag);

                if (exception(flag)) {
                    handler.sendEmptyMessage(6);
                    if (image_video_change) {//이미지 변경함
                        handler.sendEmptyMessage(4);
                    } else {//이미지 변경안함
                        handler.sendEmptyMessage(5);
                    }
                }
            }

            @JavascriptInterface
            public void complete_del(String result) {
                Log.d(TAG, " complete_del result : " + result);
            }

            @JavascriptInterface
            public void result(String result) {
                Log.d(TAG, "result : " + result);
                //  handler.sendEmptyMessage(3);//pictureUpload에서 로딩 시작
                handler.sendEmptyMessage(7);//로딩 종료
                if (result.contains("1")) {
                    Toast.makeText(getFreighEditActivity(), "화물수정을 완료하였습니다.", Toast.LENGTH_SHORT).show();
                    if (image_video_change) {//이미지 및 동영상 변경이 있었을 경우
                        handler.sendEmptyMessage(8);
                    }
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    Toast.makeText(getFreighEditActivity(), "화물수정을 실패하였습니다.", Toast.LENGTH_SHORT).show();
                }
            }

            @JavascriptInterface
            public void setProfile(String profile_img, String flag) {
                //   profileimage_name = profile_img;uploadImageName
                // profile_img = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + profile_img;

                uploadImageName = profile_img;
                Log.d(TAG, "profile_img : " + profile_img + " flag : " + flag);
                if (flag.matches("0")) {//이미지일 경우
                    statePv = SELECT_PICTURE;
                    handler.sendEmptyMessage(2);//
                } else if (flag.matches("1")) {//동영상일 경우
                    statePv = SELECT_MOVIE;
                    handler.sendEmptyMessage(3);
                }
                //   setProfileImageView(profile_img);
            }

        }, "quickbird");
    }
    //이미지 촬영 후 가져오기
    private void doImagePicture(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, SELECT_CAPTURE);

    }
    //사진 상태 선택하기
    private void selectPicture(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreighEditActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                // doFilmingMovie();
                doImagePicture();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                startActivityForResult(i, 200);
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("이미지 촬영");
        selectTwoDialog.getSelectTwoButton().setText("이미지 앨범");
        selectTwoDialog.show();
    }
    //동영상 상태 선택
    private void selectMovie(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreighEditActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                doFilmingMovie();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                doSelectMovie();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("동영상 촬영");
        selectTwoDialog.getSelectTwoButton().setText("동영상 앨범");
        selectTwoDialog.show();
    }
    //동영상 촬영하기
    private void doFilmingMovie(){
        //내장카메라 호출
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        //동영상 품질
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        //동영상 시간 제한
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 5);// 시간
        //동영상 용량 제한
        intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, (long) (1024 * 1024 * 4));// 용량
        //동영상 저장 경로
        String mImageMovieUri = "/sdcard/Download/exam/";
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
                mImageMovieUri);
        startActivityForResult(intent, SELECT_MOVIE);
    }


    private void setFreightVideo(String uploadImageName){
        viewSwitcher.setDisplayedChild(1);
        Uri uri = Uri.parse(uploadImageName);
        videoView.setVideoURI(uri);
        videoView.requestFocus();
        videoView.start();
    }

    private void setFreightImage(String uploadImageName){

    }

    private boolean exception(boolean check){

        if(check){
           if((statePv == SELECT_MOVIE) && !pm_permission){
                check = false;
                Toast.makeText(getFreighEditActivity(), "동영상은 최대 5초입니다.", Toast.LENGTH_SHORT).show();
            }
        }
        return check;
    }

    /* 국내, 국외 구분 함수
  *
  * */
    private void selectInternatinl(int countryState) {
        if (countryState == DOMESTIC) {
            handler.sendEmptyMessage(0);
        } else if (countryState == OVERSEAS) {
            handler.sendEmptyMessage(1);
        }
    }

    /* 출발지 정보 웹뷰로 보내기
    *
    * */
    private void sendSPpoint(String lng, String lat, String address,int state) {
        webViewClass.getWebView().loadUrl("javascript:sp_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }


    /* 도착지 정보 웹뷰로 보내기
    *
    * */
    private void sendAPpoint(String lng, String lat, String address,int state){
        webViewClass.getWebView().loadUrl("javascript:ap_point(" + lng + "," + lat + ",'" + address + "'," + state + ");");
    }

    /* 등록하기
     *
     * */
    private void sendRegister(){
        webViewClass.getWebView().loadUrl("javascript:register();");
    }

    /* 웹 예외처리
    *
    * */
    private void sendExption(){
        webViewClass.getWebView().loadUrl("javascript:qb_exeption();");
    }

    /* 이미지 이름 보내기
   *
   * */
    private void sendImageName(String imgName){
        webViewClass.getWebView().loadUrl("javascript:img_insert('"+imgName+"');");
    }

    /* 동영상 이름 보내기
   *
   * */
    private void sendVideoName(String videoName){
        webViewClass.getWebView().loadUrl("javascript:video_insert('"+videoName+"');");
    }
    /* 기존 이미지 삭제
     *
     * */
    private void deleteImage(){
        webViewClass.getWebView().loadUrl("javascript:delete_img();");
    }


    /* 지도 선택 다이얼로그 띄우기
    *
    * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            // btnState = true;
            if(msg.what == 0) {
              /*  SelectAddressDialog selectAddressDialog = new SelectAddressDialog(getFreighEditActivity()) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        if (spap_state == 0) {
                            sendSPpoint(lat, lng, address,DOMESTIC);
                        } else if (spap_state == 1) {
                            sendAPpoint(lat, lng, address,DOMESTIC);
                        }
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();*/
                Intent intent = new Intent(FreightEditActivity.this,SelectAddressActivity.class);
                startActivityForResult(intent, SELECT_ADDRESS_MAP);
            }else if(msg.what == 1){
                String[] country;
                Locale[] locales = Locale.getAvailableLocales();

                String[] isoCodes = Locale.getISOCountries();
                country = new String[isoCodes.length];

                for (int i = 0; i < isoCodes.length; i++) {
                    Locale locale = new Locale("en", isoCodes[i]);
                    Log.d(TAG, "country : " + locale.getDisplayCountry());
                    country[i] = locale.getDisplayCountry();
                }
                //나라 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(getFreighEditActivity(), country);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                        String address = selectListDialog.getSubTitleText().getText().toString()+selectListDialog.getSubAddressEdit().getText().toString();
                        if(spap_state == 0) {
                            sendSPpoint("0","0",address,OVERSEAS);
                        }else if(spap_state == 1){
                            sendAPpoint("0","0",address,OVERSEAS);
                        }
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);

                    }
                });
                selectListDialog.getTitleImage().setVisibility(View.GONE);
                selectListDialog.getTitleText().setText("나라 선택");
                selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
                selectListDialog.show();
            }else if(msg.what ==2){
                String image_url[] = uploadImageName.split("/");
                ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
                for(int i=0;i<image_url.length;i++){
                    CustomGallery customGallery = new CustomGallery();
                    customGallery.webImagePath = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + image_url[i];
                    Log.d(TAG,"webImagePath : " + customGallery.webImagePath);
                    dataT.add(customGallery);
                }

                viewSwitcher.setDisplayedChild(0);
                adapter.setImage_state(adapter.WEB_IMAGE);
                adapter.addAll(dataT);
                no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
            }else if(msg.what ==3){
                viewSwitcher.setDisplayedChild(1);
               String video_p = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + uploadImageName;
                Uri uri = Uri.parse(video_p);
                videoView.setVideoURI(uri);
                videoView.requestFocus();
                no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                videoView.start();
            }else if(msg.what ==4){
                if (AppNetWrok.networkCheck(getFreighEditActivity())) {
                    if (statePv == SELECT_PICTURE) {
                        fregithPitureUpload();
                    } else if (statePv == SELECT_MOVIE) {
                        fregithVideoUpload(video_path);
                    }
                } else {
                    Toast.makeText(getFreighEditActivity(), "네트워크를 확인해주세요.", Toast.LENGTH_SHORT).show();
                }
            }else if(msg.what == 5){
                if (statePv == SELECT_PICTURE) {
                    sendImageName(uploadImageName);
                } else if (statePv == SELECT_MOVIE) {
                    sendVideoName(uploadImageName);
                }

                sendRegister();

            }else if(msg.what == 6){
                loading.show();
            }else if(msg.what == 7){
                loading.dismiss();
            }else if(msg.what == 8){
                deleteImage();
            }
        }
    };

    private String getFreightStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.FREIGHTEDIT;
        webUrlStr = webUrlStr + "?freight_idx=" + freight_idx;
        Log.d(TAG, "getFreightStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 화물 이미지들 업로드
  *
  * */
    private void fregithPitureUpload(){
        loading.show();
        uploadImageName = "";//이미지 이름 초기화
        imageUploadCount = 0;//이미지 업로드 카운트 초기화

        Iterator<String> itr = imagePaths.iterator();
        Log.d(TAG, "Iterator : " + imagePaths.size());

        while(itr.hasNext()){
            String str[][] = {{"fileName", ""},{"target_dir","image/"}};
            String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
            PictureUpload pu = new PictureUpload(url,itr.next()) {
                @Override
                public void finishUpload(String pictureName) {
                    try {
                        JSONObject jsonObject = new JSONObject(pictureName);
                        Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                        Log.d(TAG, "message : " + jsonObject.getString("message"));
                        if(jsonObject.getString("flag").matches("1")){
                            makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                        }
                        uploadCount();//업로드된 이미지 갯수 체크
                        if(imageUploadCount == imagePaths.size()){//모든 이미지 업로드 완료
                            Log.d(TAG, "imageUploadCount : " + imageUploadCount + " imagePaths.size() : " + imagePaths.size());
                            Log.d(TAG, "uploadImageName : " + uploadImageName);
                            sendImageName(uploadImageName);
                            sendRegister();
                            //     loading.dismiss();

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void errorUpload(String errorCode) {
                    loading.dismiss();
                }
            };//섬네일 이미지 사진업로드
            pu.uploadVideo();
        }
    }

    /* 화물 이미지들 업로드
     *
     * */
   /* private void fregithPitureUpload(){
        uploadImageName = "";//이미지 이름 초기화
        imageUploadCount = 0;//이미지 업로드 카운트 초기화
        Iterator<String> itr = imagePaths.iterator();
        while(itr.hasNext()){
            String str[][] = {{"fileName", ""},{"target_dir","image/"}};
            String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;

            PictureUpload pu = new PictureUpload(PictureUpload.reSize(itr.next(), 100, 100), url, str) {
                @Override
                public void finishUpload(String pictureName) {
                    try {
                        JSONObject jsonObject = new JSONObject(pictureName);
                        Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                        Log.d(TAG, "message : " + jsonObject.getString("message"));
                        if(jsonObject.getString("flag").matches("1")){
                            makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                        }
                        uploadCount();//업로드된 이미지 갯수 체크
                        if(imageUploadCount == imagePaths.size()){//모든 이미지 업로드 완료
                            sendImageName(uploadImageName);
                            sendRegister();
                            //     loading.dismiss();

                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void errorUpload(String errorCode) {
                   handler.sendEmptyMessage(7);
                }
            };//섬네일 이미지 사진업로드
            pu.uploadPicture();
        }
    }*/

    /* 화물 동영상 업로드
    *
    * */
    private void fregithVideoUpload(String path){
        uploadImageName = "";
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADVIDEO;
        PictureUpload pu = new PictureUpload(url, path) {
            @Override
            public void finishUpload(String pictureName) {
                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG, "message : " + jsonObject.getString("message"));
                    if(jsonObject.getString("flag").matches("1")){
                        makeSplitImageName(jsonObject.getString("message"));//업로드된 이미지 이름
                    }
                    Log.d(TAG,"uploadImageName : " + uploadImageName);
                    sendVideoName(uploadImageName);
                    sendRegister();
                    //  loading.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                handler.sendEmptyMessage(7);
            }
        };//섬네일 이미지 사진업로드
        pu.uploadVideo();

    }

    /* 업로드된 이미지 카운트
    *
    * */
    private void uploadCount(){
        imageUploadCount++;
    }
    /* 이미지 이름 스플릿으로 만들기
    *
    * */
    private void makeSplitImageName(String profileName){
        if(uploadImageName.equals("")){
            uploadImageName = profileName;
        }else{
            uploadImageName = uploadImageName + "/" + profileName;
        }
        Log.d(TAG,"uploadImageName : " + uploadImageName);
    }

    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }


    private FreightEditActivity getFreighEditActivity(){
        return this;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        imagePaths = new ArrayList<String>();
        if (requestCode == 200 && resultCode == Activity.RESULT_OK) {

            String[] all_path = data.getStringArrayExtra("all_path");
            float scale = this.getBaseContext().getResources().getDisplayMetrics().density;
            int dp = (int)(300/scale)*all_path.length;

            //그리드 뷰 아이템 개수에 따라 크기 설정
           // LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(1000, LinearLayout.LayoutParams.WRAP_CONTENT);
           // gridGallery.setNumColumns(all_path.length);
            //gridGallery.setLayoutParams(gridParams);


            ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
            for (String string : all_path) {
                CustomGallery item = new CustomGallery();
                item.sdcardPath = string;
                imagePaths.add(string);
                dataT.add(item);
                no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
            }
            viewSwitcher.setDisplayedChild(0);
            adapter.setImage_state(adapter.ANDROID_IMAGE);
            adapter.addAll(dataT);
            imgvideoSelected = true;
            image_video_change = true;
        }else if(requestCode == SELECT_CAPTURE){//사진 촬영후 이미지 가져오기
            imagePaths.clear();
            Uri uri = data.getData();
            String imagePath = getPath(uri);
            ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();
            CustomGallery item = new CustomGallery();
            item.sdcardPath = imagePath;
            imagePaths.add(imagePath);
            dataT.add(item);
            viewSwitcher.setDisplayedChild(0);
            no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
            adapter.setImage_state(adapter.ANDROID_IMAGE);
            adapter.addAll(dataT);
            imgvideoSelected = true;
            image_video_change = true;
        } else if(requestCode == APP_PERMISSION_STORAGE){
            Log.d(TAG, "APP_PERMISSION_STORAGE");
            if(statePv == SELECT_PICTURE) {
                Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                startActivityForResult(i, 200);
            }else{
                doSelectMovie();
            }
        }else if(requestCode == SELECT_MOVIE){
            try {
                imgvideoSelected = true;
                image_video_change = true;
                Uri uri = data.getData();

                String path2 = Environment.getExternalStorageDirectory()
                        + "/TestVidio6.mp4";
                if (getPath(uri) == null) {
                    Toast.makeText(this, "동영상은 갤러리에서 선택을 해주세요.", Toast.LENGTH_SHORT).show();
                } else {
                    viewSwitcher.setDisplayedChild(1);
                    Log.d(TAG, "video url : " + uri.toString());
                    Log.d(TAG, "video path : " + getPath(uri));
                    video_path = getPath(uri);
                    videoView.setVideoURI(uri);
                    no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                    videoView.start();
                }
               /* viewSwitcher.setDisplayedChild(1);
                Log.d(TAG, "video url : " + uri.toString());
                Log.d(TAG, "video path : " + getPath(uri));
                video_path = getPath(uri);
                videoView.setVideoURI(uri);
                no_select_linear.setVisibility(View.GONE);//사진및 동영상 없음 이미지 없앰
                videoView.start();*/
            }catch (NullPointerException e){
                Log.d(TAG,e.toString());

            }

        }else if(requestCode == SELECT_ADDRESS_MAP) {//국내 주소 선택
            try {
                Log.d(TAG, "lat : " + data.getStringExtra("lat") + "lng : " + data.getStringExtra("lng") + "address : " + data.getStringExtra("address"));
                if (spap_state == 0) {
                    sendSPpoint(data.getStringExtra("lat"), data.getStringExtra("lng"), data.getStringExtra("address"), DOMESTIC);
                } else if (spap_state == 1) {
                    sendAPpoint(data.getStringExtra("lat"), data.getStringExtra("lng"), data.getStringExtra("address"), DOMESTIC);
                }
            }catch (NullPointerException e){
                Log.d(TAG,"주소검색 : " + e.toString());
            }
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }
}
