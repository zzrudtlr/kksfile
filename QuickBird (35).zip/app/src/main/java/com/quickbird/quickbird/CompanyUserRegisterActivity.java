package com.quickbird.quickbird;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.regex.Pattern;

import Dialog.ConfirmDialog;
import Dialog.Loading;
import Filter.Filter;
import Register.ImageIcon;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-06.
 * 사업자 회원가입
 */
public class CompanyUserRegisterActivity extends Activity {
    private final String TAG = "CompanyUserRegister";

    public final int ICON_EMAIL = 0;//이메일 아이디
    public final int ICON_PW = 1;//비밀번호
    public final int ICON_CHECKPW = 2;//비밀번호 확인
    public final int ICON_CNAME = 3;//업체명
    public final int ICON_CEO = 4;//대표자
    public final int ICON_CIDENTITY = 5;//사업자등록번호
    public final int ICON_TYPE = 6;//업종
    public final int ICON_BUSINESS = 7;//업태
    public final int ICON_ADRESS = 8;//사업장 주소
    public final int ICON_PHONE = 9;//휴대폰
    public final int ICON_COMPANYNUMBER = 10;//사무실전화번호

    private Loading loading;//로딩
    private boolean emailid_overlap = false;//아이디 중복 체크

    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();//이미지 아이콘 관리

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_companyuser_register);
        init();
    }

    private void init(){

        loading = new Loading(this);

        imageIconinit();//이미지 아이콘 구조체 초기화
        buttonEvent();//버튼 이벤트
        editTextEvent();//EditText 포커스 이벤트
    }

    private void imageIconinit(){

        //이메일 아이디
        ImageIcon emaildIcon = new ImageIcon();
        emaildIcon.setEditText((EditText)findViewById(R.id.cEmailidText));
        emaildIcon.getEditText().setFilters(new InputFilter[]{Filter.filterAlphaNum});
        emaildIcon.setView((ImageView) findViewById(R.id.cEmailidImage));
        emaildIcon.setImageId(ICON_EMAIL);
        emaildIcon.setSetOnImage(R.drawable.icon_email_on);
        emaildIcon.setSetOffImage(R.drawable.icon_email_off);
        imageIcons.add(emaildIcon);

        //비밀번호
        ImageIcon pwIcon = new ImageIcon();
        pwIcon.setEditText((EditText) findViewById(R.id.cPwText));
        pwIcon.setView((ImageView) findViewById(R.id.cPwImage));
        pwIcon.setImageId(ICON_PW);
        pwIcon.setSetOnImage(R.drawable.icon_lock_on);
        pwIcon.setSetOffImage(R.drawable.icon_lock_off);
        imageIcons.add(pwIcon);

        //비밀번호 확인
        ImageIcon checkpwIcon = new ImageIcon();
        checkpwIcon.setEditText((EditText)findViewById(R.id.cCheckPwText));
        checkpwIcon.setView((ImageView) findViewById(R.id.cCheckPwImage));
        checkpwIcon.setImageId(ICON_CHECKPW);
        checkpwIcon.setSetOnImage(R.drawable.icon_lock_on);
        checkpwIcon.setSetOffImage(R.drawable.icon_lock_off);
        imageIcons.add(checkpwIcon);

        //업체명
        ImageIcon companyNameIcon = new ImageIcon();
        companyNameIcon.setEditText((EditText)findViewById(R.id.cCampanyNameText));
        companyNameIcon.setView((ImageView) findViewById(R.id.cCampanyNameImage));
        companyNameIcon.setImageId(ICON_CNAME);
        companyNameIcon.setSetOnImage(R.drawable.icon_doc_on);
        companyNameIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(companyNameIcon);

        //대표자
        ImageIcon ceoIcon = new ImageIcon();
        ceoIcon.setEditText((EditText)findViewById(R.id.cCeoText));
        ceoIcon.setView((ImageView) findViewById(R.id.cCeoImage));
        ceoIcon.setImageId(ICON_CEO);
        ceoIcon.setSetOnImage(R.drawable.icon_user_on);
        ceoIcon.setSetOffImage(R.drawable.icon_user_off);
        imageIcons.add(ceoIcon);

        //사업자등록번호
        ImageIcon companyIdentityIcon = new ImageIcon();
        companyIdentityIcon.setEditText((EditText)findViewById(R.id.cCompanyIdentityText));
        companyIdentityIcon.setView((ImageView) findViewById(R.id.cCompanyIdentityImage));
        companyIdentityIcon.setImageId(ICON_CIDENTITY);
        companyIdentityIcon.setSetOnImage(R.drawable.icon_doc_on);
        companyIdentityIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(companyIdentityIcon);

        //업종
        ImageIcon typeIcon = new ImageIcon();
        typeIcon.setEditText((EditText)findViewById(R.id.ctypeText));
        typeIcon.setView((ImageView) findViewById(R.id.ctypeImage));
        typeIcon.setImageId(ICON_TYPE);
        typeIcon.setSetOnImage(R.drawable.icon_doc_on);
        typeIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(typeIcon);

        //업태
        ImageIcon businessIcon = new ImageIcon();
        businessIcon.setEditText((EditText)findViewById(R.id.cBusinessText));
        businessIcon.setView((ImageView) findViewById(R.id.cBusinessImage));
        businessIcon.setImageId(ICON_BUSINESS);
        businessIcon.setSetOnImage(R.drawable.icon_doc_on);
        businessIcon.setSetOffImage(R.drawable.icon_doc_off);
        imageIcons.add(businessIcon);

        //사업장 주소
        ImageIcon addressIcon = new ImageIcon();
        addressIcon.setEditText((EditText)findViewById(R.id.cAddressText));
        addressIcon.setView((ImageView) findViewById(R.id.cAddressImage));
        addressIcon.setImageId(ICON_ADRESS);
        addressIcon.setSetOnImage(R.drawable.icon_map_on);
        addressIcon.setSetOffImage(R.drawable.icon_map_off);
        imageIcons.add(addressIcon);

        //휴대폰
        ImageIcon phoneIcon = new ImageIcon();
        phoneIcon.setEditText((EditText)findViewById(R.id.cPhoneText));
        phoneIcon.setView((ImageView) findViewById(R.id.cPhoneImage));
        phoneIcon.setImageId(ICON_PHONE);
        phoneIcon.setSetOnImage(R.drawable.icon_phone_on);
        phoneIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(phoneIcon);

        //인증번호
        ImageIcon phoneCertifyIcon = new ImageIcon();
        phoneCertifyIcon.setEditText((EditText)findViewById(R.id.cCompanyNumberText));
        phoneCertifyIcon.setView((ImageView) findViewById(R.id.cCompanyNumbeImage));
        phoneCertifyIcon.setImageId(ICON_COMPANYNUMBER);
        phoneCertifyIcon.setSetOnImage(R.drawable.icon_phone_on);
        phoneCertifyIcon.setSetOffImage(R.drawable.icon_phone_off);
        imageIcons.add(phoneCertifyIcon);
    }

    private void buttonEvent(){

        //아이디 중복확인
        Button overlabbtn = (Button)findViewById(R.id.cOverlapbtn);
        overlabbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                if(emailException(imageIcons.get(ICON_EMAIL).getEditText(),ICON_EMAIL)) {
                    JsonParse overlabJson = new JsonParse(getCompanyUserRegisterActivity()) {
                        @Override
                        public void startParse() {
                            loading.show();
                        }

                        @Override
                        public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                            if (flag.matches("1")) {//아이디 중복 안됨
                                emailid_overlap = true;
                                Toast.makeText(getCompanyUserRegisterActivity(), "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                emailid_overlap = false;
                                Toast.makeText(getCompanyUserRegisterActivity(), "아이디가 중복됩니다.", Toast.LENGTH_SHORT).show();
                            }
                            Log.d(TAG, "flag : " + flag);
                            Log.d(TAG, "message : " + message);
                            loading.dismiss();
                        }
                    };

                    overlabJson.getJsonParse(getOverLapUrlStr());
                }
            }
        });

        //취소버튼
        Button cancelbtn = (Button)findViewById(R.id.cCancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmDialog confirmDialog = new ConfirmDialog(getCompanyUserRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        getCompanyUserRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();
            }
        });

        Button register = (Button)findViewById(R.id.cRegisterbtn);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (exception()) {
                   Log.d(TAG,"성공");
                    JsonParse jsonParse = new JsonParse(getCompanyUserRegisterActivity()) {
                        @Override
                        public void startParse() {
                            loading.show();
                        }

                        @Override
                        public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                            Log.d(TAG, "flag : " + flag);
                            Log.d(TAG, "message : " + message);
                            loading.dismiss();
                            if(flag.matches("1")){
                                Toast.makeText(getCompanyUserRegisterActivity(),"회원가입 신청이 완료되었습니다.",Toast.LENGTH_SHORT).show();
                                finish();
                            }else{
                                Toast.makeText(getCompanyUserRegisterActivity(),"회원가입 신청에 실패하였습니다.",Toast.LENGTH_SHORT).show();
                            }
                        }
                    };
                    jsonParse.getJsonParse(getUrlStr());
                }
            }
        });
    }

    /* 회원가입 주소 값
    *
    * */
    private String getUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.COMPANY_REGISTER;
        urlStr = urlStr + "?email=" + imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        urlStr = urlStr + "&pw=" + imageIcons.get(ICON_PW).getEditText().getText().toString();
        try {
            urlStr = urlStr + "&company_name=" + URLEncoder.encode(imageIcons.get(ICON_CNAME).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&ceo_name=" + URLEncoder.encode(imageIcons.get(ICON_CEO).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&b_num=" + imageIcons.get(ICON_CIDENTITY).getEditText().getText().toString();
            urlStr = urlStr + "&sectors=" + URLEncoder.encode(imageIcons.get(ICON_TYPE).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&business=" + URLEncoder.encode(imageIcons.get(ICON_BUSINESS).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&phone=" + imageIcons.get(ICON_PHONE).getEditText().getText().toString();
            urlStr = urlStr + "&address=" + URLEncoder.encode(imageIcons.get(ICON_ADRESS).getEditText().getText().toString(), "UTF-8");
            urlStr = urlStr + "&call_num=" + imageIcons.get(ICON_COMPANYNUMBER).getEditText().getText().toString();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        urlStr = urlStr + "&fcm="+ FirebaseInstanceId.getInstance().getToken();
        urlStr = urlStr + "&profile_img=null";
        return urlStr;
    }

    /* 아이디 중복확인 주소 값
    *
    * */
    private String getOverLapUrlStr(){
        String urlStr = "";
        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.OVERLAP_CHECK;
        urlStr = urlStr + "?email=" + imageIcons.get(ICON_EMAIL).getEditText().getText().toString();
        return urlStr;
    }

    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
   *
   * */
    private void editTextEvent(){

        for(int i=0;i<imageIcons.size();i++) {
            imageIcons.get(i).getEditText().setId(imageIcons.get(i).getImageId());
            imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                    } else {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                    }
                }
            });
        }
    }



    /* EditText 예외처리
    *
    * */
    private boolean exception(){
        boolean check = true;
        for(int i=0;i<imageIcons.size();i++){
            if(imageIcons.get(i).getEditText().getText().toString().matches("")){//빈공간 예외처리
                check = false;
                imageIcons.get(i).getEditText().requestFocus();
                Toast.makeText(getCompanyUserRegisterActivity(), "가입양식을 입력해주세요.", Toast.LENGTH_SHORT).show();
                break;
            }else{
                if(!editTextException(imageIcons.get(i).getEditText(),imageIcons.get(i).getImageId())){//형식 에외처리
                    check = false;
                    break;
                }
            }
        }
        return check;
    }

    /* editText 형식 예외처리
    *
    * */
    private boolean emailException(EditText editText,int stateExcept){
        boolean check = true;
        switch (stateExcept){
            case ICON_EMAIL:
                if(editText.getText().toString().matches("")){
                    check = false;
                    Log.d(TAG,"아이디를 입력해 주세요.");
                    Toast.makeText(getCompanyUserRegisterActivity(),"아이디를 입력해 주세요.",Toast.LENGTH_SHORT).show();
                }else if(!Filter.checkEmailForm(editText.getText().toString())){
                    check = false;
                    Log.d(TAG,"이메일 형식에 맞지않습니다.");
                    Toast.makeText(getCompanyUserRegisterActivity(),"이메일 형식에 맞지않습니다.",Toast.LENGTH_SHORT).show();
                }
                break;

        }

        return check;
    }

    /* editText 형식 예외처리
    * editText : 예외처리할 EditText
    * stateExcepte : 예외처리 방법
    * */
    private boolean editTextException(EditText editText,int stateExcept){
        boolean check = true;
        switch (stateExcept){
            case ICON_EMAIL:
                if(!editText.getText().toString().contains("@")){
                    check = false;
                    Log.d(TAG,"이메일 형식에 맞지않습니다.");
                    Toast.makeText(getCompanyUserRegisterActivity(),"이메일 형식에 맞지않습니다.",Toast.LENGTH_SHORT).show();
                }else if(!emailid_overlap){
                    check = false;
                    Log.d(TAG,"이메일 중복 체크를 해주세요.");
                    Toast.makeText(getCompanyUserRegisterActivity(),"이메일 중복 체크를 해주세요.",Toast.LENGTH_SHORT).show();
                }
                break;
            case ICON_CHECKPW:
                if(!editText.getText().toString().matches(imageIcons.get(ICON_PW).getEditText().getText().toString())){
                    check = false;
                    Log.d(TAG,"비밀번호가 일치하지 않습니다.");
                    editText.requestFocus();
                    Toast.makeText(getCompanyUserRegisterActivity(),"비밀번호가 일치하지 않습니다.",Toast.LENGTH_SHORT).show();

                }
                break;
        }

        return check;
    }

    public CompanyUserRegisterActivity getCompanyUserRegisterActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
