package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

import Database.DB_SingleTon;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import Picture.DevicePicture;
import Picture.MultiplePicture.Action;
import Picture.PictureUpload;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-04-23.
 */
public class FreightCompleteInfoActivity extends Activity {

    private final String TAG ="FreightCompleteInfo";
    private final int PICK_FROM_CAMERA = 0;
    private final int PICK_FROM_ALBUM = 1;
    private final int CROP_FROM_iMAGE = 2;
    private final int SELECT_CAPTURE = 3;

    private DevicePicture devicePicture;

    private ImageView freightImageView;//화물 이미지
    private EditText memoEdit;//메모
    private TextView no_imgae_text;//이미지 없음 텍스트

    private String freight_idx;//화물 idx
    private String delivery_idx;//배송자 idx;

    private String freightimage_name="";//화물이미지 이름
    private Bitmap freight_img;//화물이미지
    private String image_path="";//이미지 경로


    private Loading loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freight_complete_info);
        freight_idx = getIntent().getStringExtra("freight_idx");
        delivery_idx = getIntent().getStringExtra("delivery_idx");


        init();
        eventButton();
    }

    private void init(){
        devicePicture = new DevicePicture(this);
        loading = new Loading(this);
        no_imgae_text = (TextView)findViewById(R.id.no_image_text);
        //화물 이미지뷰
        freightImageView = (ImageView)findViewById(R.id.fciImageView);
        freightImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // devicePicture.doTakeAlbumAction();
                selectPicture();
            }
        });
        memoEdit = (EditText)findViewById(R.id.fcimemoEdit);
    }

    private void eventButton(){
        //취소 버튼
        Button cancelBtn = (Button)findViewById(R.id.fcicancelbtn);
        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //확인 버튼
        Button selectBtn = (Button)findViewById(R.id.fciselectbtn);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deliveryPictureUpload(image_path);
            }
        });

        //종료 버튼
        Button exitbtn = (Button)findViewById(R.id.fciexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
    //사진 상태 선택하기
    private void selectPicture(){
        SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightCompleteInfoActivity()) {
            @Override
            public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                // doFilmingMovie();
                doImagePicture();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                devicePicture.doTakeAlbumAction();
                selectTwoDialog.dismiss();
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectTwoDialog.getSelectOneButton().setText("이미지 촬영");
        selectTwoDialog.getSelectTwoButton().setText("이미지 앨범");
        selectTwoDialog.show();
    }

    //이미지 촬영 후 가져오기
    private void doImagePicture(){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, SELECT_CAPTURE);

    }

    //사진업로드
    private void pictureUpload(){
        loading.show();//result 에서 로딩 종료
        String str[][] = {{"fileName",""},{"target_dir","image/"}};
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(freight_img, url, str) {
            @Override
            public void finishUpload(String pictureName) {
                Log.d(TAG, "pictureName : " + pictureName);

                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG,"message : " + jsonObject.getString("message"));
                    freightimage_name = jsonObject.getString("message");
                    //  sendImageName(profileimage_name);
                    //  sendRegister();

                    handler.sendEmptyMessage(0);
                } catch (JSONException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(1);
                    Log.d(TAG, "finishUpload catch : " +e.toString());
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                Log.d(TAG,"pictureuload errorCode : " + errorCode);
                loading.dismiss();
            }
        };//섬네일 이미지 사진업로드
        pu.uploadPicture();
    }

    /* 완료된 화물 사진 업로드
    *
    * */
    private void deliveryPictureUpload(String path){
        loading.show();
        String url = Conn_Address.SERVER_ADDRESS + Conn_Address.UPLOADPICTURE;
        PictureUpload pu = new PictureUpload(url, path) {
            @Override
            public void finishUpload(String pictureName) {
                try {
                    JSONObject jsonObject = new JSONObject(pictureName);
                    Log.d(TAG,"flag : " + jsonObject.getString("flag"));
                    Log.d(TAG, "message : " + jsonObject.getString("message"));
                    freightimage_name = jsonObject.getString("message");
                    handler.sendEmptyMessage(0);
                    //  loading.dismiss();
                } catch (JSONException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(1);
                }
            }

            @Override
            public void errorUpload(String errorCode) {
                loading.dismiss();
            }
        };//섬네일 이미지 사진업로드
        pu.uploadVideo();
    }
    /* 배송완료 정보 업로드
    *
    * */
    private void uploadCompleteFreightInfo(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG,"message : " + message);
                    Toast.makeText(getFreightCompleteInfoActivity(),"작성을 완료하였습니다.",Toast.LENGTH_SHORT).show();
                    finish();
                }else{
                    Toast.makeText(getFreightCompleteInfoActivity(),"작성을 실패하였습니다.",Toast.LENGTH_SHORT).show();
                }
                handler.sendEmptyMessage(1);
            }
        };
        jsonParse.getJsonParse(getUrlStr());
    }
    /* 배송완료정보 업데이트 url
    *
    * */
    private String getUrlStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_FINISH_INFO;
        webUrlStr = webUrlStr + "?delivery_idx=" + delivery_idx;
        webUrlStr = webUrlStr + "&freight_idx=" + freight_idx;
        webUrlStr = webUrlStr + "&img="+freightimage_name;
        try {
            webUrlStr = webUrlStr + "&memo="+URLEncoder.encode(memoEdit.getText().toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Log.d(TAG, "getDeliveryStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 지도 선택 다이얼로그 띄우기
   *
   * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                uploadCompleteFreightInfo();
            }else if(msg.what ==1){
                loading.dismiss();
            }
        }
    };

    public Bitmap getRealPathFromURI(Uri contentUri) {//실제 경로 반환
        String res = null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = this.getContentResolver().query(contentUri, proj, null, null, null);
        if(cursor.moveToFirst()){
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);//실제 uri 주소
        }
        cursor.close();
        return BitmapFactory.decodeFile(res);
    }


    // 실제 경로 찾기
    private String getPath(Uri uri)
    {
        String[] projection = { MediaStore.Images.Media.DATA };

        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
    private FreightCompleteInfoActivity getFreightCompleteInfoActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != RESULT_OK)
            return;
        Log.d(TAG, "onActivityResult : " + requestCode);

        switch (requestCode){
            case PICK_FROM_ALBUM:
            {
                try {
                    devicePicture.setmImageCaptureUri(data.getData());
                    image_path = getPath(data.getData());
                    freight_img = getRealPathFromURI(data.getData());
                    no_imgae_text.setVisibility(View.GONE);
                    freightImageView.setImageBitmap(freight_img);
                }catch(RuntimeException e){
                    Log.d(TAG,"이미지 경로에러");
                }catch(Exception e){

                }
                // handler.sendEmptyMessage(0);
                //  profile_img = getRealPathFromURI(data.getData());
                //   profileImageView.setImageBitmap(profile_img);
                //   imageSelect = true;
                Log.d(TAG, "PICK_FROM_ALBUM");
            }
            case SELECT_CAPTURE:
            {
                devicePicture.setmImageCaptureUri(data.getData());
                image_path = getPath(data.getData());
                freight_img = getRealPathFromURI(data.getData());
                no_imgae_text.setVisibility(View.GONE);
                freightImageView.setImageBitmap(freight_img);
                Log.d(TAG, "SELECT_CAPTURE");
            }

            case PICK_FROM_CAMERA:
            {
                devicePicture.pickFromCamera();
                Log.d(TAG, "PICK_FROM_CAMERA");
            }

            case CROP_FROM_iMAGE:
            {
                Log.d(TAG, "CROP_FROM_iMAGE");
                if(resultCode != RESULT_OK){
                    return;
                }
                //  devicePicture.cropFromImage(data,profileImageView);
            }

        }
    }
}
