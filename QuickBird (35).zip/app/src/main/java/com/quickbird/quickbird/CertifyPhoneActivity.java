package com.quickbird.quickbird;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by KyoungSik on 2017-04-19.
 */
public class CertifyPhoneActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_certifyphone);

    }
}
