package com.quickbird.quickbird;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

import Dialog.Loading;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-20.
 * 화물 관제
 */
public class FreightManagementActivity extends Activity {

    private final String TAG = "FreightManagement";

    private WebViewClass webViewClass;
    private Loading loading;

    private String freight_idx="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freight_menagement);
        freight_idx = getIntent().getStringExtra("freight_idx");
        loading = new Loading(getFreightManagementActivity());
        loading.show();
        init();


    }

    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.MYFREIGHT_LOCATION;
        urlStr = urlStr + "?freight_idx="+freight_idx;
        Log.d(TAG,"getUrlStr : " + urlStr);
        return urlStr;
    }

    private void init(){

        webViewClass = new WebViewClass((WebView)findViewById(R.id.fmwebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {

            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        Button exitbtn = (Button)findViewById(R.id.fmexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

    private FreightManagementActivity getFreightManagementActivity(){
        return this;
    }
}
