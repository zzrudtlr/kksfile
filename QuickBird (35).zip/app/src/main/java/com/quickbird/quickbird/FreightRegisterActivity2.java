package com.quickbird.quickbird;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ActionMenuView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.VideoView;
import android.widget.ViewSwitcher;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;

import java.util.ArrayList;

import Dialog.ConfirmDialog;
import Dialog.SelectTwoDialog;
import Picture.MultiplePicture.Action;
import Picture.MultiplePicture.CustomGallery;
import Picture.MultiplePicture.CustomGalleryAdapter;
import Register.ImageIcon;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-08.
 * 화물 등록하기
 */
public class FreightRegisterActivity2 extends Activity {

    private final int APP_PERMISSION_STORAGE = 0;
    private final int SELECT_MOVIE = 2;
    private final String TAG = "FreightRegister";

    private final int galleryItemWidth = 300;
    private int gridWidth = 0;

    private ArrayList<ImageIcon> imageIcons = new ArrayList<ImageIcon>();//이미지 아이콘 관리

    GridView gridGallery;
    Handler handler;
    CustomGalleryAdapter adapter;
    ArrayList<String> imagePaths;
    ImageView imgSinglePick;

    ViewSwitcher viewSwitcher;
    VideoView videoView;
    ImageLoader imageLoader;

    LinearLayout pvLienar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freight_register2);
        initImageLoader();
        init();

    }
    private void initImageLoader() {
        // for universal image loader
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisc().imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
                .bitmapConfig(Bitmap.Config.RGB_565).build();
        ImageLoaderConfiguration.Builder builder = new ImageLoaderConfiguration.Builder(
                this).defaultDisplayImageOptions(defaultOptions).memoryCache(
                new WeakMemoryCache());

        ImageLoaderConfiguration config = builder.build();
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(config);
    }
    private void init(){

        gridGallery = (GridView) findViewById(R.id.gridGallery);
        gridWidth = gridGallery.getWidth();
        gridGallery.setFastScrollEnabled(true);
        adapter = new CustomGalleryAdapter(getApplicationContext(), imageLoader);
        adapter.setMultiplePick(false);

        gridGallery.setAdapter(adapter);

        gridGallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(FreightRegisterActivity2.this, "" + imagePaths.get(i), Toast.LENGTH_LONG).show();
            }
        });

        viewSwitcher = (ViewSwitcher) findViewById(R.id.viewSwitcher);
        videoView = (VideoView)findViewById(R.id.frvideoView);
        pvLienar = (LinearLayout)findViewById(R.id.pvlienar);
        viewSwitcher.setDisplayedChild(0);
        imageIconinit();
        buttonEvent();
        editTextEvent();
    }

    /**
     * 퍼미션 체크
     */
    private void checkPermission(){

        //권한이 없는 경우
        if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                ||checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){

            //최초 거부를 선택하면 두번째부터 이벤트 발생 & 권한 획득이 필요한 이융를 설명
            if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                Toast.makeText(this, "shouldShowRequestPermissionRationale", Toast.LENGTH_SHORT).show();
            }

            //요청 팝업 팝업 선택시 onRequestPermissionsResult 이동
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, APP_PERMISSION_STORAGE);

        }
        //권한이 있는 경우
        else{
            Log.d(TAG,"checkPermission true");
            Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
            startActivityForResult(i, 200);
        }
    }


    private void imageIconinit(){
        //품목 아이콘
        ImageIcon itemIcon = new ImageIcon();
        itemIcon.setEditText((EditText) findViewById(R.id.frItemText));
        itemIcon.setView((ImageView) findViewById(R.id.fritemImage));
        itemIcon.setSetOnImage(R.drawable.icon_tag_on);
        itemIcon.setSetOffImage(R.drawable.icon_tag_off);
        imageIcons.add(itemIcon);

        //크기 아이콘
        ImageIcon sizeIcon = new ImageIcon();
        sizeIcon.setEditText((EditText) findViewById(R.id.frSizeText));
        sizeIcon.setView((ImageView) findViewById(R.id.frsizeImage));
        sizeIcon.setSetOnImage(R.drawable.icon_width_on);
        sizeIcon.setSetOffImage(R.drawable.icon_width_off);
        imageIcons.add(sizeIcon);

        //무게 아이콘
        ImageIcon weightIcon = new ImageIcon();
        weightIcon.setEditText((EditText) findViewById(R.id.frweightText));
        weightIcon.setView((ImageView) findViewById(R.id.frweightImage));
        weightIcon.setSetOnImage(R.drawable.icon_weight_on);
        weightIcon.setSetOffImage(R.drawable.icon_weight_off);
        imageIcons.add(weightIcon);

        //받는분 아이콘
        ImageIcon reciveIcon = new ImageIcon();
        reciveIcon.setEditText((EditText) findViewById(R.id.frreciveText));
        reciveIcon.setView((ImageView) findViewById(R.id.frreciveImage));
        reciveIcon.setSetOnImage(R.drawable.icon_user_on);
        reciveIcon.setSetOffImage(R.drawable.icon_user_off);
        imageIcons.add(reciveIcon);

        //출발지 아이콘
        ImageIcon dpIcon = new ImageIcon();
        dpIcon.setEditText((EditText) findViewById(R.id.frDeparturePointText));
        dpIcon.setView((ImageView) findViewById(R.id.frDeparturePointImage));
        dpIcon.setSetOnImage(R.drawable.icon_map_on);
        dpIcon.setSetOffImage(R.drawable.icon_map_off);
        imageIcons.add(dpIcon);

        //도착지 아이콘
        ImageIcon apIcon = new ImageIcon();
        apIcon.setEditText((EditText) findViewById(R.id.frArrivePointText));
        apIcon.setView((ImageView) findViewById(R.id.frArrivePointImage));
        apIcon.setSetOnImage(R.drawable.icon_map_on);
        apIcon.setSetOffImage(R.drawable.icon_map_off);
        imageIcons.add(apIcon);

        //예상거리 아이콘
        ImageIcon distanceIcon = new ImageIcon();
        distanceIcon.setEditText((EditText) findViewById(R.id.frDistanceText));
        distanceIcon.setView((ImageView) findViewById(R.id.frDistanceImage));
        distanceIcon.setSetOnImage(R.drawable.icon_map_on);
        distanceIcon.setSetOffImage(R.drawable.icon_map_off);
        imageIcons.add(distanceIcon);

        //추천가격 아이콘
        ImageIcon recommendIcon = new ImageIcon();
        recommendIcon.setEditText((EditText) findViewById(R.id.frRecommendText));
        recommendIcon.setView((ImageView) findViewById(R.id.frRecommendImage));
        recommendIcon.setSetOnImage(R.drawable.icon_card_on);
        recommendIcon.setSetOffImage(R.drawable.icon_card_off);
        imageIcons.add(recommendIcon);

        //메모 아이콘
        ImageIcon memoIcon = new ImageIcon();
        memoIcon.setEditText((EditText) findViewById(R.id.frMemoText));
        memoIcon.setView((ImageView) findViewById(R.id.frMemoImage));
        memoIcon.setSetOnImage(R.drawable.icon_pencil_on);
        memoIcon.setSetOffImage(R.drawable.icon_pencil_off);
        imageIcons.add(memoIcon);
    }

    /* 버튼 이벤트
    *
    * */
    private void buttonEvent(){
        Button cancelbtn = (Button)findViewById(R.id.drcancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*ConfirmDialog confirmDialog = new ConfirmDialog(getFreightRegisterActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        getFreightRegisterActivity().finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 취소를 하시겠습니까?");
                confirmDialog.show();*/
                checkPermission();

            }
        });
        Button exitbtn = (Button)findViewById(R.id.drexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

       /* Button picturemovebtn = (Button)findViewById(R.id.frPicturemovebtn);
        picturemovebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {

                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {

                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("이미지");
                selectTwoDialog.getSelectTwoButton().setText("동영상");
                selectTwoDialog.show();
            }
        });*/

        Button frbtn = (Button)findViewById(R.id.frpvbtn);
        frbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFreightRegisterActivity()) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                        viewSwitcher.setDisplayedChild(0);
                        checkPermission();
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        doSelectMovie();
                        viewSwitcher.setDisplayedChild(1);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("이미지");
                selectTwoDialog.getSelectTwoButton().setText("동영상");
                selectTwoDialog.show();
            }
        });
    }

    //동영상선택
    private void doSelectMovie(){
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try{
            startActivityForResult(i, SELECT_MOVIE);
        }catch (android.content.ActivityNotFoundException e)
        {
            e.printStackTrace();
        }
    }


    /* EditText 포커스 바꼈을시 아이콘 이미지 상태 바꿈
    *
    * */
    private void editTextEvent(){

        for(int i=0;i<imageIcons.size();i++) {
            imageIcons.get(i).getEditText().setId(i);
            imageIcons.get(i).getEditText().setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOnImage());
                    } else {
                        imageIcons.get(v.getId()).getView().setBackgroundResource(imageIcons.get(v.getId()).getSetOffImage());
                    }
                }
            });
        }
    }


    public FreightRegisterActivity2 getFreightRegisterActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        imagePaths = new ArrayList<String>();
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            adapter.clear();

            viewSwitcher.setDisplayedChild(1);
            String single_path = data.getStringExtra("single_path");
            imagePaths.add(single_path);
            imageLoader.displayImage("file://" + single_path, imgSinglePick);

        } else if (requestCode == 200 && resultCode == Activity.RESULT_OK) {

            String[] all_path = data.getStringArrayExtra("all_path");
            Log.d(TAG, "multiplePicker all_path : " + all_path.length);
            float scale = this.getBaseContext().getResources().getDisplayMetrics().density;
            int dp = (int)(300/scale)*all_path.length;
            LinearLayout.LayoutParams gridParams = new LinearLayout.LayoutParams(galleryItemWidth*all_path.length, LinearLayout.LayoutParams.WRAP_CONTENT);
            LinearLayout.LayoutParams linearParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
         /*   if(all_path.length > 3) {
                linearParams.gravity = Gravity.START;
                pvLienar.setLayoutParams(linearParams);
            }else{
                linearParams.gravity = Gravity.CENTER;
                pvLienar.setLayoutParams(linearParams);
            }*/
            gridGallery.setNumColumns(all_path.length);
            gridGallery.setBackgroundColor(Color.BLACK);
            gridGallery.setLayoutParams(gridParams);

            ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();

            for (String string : all_path) {
                CustomGallery item = new CustomGallery();
                item.sdcardPath = string;
                imagePaths.add(string);
                dataT.add(item);
            }

            viewSwitcher.setDisplayedChild(0);
            adapter.addAll(dataT);
        } else if(requestCode == APP_PERMISSION_STORAGE){
            Log.d(TAG,"APP_PERMISSION_STORAGE");
            Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
            startActivityForResult(i, 200);
        }else if(requestCode == SELECT_MOVIE){
            Uri uri = data.getData();
            String path2 = Environment.getExternalStorageDirectory()
                    + "/TestVidio6.mp4";
            viewSwitcher.setDisplayedChild(1);
            videoView.setVideoURI(uri);
            videoView.start();

        }
    }
}
