package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import Dialog.Loading;
import Dialog.SelectTwoDialog;
import Permission.DevicePermission;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 화물 배송을 요청한 배송자 리스트
 */
public class FrequestDeliveryActivity extends Activity {

    private final String TAG = "FrequestDelivery";

    private WebViewClass webViewClass;
    private Loading loading;

    private String freight_idx="";
    private String delivery_idx ="";
    private int delivery_flag = 0;//배송가능 유무 1:배송가능 0 : 배송불가
    private int request_state = 0;//신청 상태 1 : 배송자->화물 신청 2 : 화물 -> 배송자 신청

    private DevicePermission devicePermission;//기기 접근 허가

    private String phoneNumber = "";

    private String startState="not_push";//푸쉬로인해 켜진건지
    private boolean topActivityCheck = false; //false : topActivity아님

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frequest_delivery);

        try{
            startState = getIntent().getStringExtra("startState");
            if(startState == null){
                startState = "not_push";
            }
        }catch (Exception e){
            startState = "not_push";
            Log.d(TAG,e.toString());
        }
        String topCheck = getIntent().getStringExtra("topActivity");
        try {
            Log.d(TAG,"topCheck : " + topCheck);
            Log.d(TAG,"getSimpleName : " + this.getClass().getSimpleName());
            if (!topCheck.matches(this.getClass().getPackage().getName())) {
                Log.d(TAG,"topCheck2 : " + topCheck);
                topActivityCheck = true;
            }
        }catch (NullPointerException e){
            topActivityCheck = false;
        }

        loading = new Loading(getFrequestDeliveryActivity());
       freight_idx = getIntent().getStringExtra("freight_idx");
        init();
    }


    private void init(){
        devicePermission = new DevicePermission();
        webViewClass = new WebViewClass((WebView)findViewById(R.id.frdwebview),this,getWebUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                loading.show();
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void hope_delivery_more(int state, int deliveryidx,String phone_Number,int flag, int r_state) {
                request_state = r_state;
                delivery_flag = flag;
                showStateDialog(state);
                Log.d(TAG, "my_delivery_more : " + state + " delivery_idx : " + deliveryidx  + " phoneNumber : " + phone_Number);
                delivery_idx = "" + deliveryidx;
                phoneNumber = phone_Number;
            }

            @JavascriptInterface
            public void h_list(int state, int view_idx) {
                Log.d(TAG, "h_list");
                Intent intent = new Intent(FrequestDeliveryActivity.this, DeliveryInfoDetailActivity.class);
                intent.putExtra("delivery_idx", "" + view_idx);
                startActivity(intent);
            }

            @JavascriptInterface
            public void accept(String result, String message){
                Log.d(TAG, "result : " + result);
                handler.sendEmptyMessage(1);//로딩 종료
                if(result.contains("1")){
                    Toast.makeText(getFrequestDeliveryActivity(),"배송자 지정을 완료하였습니다.",Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }else if(result.contains("0")){
                    Toast.makeText(getFrequestDeliveryActivity(), message, Toast.LENGTH_SHORT).show();
                }else if(result.contains("2")) {
                    Toast.makeText(getFrequestDeliveryActivity(), message, Toast.LENGTH_SHORT).show();
                    handler.sendEmptyMessage(3);
                }

               // handler.sendEmptyMessage(3);//웹 reload
             }
        }, "quickbird");

        Button exitbtn = (Button)findViewById(R.id.frdexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /* 화물 배송을 요청한 배송자 리스트 url
    *
    * */
    private String getWebUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_DELIVERY;
        urlStr = urlStr + "?user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&freight_idx=" +freight_idx;
        Log.d(TAG, "urlStr :" + urlStr);
        return urlStr;
    }


    /* 배송 상태에 따라 띄우는 다이얼로그 함수
*
* */
    private void showStateDialog(int state){
        switch (state){
            case 0://미확정
                if(request_state == 1) {
                    SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getFrequestDeliveryActivity()) {
                        @Override
                        public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                            devicePermission.checkPermissionCall(FrequestDeliveryActivity.this, phoneNumber);
                        }

                        @Override
                        public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                            if (delivery_flag == 1) {//배송가능 상태
                                selectTwoDialog.dismiss();
                                handler.sendEmptyMessage(0);//로딩시작 accept에서 로딩 종료
                                handler.sendEmptyMessage(2);
                            } else {
                                Toast.makeText(FrequestDeliveryActivity.this, "배송 가능 횟수를 초과하였습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void clickCancelButton() {

                        }
                    };
                    selectTwoDialog.getSelectOneButton().setText("전화걸기");
                    selectTwoDialog.getSelectTwoButton().setText("배송자지정");
                    selectTwoDialog.show();
                }else{
                    Toast.makeText(getFrequestDeliveryActivity(),"권한이 없습니다.",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    /* 배송자 지정하기
    *
    * */
    private void acceptDelivery(String delivery_idx, String freight_idx) {
        webViewClass.getWebView().loadUrl("javascript:accept_delivery(" + delivery_idx + "," + freight_idx +");");
    }

    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.show();
            }else if(msg.what==1){
                loading.dismiss();
            }else if(msg.what==2){
                acceptDelivery(delivery_idx, freight_idx);//배송자 지정하기
            }else if(msg.what == 3){
                webViewClass.getWebView().reload();
            }
        }
    };

    /*
         * 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
         * */
    @Override
    public void onBackPressed() {
        //;
        Log.d("onBack", "backpress");
        if(startState.matches("not_push")){//푸시로 화면이 실행안된경우
            super.onBackPressed();
        }else{//푸시로 실행된경우
            if(topActivityCheck) {
                BackPressClose backPressClose = new BackPressClose(this);
                backPressClose.BackActivity(this, IntroActivity.class);
            }else{
                super.onBackPressed();
            }
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

    private FrequestDeliveryActivity getFrequestDeliveryActivity(){
        return this;
    }
}
