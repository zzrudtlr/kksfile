package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import Dialog.Loading;
import Dialog.SelectThreeDialog;
import Dialog.SelectTwoDialog;
import Permission.DevicePermission;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 배송을 요청한 화물
 */
public class DrequestFreightActivity extends Activity {

    private final String TAG = "DrequestFreightActivity";

    private WebViewClass webViewClass;
    private Loading loading;

    private String delivery_idx = "";
    private String freight_idx = "";
    private int delivery_flag = 0;//배송가능 유무 1:배송가능 0 : 배송불가
    private int request_state = 0;//신청 상태 1 : 배송자->화물 신청 2 : 화물 -> 배송자 신청

    private DevicePermission devicePermission;//기기 접근 허가

    private String phoneNumber = "";
    private boolean changeinfo = false;//정보 수정 체크
    private int point = 0;//배송완료시 받는 포인트

    private String startState="not_push";//푸쉬로인해 켜진건지
    private boolean topActivityCheck = false; //false : topActivity아님
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drequest_freight);

        try{
            startState = getIntent().getStringExtra("startState");
            if(startState == null){
                startState = "not_push";
            }
        }catch (Exception e){
            startState = "not_push";
            Log.d(TAG,e.toString());
        }
        String topCheck = getIntent().getStringExtra("topActivity");
        try {
            Log.d(TAG,"topCheck : " + topCheck);
            Log.d(TAG,"getSimpleName : " + this.getClass().getSimpleName());
            if (!topCheck.matches(this.getClass().getPackage().getName())) {
                Log.d(TAG,"topCheck2 : " + topCheck);
                topActivityCheck = true;
            }
        }catch (NullPointerException e){
            topActivityCheck = false;
        }

        loading = new Loading(getDrequestFreightActivity());
        delivery_idx = getIntent().getStringExtra("delivery_idx");
        Log.d(TAG, "delivery_idx : " + delivery_idx);
        init();


    }

    private void init(){
        devicePermission = new DevicePermission();
        webViewClass = new WebViewClass((WebView)findViewById(R.id.drfwebview),this,getWebUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                loading.show();
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void hope_freight_more(int state, int freightidx, String phone, int flag, int r_state) {
                Log.d(TAG, " state : " + state + " freight_idx : " + freightidx + " phone : " + phone);
              //  if(flag == 1) {
                if(DB_SingleTon.getInstance(getDrequestFreightActivity()).getUserInfoTable().getDelivery_idx().matches(delivery_idx)) {
                    request_state = r_state;
                    delivery_flag = flag;
                    showStateDialog(state);
                    Log.d(TAG, " state : " + state + " freight_idx : " + freightidx + " phone : " + phone);

                    freight_idx = "" + freightidx;
                    phoneNumber = phone;
                }else{
                    Toast.makeText(DrequestFreightActivity.this,"내 배송자가 아닙니다.",Toast.LENGTH_SHORT).show();
                }
              //  }else{
                  //  Toast.makeText(DrequestFreightActivity.this,"배송가능 횟수를 초과 했습니다.",Toast.LENGTH_SHORT).show();
              //  }
            }

            @JavascriptInterface
            public void h_list(int state, int freight_idx) {
                Log.d(TAG, "freight_idx : " + freight_idx);
                Intent intent = new Intent(DrequestFreightActivity.this, FreightInfoDetailActivity.class);
                intent.putExtra("freight_idx", "" + freight_idx);
                startActivity(intent);
            }

            @JavascriptInterface
            public void accept(String result, String message) {
                Log.d(TAG, "result : " + result + " message : " + message);
                handler.sendEmptyMessage(1);//로딩 종료
                if (result.contains("1")) {
                    Toast.makeText(getDrequestFreightActivity(), "화물 지정을 완료하였습니다.", Toast.LENGTH_SHORT).show();
                    changeinfo = true;//정보 변경
                    handler.sendEmptyMessage(5);
                    //setResult(RESULT_OK);
                   // finish();
                }else if(result.contains("0")){
                    Toast.makeText(getDrequestFreightActivity(), message, Toast.LENGTH_SHORT).show();
                }else if(result.contains("2")) {
                    Toast.makeText(getDrequestFreightActivity(), message, Toast.LENGTH_SHORT).show();
                    handler.sendEmptyMessage(5);
                }

                // handler.sendEmptyMessage(3);//웹 reload
            }
        }, "quickbird");

        Button exitbtn = (Button)findViewById(R.id.drfexitbtn);
        exitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /* 배송자에게 배송요청을 한 화물 Url
*
* */
    private String getWebUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_FREIGHT;
        urlStr = urlStr + "?user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&delivery_idx=" +delivery_idx;
        Log.d(TAG, "urlStr :" + urlStr);
        return urlStr;
    }



    /* 배송 상태에 따라 띄우는 다이얼로그 함수
*
* */
    private void showStateDialog(int state){
        switch (state){
            case 0://배송대기
                if(request_state == 2) {
                    SelectTwoDialog selectTwoDialog = new SelectTwoDialog(getDrequestFreightActivity()) {
                        @Override
                        public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                            devicePermission.checkPermissionCall(DrequestFreightActivity.this, phoneNumber);
                        }

                        @Override
                        public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                            if (delivery_flag == 1) {//배송가능 상태
                                selectTwoDialog.dismiss();
                                handler.sendEmptyMessage(0);//로딩시작 accept에서 로딩 종료
                                handler.sendEmptyMessage(2);
                            } else {
                                Toast.makeText(DrequestFreightActivity.this, "배송 가능 횟수를 초과하였습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void clickCancelButton() {

                        }
                    };
                    selectTwoDialog.getSelectOneButton().setText("전화걸기");
                    selectTwoDialog.getSelectTwoButton().setText("화물지정");
                    selectTwoDialog.show();
                }else{
                    Toast.makeText(getDrequestFreightActivity(),"권한이 없습니다.",Toast.LENGTH_SHORT).show();
                }
                break;
            case 1://배송확정
                SelectThreeDialog selectThreeDialog = new SelectThreeDialog(this) {
                    @Override
                    public void clickOneButton(SelectThreeDialog selectThreeDialog) {
                        Intent intent = new Intent(getDrequestFreightActivity(), FreightInfoDetailActivity.class);
                        intent.putExtra("freight_idx", "" + freight_idx);
                        intent.putExtra("home_flag","1");
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectThreeDialog selectThreeDialog) {

                        Intent intent = new Intent(getDrequestFreightActivity(),FreightCompleteInfoActivity.class);
                        intent.putExtra("freight_idx",freight_idx);
                        intent.putExtra("delivery_idx",delivery_idx);
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickThreeButton(SelectThreeDialog selectThreeDialog) {
                        selectThreeDialog.dismiss();
                        handler.sendEmptyMessage(4);
                        // finish();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectThreeDialog.getSelectOneButton().setText("배송중인 화물정보");
                selectThreeDialog.getSelectTwoButton().setText("배송완료정보작성");
                selectThreeDialog.getSelectThreeButton().setText("배송완료");
                selectThreeDialog.show();
                break;
        }
    }

    /* 화물 지정하기
    *
    * */
    private void acceptFreight(String freight_idx, String delivery_idx) {
        Log.d(TAG,"freight_idx : " + freight_idx + " delivery_idx : " + delivery_idx);
        webViewClass.getWebView().loadUrl("javascript:accept_freight(" + freight_idx + "," + delivery_idx + ");");
    }

    /* 배송완료정보 업데이트 url
   *
   * */
    private String getFinishFreightUrlStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_FINISH;
        webUrlStr = webUrlStr + "?freight_idx=" +freight_idx;
        webUrlStr = webUrlStr + "&delivery_idx=" + delivery_idx;
        Log.d(TAG, "getFinishFreightUrlStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 배송완료하기
       *
       * */
    private void updateFinishFreight(){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    Log.d(TAG, "result : " + result.toString());

                    Toast.makeText(getDrequestFreightActivity(),"배송이 완료되었습니다.",Toast.LENGTH_SHORT).show();
                    changeinfo = true;
                    Log.d(TAG, "point : " +result.get(0).get(0));
                    try {
                        point = Integer.parseInt(result.get(0).get(0));//배송완료 화물시 얻은 포인트
                    }catch (Exception e){
                        Log.d(TAG,"Exception : " + e.toString());
                    }
                    webViewClass.getWebView().reload();
                    //point
                }else{
                    Toast.makeText(getDrequestFreightActivity(),"실패하였습니다.",Toast.LENGTH_SHORT).show();
                }
                loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getFinishFreightUrlStr());
    }

    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.show();
            }else if(msg.what==1){
                loading.dismiss();
            }else if(msg.what==2){
                acceptFreight(freight_idx,delivery_idx);//배송자 지정하기
            }else if(msg.what == 3){
                webViewClass.getWebView().reload();
            }else if(msg.what == 4){
                updateFinishFreight();
            }else if(msg.what == 5){
                webViewClass.getWebView().reload();
            }
        }
    };
    /*
* 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
* */
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Log.d("onBack", "backpress");

        if(startState.matches("not_push")){//푸시로 화면이 실행안된경우
            super.onBackPressed();
        }else{//푸시로 실행된경우
            if(topActivityCheck) {
                BackPressClose backPressClose = new BackPressClose(this);
                backPressClose.BackActivity(this, IntroActivity.class);
            }
        }

        if(changeinfo) {
            Intent intent = new Intent();
            intent.putExtra("point", "" + point);
            Log.d(TAG, "point : " + point);
            setResult(RESULT_OK, intent);
        }else {
            setResult(RESULT_CANCELED);
        }
        finish();
    }



    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());

    }

    private DrequestFreightActivity getDrequestFreightActivity(){
        return this;
    }

}
