package com.quickbird.quickbird;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import BackPress.BackPressClose;
import Database.DB_SingleTon;
import DeliveryDetail.FreightInfo;
import Dialog.Loading;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Permission.DevicePermission;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-18.
 * 배송자 상세정보
 */
public class DeliveryInfoDetailActivity extends Activity {

    private final String TAG = "DeliveryInfoDetail";

    private WebViewClass webViewClass;
    private Loading loading;

    private String delivery_idx="";
    private String freight_idx="";//희망 화물로 등록할 화물 idx
    private ArrayList<FreightInfo> freightInfos;

    private String startState="not_push";//푸쉬로인해 켜진건지
    private boolean topActivityCheck = false; //false : topActivity아님
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deliveryinfo_detail);
        try{
            startState = getIntent().getStringExtra("startState");
            if(startState == null){
                startState = "not_push";
            }
        }catch (Exception e){
            startState = "not_push";
            Log.d(TAG,e.toString());
        }
        String topCheck = getIntent().getStringExtra("topActivity");
        try {
            Log.d(TAG,"topCheck : " + topCheck);
            Log.d(TAG,"getSimpleName : " + this.getClass().getSimpleName());
            if (!topCheck.matches(this.getClass().getPackage().getName())) {
                Log.d(TAG,"topCheck2 : " + topCheck);
                topActivityCheck = true;
            }
        }catch (NullPointerException e){
            topActivityCheck = false;
        }


        loading = new Loading(this);
        loading.show();
        delivery_idx = getIntent().getStringExtra("delivery_idx");
        init();
        eventButton();
    }

    private void init(){
        freightInfos = new ArrayList<>();
        webViewClass = new WebViewClass((WebView)findViewById(R.id.ddwebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {

            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void more_m() {
                Log.d(TAG, "more_m");
            }

            @JavascriptInterface
            public void qhlist() {
                Log.d(TAG, "h_list");
            }

            @JavascriptInterface
            public void phone(String number) {
                Log.d(TAG, "number : " + number);
                DevicePermission devicePermission = new DevicePermission();
                devicePermission.checkPermissionCall(DeliveryInfoDetailActivity.this, number);
            }
        }, "quickbird");
    }

    private void eventButton(){
        //희망 화물 등록하기
        Button registerbtn = (Button)findViewById(R.id.didregisterbtn);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestFreightList();
            }
        });
    }

    /* 배송자 상세정보 url
*
* */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERYDETAILINFO;
        urlStr = urlStr + "?delivery_idx="+ delivery_idx;
        Log.d(TAG, "getUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송안한 화물리스트 url
    *
    * */
    private String getRequestFreightList(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.MYFREIGHT_LIST;
        urlStr = urlStr+"?user_idx="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr +"&user_type=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        return urlStr;
    }

    private String getRequestFreightDeliveryUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_MYFREIGHT_DELIVERY;
        urlStr = urlStr + "?delivery_idx=" + delivery_idx;
        urlStr = urlStr + "&freight_idx=" + freight_idx;
        Log.d(TAG, "getRequestFreightDeliveryUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송안한 화물리스트 가져오기
   *
   * */
    private void RequestFreightList(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    if(result.size()>0) {
                        setFreightInfos(result);
                    }
                }else{
                    Log.d(TAG,"대기중인 화물 없음");
                    Toast.makeText(getDeliveryInfoDetailActivity(),"배송대기중인 화물이 없습니다.",Toast.LENGTH_SHORT).show();
                }
                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestFreightList());
    }

    /* 화물리스트 정보 분류하기
    *
    * */
    private void setFreightInfos(ArrayList<ArrayList<String>> result){
        freightInfos.clear();
        String freightName[] = new String[result.get(0).size()];
        for(int i=0;i<result.get(0).size();i++){
            Log.d(TAG, "freight_idx : " + result.get(0).get(i));
            Log.d(TAG, "freight_name : " + result.get(1).get(i));
            FreightInfo freightInfo = new FreightInfo();
            freightInfo.setFreight_idx(result.get(0).get(i));
            freightInfo.setFreight_name(result.get(1).get(i));
            freightName[i] = freightInfo.getFreight_name();
            freightInfos.add(freightInfo);
        }
        showFreightList(freightName);
    }

    /** 화물리스트 다이얼로그 보여주기
     *
     */
    private void showFreightList(String freightName[]){
        SelectListDialog selectListDialog = new SelectListDialog(this, freightName);
        selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
            @Override
            public void onClickCancel() {

            }

            @Override
            public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                freight_idx = freightInfos.get(position).getFreight_idx();

                selectListDialog.dismiss();
                Log.d(TAG, "position : " + titlelist[position] + " freight_idx : " + freight_idx);
                updateFreightDelivery();
            }

            @Override
            public void onClickList(int position, View view, String[] titlelist) {
                //  view.setBackgroundColor(Color.BLUE);


            }
        });
        selectListDialog.getTitleImage().setImageResource(R.drawable.icon_car_white);
        selectListDialog.getTitleText().setText("화물선택");
        selectListDialog.show();
    }

    /* 배송자에게 내화물 배송 신청하기
   *
   * */
    private void updateFreightDelivery(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag + " message : " + message);
                if(flag.matches("1")){
                    Toast.makeText(getDeliveryInfoDetailActivity(),"배송자에게 배송을 신청하였습니다.",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getDeliveryInfoDetailActivity(),message,Toast.LENGTH_SHORT).show();
                }

                handler.sendEmptyMessage(0);
            }
        };
        jsonParse.getJsonParse(getRequestFreightDeliveryUrlStr());
    }

    /*
         * 휴대폰 뒤로가기를 눌렀을 때 처리하는 함수
         * */
    @Override
    public void onBackPressed() {
        //;
        Log.d("onBack", "backpress");
        if(startState.matches("not_push")){//푸시로 화면이 실행안된경우
            super.onBackPressed();
        }else{//푸시로 실행된경우
            if(topActivityCheck) {
                BackPressClose backPressClose = new BackPressClose(this);
                backPressClose.BackActivity(this, IntroActivity.class);
            }else{
                super.onBackPressed();
            }
        }
    }
    /*
    *
    * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.dismiss();
            }
        }
    };

    private DeliveryInfoDetailActivity getDeliveryInfoDetailActivity(){
        return this;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

    public ComponentName getCurrentActivity() {

        ActivityManager am = (ActivityManager) this.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

        ComponentName topActivity = taskInfo.get(0).topActivity;
        Log.d(TAG,"topActivity : " + taskInfo.size() + " this class : " + this.getClass().getName() );
        return topActivity ;

    }
}
