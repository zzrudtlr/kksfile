package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Picture;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

import Database.DB_SingleTon;
import DeliveryDetail.FreightInfo;
import Dialog.ConfirmDialog;
import Dialog.DeliveryAssess.DeliveryInfo;
import Dialog.FinishFreightInfoDialog;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectFourDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectOneDialog;
import Dialog.SelectThreeDialog;
import Dialog.SelectTwoDialog;
import Gps.GpsInfo;
import Permission.DevicePermission;
import Picture.DevicePicture;
import WebView.WebViewClass;
import WebView.OnWebViewClientListener;
import connection.Conn_Address;
import connection.JsonParse;
import memory.RecycleUtils;

/**
 * Created by KyoungSik on 2017-03-15.
 * 내가 등록한 배송자
 */
public class MyRegisteredDeliveryActivity extends Activity {

    private final String TAG = "MyRegisteredDelivery";

    private final int RELOAD_WEBVIEW=3;

    private WebViewClass webViewClass;
    private Loading loading;

    private String delivery_idx="";//내 배송자로 지정할 때 저장할 배송자 idx
    private String freight_idx="";//각 배송자가 배달중인 화물 idx;

    private String lng = "0";
    private String lat = "0";

    private boolean changeinfo = false;//정보 수정 체크
    private int point = 0;//배송완료시 받는 포인트
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myregistered_delivery);

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG,"Start");
        loading = new Loading(getMyRegisteredDeliveryActivity());
        init();
    }


    //내가 등록한 배송자 웹뷰 셋팅
    private void init(){
        //devicePermission = new DevicePermission();
        webViewClass = new WebViewClass((WebView)findViewById(R.id.mrdwebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                loading.show();
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {

            }
        });

        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void my_delivery_more(int state, int deliveryidx, int freightidx) {
                showStateDialog(state);
                Log.d(TAG, "more_m : " + state + " delivery_idx : " + deliveryidx + " freight_idx : " + freightidx);
                delivery_idx = "" + deliveryidx;
                freight_idx = "" + freightidx;
            }

            @JavascriptInterface
            public void h_list(int state, int view_idx) {
                Log.d(TAG, "h_list");
                Intent intent = new Intent(MyRegisteredDeliveryActivity.this, DeliveryInfoDetailActivity.class);
                intent.putExtra("delivery_idx", "" + view_idx);
                startActivity(intent);
            }
        }, "quickbird");
    }

    /* 내가등록한 배송자 url
    *
    * */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.MYREGISTERED_DELIVERY;
        urlStr = urlStr + "?user_type="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserTyp();
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        Log.d(TAG, "getUrlStr : " + urlStr);
        return urlStr;
    }

    /* 배송완료정보 업데이트 url
    *
    * */
    private String getFinishFreightUrlStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_FINISH;
        webUrlStr = webUrlStr + "?freight_idx=" +freight_idx;
        webUrlStr = webUrlStr + "&delivery_idx=" + delivery_idx;
        Log.d(TAG, "getFinishFreightUrlStr : " + webUrlStr);
        return webUrlStr;
    }

    /* 배송자 fcm_key업데이트 url
    *
    * */
    private String getDeliveryFcmKeyUpdateUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_FCMKEY_UPDATE;
        urlStr = urlStr + "?fcm_key=" + FirebaseInstanceId.getInstance().getToken();
        urlStr = urlStr + "&delivery_idx=" + DB_SingleTon.getInstance(this).getUserInfoTable().getDelivery_idx();
        urlStr = urlStr + "&lng=" + lng;
        urlStr = urlStr + "&lat=" + lat;
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }

    /* 배송자 삭제하기 url
   *
   * */
    private String getDeliveryDeleteUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.DELIVERY_DELETE;
        urlStr = urlStr + "?user_idx="+ DB_SingleTon.getInstance(this).getUserInfoTable().getUserIdx();
        urlStr = urlStr + "&delivery_idx="+ delivery_idx;
        return urlStr;
    }

    /*배송자 삭제하기
    *
    * */
    private void deliveryDelete(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);
                if(flag.matches("1")){
                    Toast.makeText(getMyRegisteredDeliveryActivity(),"배송자를 삭제하였습니다.",Toast.LENGTH_SHORT).show();
                    changeinfo = true;//정보 바뀜
                    webViewClass.getWebView().reload();
                }else{
                    webViewClass.getWebView().reload();
                    Toast.makeText(getMyRegisteredDeliveryActivity(),message,Toast.LENGTH_SHORT).show();
                }
                loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getDeliveryDeleteUrlStr());
    }
    /* 배송완료하기
    *
    * */
    private void updateFinishFreight(){

        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    Toast.makeText(getMyRegisteredDeliveryActivity(),"배송이 완료되었습니다.",Toast.LENGTH_SHORT).show();
                    webViewClass.getWebView().reload();
                }else{
                    Toast.makeText(getMyRegisteredDeliveryActivity(),"실패하였습니다.",Toast.LENGTH_SHORT).show();
                }
               loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getFinishFreightUrlStr());
    }

    /* 배송자 fcm_key 업데이트
    *
    * */
    private void updateDeliveryFcmKey(){
        JsonParse jsonParse = new JsonParse(this) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                loading.dismiss();
                if(flag.matches("1")){
                    onStart();
                    Toast.makeText(getMyRegisteredDeliveryActivity(), "내 배송자로 지정되었습니다.", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getMyRegisteredDeliveryActivity(), "배송자 등록에 실패하였습니다.", Toast.LENGTH_SHORT).show();
                }

            }
        };
        jsonParse.getJsonParse(getDeliveryFcmKeyUpdateUrlStr());
    }

    /* 배송 상태에 따라 띄우는 다이얼로그 함수
   *
   * */
    private void showStateDialog(int state){

        SelectFourDialog selectFourDialog = new SelectFourDialog(getMyRegisteredDeliveryActivity()) {
            @Override
            public void clickOneButton(SelectFourDialog selectFourDialog) {
                Intent intent = new Intent(MyRegisteredDeliveryActivity.this, DeliveryEditActivity.class);
                intent.putExtra("delivery_idx",delivery_idx);
                startActivityForResult(intent, RELOAD_WEBVIEW);
                selectFourDialog.dismiss();
            }

            @Override
            public void clickTwoButton(SelectFourDialog selectFourDialog) {
                selectFourDialog.dismiss();
                ConfirmDialog confirmDialog = new ConfirmDialog(getMyRegisteredDeliveryActivity()) {
                    @Override
                    public void onClickConfirm(ConfirmDialog confirmDialog) {
                        confirmDialog.dismiss();
                        handler.sendEmptyMessage(3);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                confirmDialog.getConfirmBtn().setText("확인");
                confirmDialog.getCancelBtn().setText("취소");
                confirmDialog.getTitleText().setText("정말로 삭제를 하시겠습니까?");
                confirmDialog.show();
            }

            @Override
            public void clickThreeButton(SelectFourDialog selectFourDialog) {
                Intent intent = new Intent(MyRegisteredDeliveryActivity.this, DrequestFreightActivity.class);
                intent.putExtra("delivery_idx", delivery_idx);
                startActivityForResult(intent, RELOAD_WEBVIEW);
                selectFourDialog.dismiss();
            }

            @Override
            public void clickFourButton(SelectFourDialog selectFourDialog) {
                GpsInfo gpsInfo = new GpsInfo(getActivity());
                if (gpsInfo.isGetLocation()) {
                    DB_SingleTon.getInstance(getMyRegisteredDeliveryActivity()).getUserInfoTable().updateDeliveryIdx(delivery_idx);//배송자 idx 업데이트
                    Log.d(TAG, "delivery_idx : " + DB_SingleTon.getInstance(getMyRegisteredDeliveryActivity()).getUserInfoTable().getDelivery_idx());
                    selectFourDialog.dismiss();
                    double latitude = gpsInfo.getLatitude();
                    double longitude = gpsInfo.getLongitude();

                    //lat = String.format("%.4f",latitude);
                    // lng = String.format("%.4f",longitude);
                    lat = ""+latitude;
                    lng = ""+longitude;
                    Log.d(TAG, "lat : " + lat + " lng : " + lng);
                    handler.sendEmptyMessage(2);

                } else {
                    Toast.makeText(getMyRegisteredDeliveryActivity(), "GPS 정보를 켜주세요.", Toast.LENGTH_SHORT).show();
                    selectFourDialog.dismiss();
                }
            }

            @Override
            public void clickCancelButton() {

            }
        };
        selectFourDialog.getSelectOneButton().setText("수정");
        selectFourDialog.getSelectTwoButton().setText("삭제");
        selectFourDialog.getSelectThreeButton().setText("화물 선택하기");
        selectFourDialog.getSelectFourButton().setText("내 배송자로 지정");
        selectFourDialog.show();
       /* switch (state){
           case 1://배송확정
                SelectThreeDialog selectThreeDialog = new SelectThreeDialog(this) {
                    @Override
                    public void clickOneButton(SelectThreeDialog selectThreeDialog) {
                        Intent intent = new Intent(MyRegisteredDeliveryActivity.this, FreightInfoDetailActivity.class);
                        intent.putExtra("freight_idx", "" + freight_idx);
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectThreeDialog selectThreeDialog) {

                       Intent intent = new Intent(getMyRegisteredDeliveryActivity(),FreightCompleteInfoActivity.class);
                       intent.putExtra("freight_idx",freight_idx);
                       intent.putExtra("delivery_idx",delivery_idx);
                        startActivity(intent);
                        selectThreeDialog.dismiss();
                    }

                    @Override
                    public void clickThreeButton(SelectThreeDialog selectThreeDialog) {
                        selectThreeDialog.dismiss();
                       handler.sendEmptyMessage(1);
                       // finish();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectThreeDialog.getSelectOneButton().setText("배송중인 화물정보");
                selectThreeDialog.getSelectTwoButton().setText("배송완료정보작성");
                selectThreeDialog.getSelectThreeButton().setText("배송완료");
                selectThreeDialog.show();
                break;
            case 0://미확정

                break;
        }*/
    }

  /*
  *
  * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==0) {
                loading.dismiss();
            }else if(msg.what==1){
                updateFinishFreight();
            }else if(msg.what==2){
                updateDeliveryFcmKey();
            }else if(msg.what == 3){
                deliveryDelete();
            }
        }
    };

    private MyRegisteredDeliveryActivity getMyRegisteredDeliveryActivity(){
        return this;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult : " + requestCode);
        if(resultCode != RESULT_OK)
            return;

        switch (requestCode) {
            case RELOAD_WEBVIEW:{
                changeinfo = true;//정보 바뀜
                try {
                    point = point + Integer.parseInt(data.getStringExtra("point"));
                }catch (NullPointerException e){
                    Log.d(TAG,e.toString());
                }catch (NumberFormatException e){
                    Log.d(TAG,e.toString());
                }
                Log.d(TAG,"point : " + point);
               webViewClass.getWebView().reload();
                break;
            }
        }
    }

    public MyRegisteredDeliveryActivity getActivity(){
        return this;
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Intent intent = new Intent();
        if(changeinfo) {
            intent.putExtra("point",""+point);
            setResult(RESULT_OK,intent);
        }else{
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        RecycleUtils.recursiveRecycle(getWindow().getDecorView());
    }

}
