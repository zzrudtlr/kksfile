package com.quickbird.quickbird;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import Dialog.DetailAddressDialog;
import Dialog.Loading;
import Gps.GpsInfo;
import WebView.OnWebViewClientListener;
import WebView.WebViewClass;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-07-04.
 * 지도 주소 받아오기 Activity
 */
public class SelectAddressActivity extends Activity {
    private final String TAG = "SelectAddressActivity";

    private WebViewClass webViewClass;
    private Loading loading;
    private LinearLayout errorView;

    private String lat;//위도
    private String lng;//경도

    private double my_lat;
    private double my_lng;

    private GpsInfo gps;//gps 위치 정보
    private String address;//주소
    private String searchAddress="";
    private Activity act;

    private EditText searchCityEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_address_map);
        init();
    }

    private void init(){
        loading = new Loading(this);
        errorView = (LinearLayout)findViewById(R.id.fr_errorview);
        searchCityEditText = (EditText)findViewById(R.id.samesearchText);
        gps = new GpsInfo(this);
        if (gps.isGetLocation()) {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();

            //lat = String.format("%.4f",latitude);
            // lng = String.format("%.4f",longitude);
            my_lat = latitude;
            my_lng = longitude;
            Log.d(TAG, "lat : " + my_lat + " lng : " + my_lng);
        } else {
            // GPS 를 사용할수 없으므로
            // gps.showSettingsAlert();
        }
        webViewinit();
        eventButton();

    }

    /* 주소 선택 지도 웹 뷰
     *
     * */
    private void webViewinit(){

        webViewClass = new WebViewClass((WebView)findViewById(R.id.mawebview),this,getUrlStr());
        webViewClass.getWebViewClientClass().setOnWebViewClientListener(new OnWebViewClientListener() {
            @Override
            public void startWebClient(WebView webView, String url) {
                if (!loading.isLoadingState()) {
                    loading.setLoadingState(true);
                    loading.show();
                }
            }

            @Override
            public void finishWebClient(WebView webView, String url) {
                loading.dismiss();
                loading.setLoadingState(false);
            }

            @Override
            public void errorWebClient(WebView webView, int errorCode, String failingUrl) {
                loading.dismiss();
                loading.setLoadingState(false);
                errorView.setVisibility(View.VISIBLE);
            }
        });


        webViewClass.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void map(String lat,String lng, String address) {
                Log.d(TAG, "map lat : " + lat + " lng : " + lng + " address : "+ address);
                setLat(lat);
                setLng(lng);
                setAddress(address);
            }

        }, "quickbird");
    }

    private void eventButton(){
        //웹뷰 재시도 버튼
        Button restartbtn = (Button)findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webViewClass.getWebView().reload();
                errorView.setVisibility(View.GONE);
            }
        });

        //확인 버튼
        Button selectbtn = (Button)findViewById(R.id.maconfirmbtn);
        selectbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetailAddressDialog detailAddressDialog = new DetailAddressDialog(SelectAddressActivity.this) {
                    @Override
                    public void onClickConfirm(String detailInfo, DetailAddressDialog detailAddressDialog) {
                        Intent intent = new Intent();
                        intent.putExtra("lat",lat);
                        intent.putExtra("lng",lng);
                        intent.putExtra("address",address+" "+ detailInfo);
                        setResult(RESULT_OK, intent);
                        detailAddressDialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                detailAddressDialog.show();

            }
        });

        //취소 버튼
        Button cancelbtn = (Button)findViewById(R.id.macancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED, null);
                finish();
                Log.d(TAG, "cancel");
            }
        });

        //검색 버튼
        Button searchbtn = (Button)findViewById(R.id.samesearchbtn);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchAddress = searchCityEditText.getText().toString();
                webViewClass.getWebView().loadUrl(getUrlStr());
            }
        });
    }

    /* 지도 주소 받아오기 url
    *
    * */
    private String getUrlStr(){
        String webUrlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.ADDRESS_MAP;
        if(my_lat == 0){
            webUrlStr = webUrlStr + "?lat=";
        }else{
            webUrlStr = webUrlStr + "?lat="+ my_lat;
        }

        if(my_lng == 0){
            webUrlStr = webUrlStr + "&lng=";
        }else{
            webUrlStr = webUrlStr + "&lng=" + my_lng;
        }
        webUrlStr = webUrlStr + "&address=" + searchAddress;
                Log.d(TAG,"webUrlStr : " + webUrlStr);
        return webUrlStr;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
