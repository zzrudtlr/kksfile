package SearchLayout;

/**
 * Created by KyoungSik on 2017-04-04.
 * 검색 조건 정보
 * $search_flag = $_GET["search_flag"];//전체,화물,배송자 0:배송자 1:화물
 $lat = $_GET["lat"];//현재 내위치에서 떨어진 거리
 $lng = $_GET["lng"];
 $my_distance = $_GET["distance"];//거리별 검색
 $s_address = $_GET["s_address"];//출발지 주소
 $a_address = $_GET["a_address"];//도착지 주소
 $item_idx = $_GET["item_idx"];//아이템 검색
 $key_word = $_GET["key_word"];//키워드검색
 */
public class SearchInfo {
    private int searchState=0;// 전체 화물 배송자 상태

    public final String searchFlagStr = "search_flag";//전체,화물,배송자 0:배송자
    public final String latStr = "lat";//현재 내위치에서 떨어진 거리
    public final String lngStr = "lng";
    public final String distanceStr = "distance";//거리별검색
    public final String s_addressStr = "s_address";//출발지 주소
    public final String a_addressStr = "a_address";//도착지 주소
    public final String item_idxStr = "item_idx";//아이템 검색
    public final String key_wordStr = "key_word";//키워드 검색

    private String  searchFlag="";//전체,화물,배송자

    private String itemidx="";// 품목 idx
    private String itemName="";// 품목 이름

    private String myLng="";
    private String myLat="";

    private String start_address="";//출발지 주소

    private String end_address="";//도착지 주소

    private String myarea_idx="";//내주변 idx
    private String myarea_name="";//내주변 이름

    private String keyword="";//키워드

    public String getSearchFlagStr() {
        return searchFlagStr;
    }

    public int getSearchState() {
        return searchState;
    }

    public void setSearchState(int searchState) {
        this.searchState = searchState;
    }

    public String getItemidx() {
        return itemidx;
    }

    public void setItemidx(String itemidx) {
        this.itemidx = itemidx;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }


    public String getStart_address() {
        return start_address;
    }

    public void setStart_address(String start_address) {
        this.start_address = start_address;
    }


    public String getEnd_address() {
        return end_address;
    }

    public void setEnd_address(String end_address) {
        this.end_address = end_address;
    }

    public String getMyarea_idx() {
        return myarea_idx;
    }

    public void setMyarea_idx(String myarea_idx) {
        this.myarea_idx = myarea_idx;
    }

    public String getMyarea_name() {
        return myarea_name;
    }

    public void setMyarea_name(String myarea_name) {
        this.myarea_name = myarea_name;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getMyLng() {
        return myLng;
    }

    public void setMyLng(String myLng) {
        this.myLng = myLng;
    }

    public String getMyLat() {
        return myLat;
    }

    public void setMyLat(String myLat) {
        this.myLat = myLat;
    }
}
