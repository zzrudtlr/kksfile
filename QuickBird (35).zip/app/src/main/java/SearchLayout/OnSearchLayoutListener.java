package SearchLayout;

/**
 * Created by KyoungSik on 2017-03-12.
 * 검색 필터
 */
public interface OnSearchLayoutListener {
    public void onClickSearchState(int state);
    public void onClickItem(int position, String[] titlelist);
    public void onClickAreaInfo(String lat, String lng, String address, int state);
    public void onClickCancel();
    public void onClickSelect(SearchInfo searchInfo);

}
