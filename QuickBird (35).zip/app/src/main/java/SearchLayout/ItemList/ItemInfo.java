package SearchLayout.ItemList;

/**
 * Created by KyoungSik on 2017-04-26.
 * 품목 정보
 */
public class ItemInfo {
    private String item_idx;
    private String itemName;

    public String getItem_idx() {
        return item_idx;
    }

    public void setItem_idx(String item_idx) {
        this.item_idx = item_idx;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
}
