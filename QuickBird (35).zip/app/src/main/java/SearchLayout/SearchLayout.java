package SearchLayout;

import android.app.Activity;
import android.graphics.Color;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.quickbird.quickbird.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Locale;

import DeliveryDetail.FreightInfo;
import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import SearchLayout.ItemList.ItemInfo;
import connection.Conn_Address;
import connection.JsonParse;

/**
 * Created by KyoungSik on 2017-03-12.
 * 검색 필터
 */
public class SearchLayout {

    private final String TAG = "SearchLayout";

    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;

    public final int STARTAREA = 0;
    public final int ENDAREA = 1;

    private LinearLayout linearLayout;//검색 조건 레이아웃
    private Activity act;

    private TextView itemText;//선택된 품목을 보여주는 TextView
    private TextView myareaText;//선택된 내주변 항목을 보여주는 TextView
    private EditText startText;//출발지 주소를 보여주는 TextView
    private EditText endText;//도착지 주소를 보여주는 TextView
    private EditText keywordEdit;//키워드

    private SearchInfo searchInfo;//검색 정보를 담는 구조체
    private SearchState searchState;

    private ArrayList<ItemInfo> itemInfos;

    private OnSearchLayoutListener onSearchLayoutListener;

    private Loading loading;

    public SearchLayout(LinearLayout linearLayout,Activity act){
        Log.d(TAG, "생성자");
        this.act = act;
        this.linearLayout = linearLayout;
        loading = new Loading(act);
        itemInfos = new ArrayList<>();
        linearLayout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                Log.d(TAG, "setOnTouchListener");
                return true;
            }
        });
        init();
    }

    private void init(){
        itemText = (TextView)linearLayout.findViewById(R.id.searhItemText);
        myareaText = (TextView)linearLayout.findViewById(R.id.myareaText);
        startText = (EditText)linearLayout.findViewById(R.id.alDeparturePointText);
        endText = (EditText)linearLayout.findViewById(R.id.alArrivePointText);
        keywordEdit = (EditText)linearLayout.findViewById(R.id.keywordEdit);
        searchInfo = new SearchInfo();

        initSeaerchState();//전체.화물 및 배송자 선택 버튼 이벤트
        searchInfo.setSearchState(searchState.SEARCH_ALL);
        itemButtonEvent();//품목 버튼 이벤트
        myareaButtonEvent();//내주변 버튼 이벤트
       // startEndAreaEvent();//출발지 도착지 이벤트
        buttonEvent();
    }

    /* 전체.화물 및 배송자 선택 버튼 이벤트
    *
    * */
    private void initSeaerchState(){
        searchState = new SearchState(linearLayout,act) {
            @Override
            public void onClickButton(int state, SearchState searchState) {
                if(searchState.SEARCH_ALL == state){
                    Log.d(TAG,"SEARCH_ALL");
                }else if(searchState.SEARCH_FREIGHT == state){
                    Log.d(TAG,"SEARCH_FREIGHT");
                }else if(searchState.SEARCH_DELIVERY == state){
                    Log.d(TAG,"SEARCH_DELIVERY");
                    searchInfo.setItemidx("");
                    itemText.setText("");
                }
                searchInfo.setSearchState(state);
                if(onSearchLayoutListener != null)
                    onSearchLayoutListener.onClickSearchState(state);
            }
        };

    }


    /*품목 선택 버튼
    *
    * */
    private void itemButtonEvent(){

        Button itembtn = (Button)linearLayout.findViewById(R.id.searchItembtn);
        itembtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick");
                if (searchState.getCurrentSearchState() != searchState.SEARCH_DELIVERY) {//검색 조건이 배송자가 아닐때
                    showItem();
                } else {
                    Toast.makeText(act, "화물 검색시 선택이 가능합니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String getItemInfoUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_ITEMINFO;
        return urlStr;
    }

    private void getItemInfo(){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    if(result.size()>0) {
                        setItemInfos(result);
                    }
                }else{

                }
                loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getItemInfoUrlStr());
    }

    /* 화물리스트 정보 분류하기
    *
    * */
    private void setItemInfos(ArrayList<ArrayList<String>> result){
        itemInfos.clear();
        String itemName[] = new String[result.get(0).size()+1];
        ItemInfo itemInfo2 = new ItemInfo();
        itemInfo2.setItem_idx("0");
        itemInfo2.setItemName("전체");
        itemName[0] = itemInfo2.getItemName();
        itemInfos.add(itemInfo2);
        for(int i=0;i<result.get(0).size();i++){
            Log.d(TAG, "freight_idx : " + result.get(0).get(i));
            Log.d(TAG, "freight_name : " + result.get(1).get(i));
            ItemInfo itemInfo = new ItemInfo();
            itemInfo.setItem_idx(result.get(0).get(i));
            itemInfo.setItemName(result.get(1).get(i));
            itemName[i+1] = itemInfo.getItemName();
            itemInfos.add(itemInfo);
        }
        showItemDialog(itemName);
    }
    /* 품목 다이얼로그 보여주기
    *
    * */
    private void showItem(){

        getItemInfo();

    }
    //품목 선택 다이얼로그
    private void showItemDialog(String[] titlelist){
        //품목 선택 다이얼로그
        SelectListDialog selectListDialog = new SelectListDialog(act, titlelist);
        selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
            @Override
            public void onClickCancel() {

            }

            @Override
            public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                itemText.setText(titlelist[position]);
                searchInfo.setItemidx(itemInfos.get(position).getItem_idx());
                searchInfo.setItemName(titlelist[position]);
                if(onSearchLayoutListener != null)
                    onSearchLayoutListener.onClickItem(position,titlelist);
                selectListDialog.dismiss();
            }

            @Override
            public void onClickList(int position, View view, String[] titlelist) {
                //  view.setBackgroundColor(Color.BLUE);
                Log.d(TAG, "position : " + titlelist[position]);
            }
        });
        selectListDialog.getTitleImage().setImageResource(R.drawable.icon_map_stuff);
        selectListDialog.getTitleText().setText("품목 검색");
        selectListDialog.show();
    }
    /*내주변 선택 버튼 이벤트
    *
    * */
    private void myareaButtonEvent(){
        Button myareabtn = (Button)linearLayout.findViewById(R.id.myareabtn);
        myareabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick");
                String[] titlelist = act.getResources().getStringArray(R.array.myarea_list);
                String[] subtitle = act.getResources().getStringArray(R.array.km);
                //내주변 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(act, titlelist,subtitle);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {

                        searchInfo.setMyarea_idx("" + position);
                        if (titlelist[position].matches("전국")) {
                            searchInfo.setMyarea_name("0");
                            myareaText.setText(titlelist[position]);
                        } else {
                            searchInfo.setMyarea_name(titlelist[position]);
                            myareaText.setText(titlelist[position] + " KM");
                        }
                        if (onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickItem(position, titlelist);
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);
                    }
                });
                selectListDialog.getTitleImage().setImageResource(R.drawable.icon_map_white);
                selectListDialog.getTitleText().setText("내주변 검색");
                selectListDialog.show();
            }
        });
    }

    /* 출발지 도착지 이벤트
    *
    * */
    private void startEndAreaEvent(){
        startText = (EditText)linearLayout.findViewById(R.id.alDeparturePointText);
        startText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "startText event");
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(act) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                        selectInternatinl(DOMESTIC,STARTAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                        selectInternatinl(OVERSEAS,STARTAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
            }
        });

        endText = (EditText)linearLayout.findViewById(R.id.alArrivePointText);
        endText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "endText event");
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(act) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {
                       /* if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,DOMESTIC);*/
                        selectInternatinl(DOMESTIC,ENDAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        /*if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(startText,OVERSEAS);*/
                        selectInternatinl(OVERSEAS,ENDAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
            }
        });
    }

    /* 버튼 이벤트
    *
    * */
    private void buttonEvent(){
        //검색 버튼
        Button searchbtn = (Button)linearLayout.findViewById(R.id.searchbtn);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "searchbtn");
                searchInfo.setStart_address(startText.getText().toString());
                searchInfo.setEnd_address(endText.getText().toString());
                searchInfo.setKeyword(keywordEdit.getText().toString());
                if(onSearchLayoutListener != null)
                    onSearchLayoutListener.onClickSelect(searchInfo);
            }
        });

        //취소 버튼
        Button cancelbtn = (Button)linearLayout.findViewById(R.id.cancelbtn);
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "cancelbtn");
                if(onSearchLayoutListener != null)
                    onSearchLayoutListener.onClickCancel();
            }
        });
    }

    /* 국내, 국외 구분 함수
    *
    * */
    private void selectInternatinl(int countryState, final int pointState){
        if(countryState == DOMESTIC){
           handler.sendEmptyMessage(pointState);
        }else if(countryState == OVERSEAS){
            String[] country;
            Locale[] locales = Locale.getAvailableLocales();

            String[] isoCodes = Locale.getISOCountries();
            country = new String[isoCodes.length];

            for( int i=0; i < isoCodes.length; i++ ){
                Locale locale = new Locale( "en",isoCodes[ i ] );
                Log.d( TAG,"country : " + locale.getDisplayCountry() );
                country[i] = locale.getDisplayCountry();
            }
            //나라 선택 다이얼로그
            SelectListDialog selectListDialog = new SelectListDialog(act, country);
            selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                @Override
                public void onClickCancel() {

                }

                @Override
                public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                    if(pointState == STARTAREA){
                        startText.setText(titlelist[position] + selectListDialog.getSubAddressEdit().getText());
                    }else if(pointState == ENDAREA){
                        endText.setText(titlelist[position] + selectListDialog.getSubAddressEdit().getText());
                    }
                    selectListDialog.dismiss();
                }

                @Override
                public void onClickList(int position, View view, String[] titlelist) {
                    //  view.setBackgroundColor(Color.BLUE);
                    Log.d(TAG, "position : " + titlelist[position]);

                }
            });
            selectListDialog.getTitleText().setText("나라 선택");
            selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
            selectListDialog.show();
        }
    }

    /* 지도 선택 다이얼로그 띄우기
    *
    * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == STARTAREA) {
                // 국내
                SelectAddressDialog selectAddressDialog = new SelectAddressDialog(act) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        startText.setText(address);
                        searchInfo.setStart_address(address);
                        if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(lat,lng,address,STARTAREA);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();
            }else if(msg.what == ENDAREA){
                // 국내
                SelectAddressDialog selectAddressDialog = new SelectAddressDialog(act) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        endText.setText(address);
                        searchInfo.setEnd_address(address);
                        if(onSearchLayoutListener != null)
                            onSearchLayoutListener.onClickAreaInfo(lat,lng,address,ENDAREA);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();
            }
        }
    };

    public void setSearchInfoData(SearchInfo searchInfo){
        Log.d(TAG, "getSearchState : " + searchInfo.getSearchState());
        searchState.searchBooleanState(searchInfo.getSearchState());
        searchState.setCurrentSearchState(searchInfo.getSearchState());
        searchState.setSearchState(searchInfo.getSearchState());
        if(searchInfo.getMyarea_name().matches("전국")){
            myareaText.setText(searchInfo.getMyarea_name());
            searchInfo.setMyarea_name("0");
        }else if(!searchInfo.getMyarea_name().matches("null")) {
            myareaText.setText(searchInfo.getMyarea_name() + " KM");
        }
        if(!searchInfo.getStart_address().matches("null")) {
            startText.setText(searchInfo.getStart_address());
        }
        if (!searchInfo.getEnd_address().matches("null")) {
            endText.setText(searchInfo.getEnd_address());
        }
        if(!searchInfo.getItemName().matches("null")) {
            itemText.setText(searchInfo.getItemName());
            this.searchInfo.setItemidx(searchInfo.getItemidx());
        }
        if(!searchInfo.getKeyword().matches("null")){
            keywordEdit.setText(searchInfo.getKeyword());
        }

        this.searchInfo.setSearchState(searchInfo.getSearchState());

        this.searchInfo.setMyarea_name(searchInfo.getMyarea_name());
        this.searchInfo.setStart_address(searchInfo.getStart_address());
        this.searchInfo.setEnd_address(searchInfo.getEnd_address());
        this.searchInfo.setItemName(searchInfo.getItemName());
        this.searchInfo.setKeyword(searchInfo.getKeyword());
       /* if(searchInfo.getSearchState() != null) {
            searchState.setSearchState(searchInfo.)
        }*/

    }

    /* 예외처리
    *
    * */
    public boolean searchinfoException(SearchInfo searchInfo){
        boolean check = false;
        if(searchInfo.getStart_address().toString().matches("")){

        }else if(searchInfo.getEnd_address().toString().matches("")){

        }else if(searchInfo.getItemidx().matches("")){

        }else if(searchInfo.getKeyword().toString().matches("")){

        }
        return check;
    }

    public void setOnSearchLayoutListener(OnSearchLayoutListener onSearchLayoutListener) {
        this.onSearchLayoutListener = onSearchLayoutListener;
    }

    public SearchInfo getSearchInfo() {
        return searchInfo;
    }

    public SearchLayout getSearchLayout(){
        return  this;
    }

    public SearchState getSearchState() {
        return searchState;
    }
}
