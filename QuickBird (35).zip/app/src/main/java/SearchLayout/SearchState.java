package SearchLayout;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.quickbird.quickbird.R;

import java.util.ArrayList;

/**
 * Created by KyoungSik on 2017-03-13.
 * 검색 레이아웃 검색
 */
public abstract class SearchState {

    private final String TAG = "SearchState";

    public abstract void onClickButton(int state,SearchState searchState);

    private final int MAX_SIZE = 3;

    public final int SEARCH_ALL = 2;//전체
    public final int SEARCH_FREIGHT = 1;//화물
    public final int SEARCH_DELIVERY = 0;//배송자

    private boolean searchallState = false;//전체 체크박스 상태
    private boolean searchfreightState = false;//화물 체크박스 상태
    private boolean searchdeliveryState = false;//배송자 체크박스 상태

    private int currentSearchState;//현재 클릭 된 상태

    private ArrayList<Button> searchbtn;

    private Activity act;

    public SearchState(LinearLayout linearLayout, Activity act){
        this.act = act;
        init(linearLayout);
        initButtonEvent();
    }


    private void init(LinearLayout linearLayout){
        searchbtn = new ArrayList<Button>();

        Button searchallbtn = (Button)linearLayout.findViewById(R.id.searchallbtn);
        Button searchFreight = (Button)linearLayout.findViewById(R.id.searchfreightbtn);
        Button searchDelivery = (Button)linearLayout.findViewById(R.id.searchdeliverybtn);
        searchbtn.add(searchDelivery);
        searchbtn.add(searchFreight);
        searchbtn.add(searchallbtn);

    }

    /* 버튼 이벤트
    *
    * */
    private void initButtonEvent(){
       /* searchbtn.get(SEARCH_ALL).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchallState) {
                    searchallState = true;
                    v.setBackgroundResource(R.drawable.icon_check_on);
                } else {
                    searchallState = false;
                    v.setBackgroundResource(R.drawable.icon_check_off);
                }
                currentSearchState = SEARCH_ALL;
                onClickButton(setSearchState(), getSearchState());
            }
        });*/

        searchbtn.get(SEARCH_FREIGHT).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchfreightState) {
                    searchfreightState = true;
                    v.setBackgroundResource(R.drawable.icon_check_on);
                } else {
                    searchfreightState = false;
                    v.setBackgroundResource(R.drawable.icon_check_off);
                }
                currentSearchState = SEARCH_FREIGHT;

                onClickButton(setSearchState(), getSearchState());
            }
        });

        searchbtn.get(SEARCH_DELIVERY).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchdeliveryState) {
                    searchdeliveryState = true;
                    v.setBackgroundResource(R.drawable.icon_check_on);
                } else {
                    searchdeliveryState = false;
                    v.setBackgroundResource(R.drawable.icon_check_off);
                }
                currentSearchState = SEARCH_DELIVERY;
                onClickButton(setSearchState(), getSearchState());
            }
        });
    }

  /*  public int setSearchState(int state){
        Log.d(TAG, "state : " + state);
        int searchState = 2;
        if(state == SEARCH_ALL){
            searchfreightState = false;
            searchdeliveryState = false;
            searchallState = true;
            searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_on);
            searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
            searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
            searchState = SEARCH_ALL;
        }else if(state == SEARCH_DELIVERY){
            if(searchfreightState){
                searchfreightState = false;
                searchdeliveryState = false;
                searchallState = true;
                searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_on);
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                searchState = SEARCH_ALL;
            }else{
                if(!searchdeliveryState){
                    Log.d(TAG,"searchdeliveryState : " + searchdeliveryState);
                    searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                }else {
                    searchallState = false;
                    searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
                    searchState = SEARCH_DELIVERY;
                }
            }
        }else if(state == SEARCH_FREIGHT) {
            if (searchdeliveryState) {
                searchfreightState = false;
                searchdeliveryState = false;
                searchallState = true;
                searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_on);
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                searchState = SEARCH_ALL;
            } else {
                if(!searchfreightState){
                    searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                }else {
                    searchallState = false;
                    searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
                    searchState = SEARCH_FREIGHT;
                }
            }
        }
        Log.d(TAG, "searchState : " + searchState);
        return searchState;
    }*/
    public int setSearchState(int state){
        Log.d(TAG, "state : " + state);
        int searchState = SEARCH_ALL;
        if(state == SEARCH_ALL){
         //   searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_on);
            searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
            searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
            searchfreightState = true;
            searchdeliveryState = true;
        }else if(state == SEARCH_DELIVERY){
         //   searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
            searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
            searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
            searchState = SEARCH_DELIVERY;

        }else{
         //   searchbtn.get(SEARCH_ALL).setBackgroundResource(R.drawable.icon_check_off);
            searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
            searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
            searchState = SEARCH_FREIGHT;
        }
        return searchState;
    }
  public int setSearchState(){

      int searchState = SEARCH_ALL;
      currentSearchState = SEARCH_ALL;
      if(!searchdeliveryState && searchfreightState){
        searchState = SEARCH_FREIGHT;
          currentSearchState = SEARCH_FREIGHT;
          Log.d(TAG, "searchState : 화물");
      }else if(searchdeliveryState && !searchfreightState){
          searchState = SEARCH_DELIVERY;
          currentSearchState = SEARCH_DELIVERY;
          Log.d(TAG, "searchState : 배송자");
      }
      Log.d(TAG, "searchState : " + searchState);
      return searchState;
  }
    /*public int setSearchState(int state){
        Log.d(TAG,"state : " + state + " searchallState : "  + searchallState + " searchdeliveryState : " + searchdeliveryState + " searchfreightState : " + searchfreightState);
        int searchState = 2;
        if(state == SEARCH_ALL){
          //  searchfreightState = false;
           // searchdeliveryState = false;
            searchallState = true;
            searchState = SEARCH_ALL;
            searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
            searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
        }else if(state == SEARCH_DELIVERY){
            if((searchfreightState && searchdeliveryState)){
              //  searchfreightState = false;
              //  searchdeliveryState = false;
                searchallState = true;
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
                searchState = SEARCH_ALL;
            }else if((!searchfreightState && !searchdeliveryState)){
                searchallState = true;
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                searchState = SEARCH_ALL;
            }else{
                searchallState = false;
                if(!searchdeliveryState){
                    Log.d(TAG,"searchdeliveryState : " + searchdeliveryState);
                    searchState = SEARCH_FREIGHT;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                }else if(!searchdeliveryState && !searchfreightState) {
                    searchState = SEARCH_ALL;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                }else {
                    searchState = SEARCH_DELIVERY;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
                }
            }
        }else if(state == SEARCH_FREIGHT) {
            if ((searchfreightState && searchdeliveryState) || (!searchfreightState && !searchdeliveryState)) {
              //  searchfreightState = false;
              //  searchdeliveryState = false;
                searchallState = true;
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
                searchState = SEARCH_ALL;
            } else if((!searchfreightState && !searchdeliveryState)){
                searchallState = true;
                searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                searchState = SEARCH_ALL;
            }else {
                searchallState = false;
                if(!searchfreightState){
                    searchState = SEARCH_DELIVERY;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_on);
                }else if(!searchdeliveryState && !searchfreightState) {
                    searchState = SEARCH_ALL;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_off);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                }else {

                    searchState = SEARCH_FREIGHT;
                    searchbtn.get(SEARCH_FREIGHT).setBackgroundResource(R.drawable.icon_check_on);
                    searchbtn.get(SEARCH_DELIVERY).setBackgroundResource(R.drawable.icon_check_off);
                }
            }
        }
        Log.d(TAG,"searchState : " + searchState);
        return searchState;
    }*/

    public void searchBooleanState(int state){
        if(state == SEARCH_ALL){
            searchallState = true;
        }else if(state == SEARCH_FREIGHT){
            searchfreightState = true;
        }else if(state == SEARCH_DELIVERY){
            searchdeliveryState = true;
        }
    }

    public int getCurrentSearchState() {
        return currentSearchState;
    }

    public void setCurrentSearchState(int currentSearchState) {
        this.currentSearchState = currentSearchState;
    }


    private SearchState getSearchState(){
        return this;
    }

}
