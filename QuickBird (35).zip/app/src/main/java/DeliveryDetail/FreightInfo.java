package DeliveryDetail;

/**
 * Created by KyoungSik on 2017-04-24.
 */
public class FreightInfo {

    private String freight_name="";
    private String freight_idx;

    public String getFreight_name() {
        return freight_name;
    }

    public void setFreight_name(String freight_name) {
        this.freight_name = freight_name;
    }

    public String getFreight_idx() {
        return freight_idx;
    }

    public void setFreight_idx(String freight_idx) {
        this.freight_idx = freight_idx;
    }
}
