package QB_MainVIewPager;
import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

/**
 * Created by KyoungSik on 2017-04-28.
 */
public class QB_ViewPager extends  ViewPager{

    public QB_ViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
