package QB_MainVIewPager.MyPage;

import android.app.Activity;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.quickbird.quickbird.R;

import java.util.ArrayList;

import Database.DB_SingleTon;
import Picture.CustomBitmapPool;
import UserInfo.PrivateUserInfo;
import connection.Conn_Address;
import connection.JsonParse;
import jp.wasabeef.glide.transformations.CropCircleTransformation;

/**
 * Created by KyoungSik on 2017-03-07.
 * 마이페이지
 */
public class MyPageView {

    private final String TAG = "MyPageView";

    private View view;
    private Activity act;

   // private MyListInfoView myListInfoView;
   private Bitmap profile_img;
    private ImageView profileImageView;
    private TextView nameText;//유저 아이디
    private TextView pointText;//유저 포인트
    private String image_path = "";
    private MyPageListView myPageListView;

    private boolean profileImageDownLoad = false;

    private PrivateUserInfo privateUserInfo;//유저 정보
    public MyPageView(View view, Activity act){
        this.view = view;
        this.act = act;
      //  myListInfoView = new MyListInfoView(view);
        init();
    }

    private void init(){
        profileImageView = (ImageView)view.findViewById(R.id.qmpprofileImageView);
        nameText = (TextView)view.findViewById(R.id.nameText);
        pointText = (TextView)view.findViewById(R.id.pointText);
        Button camerabtn = (Button)view.findViewById(R.id.qmpcamerabtn);
        initListView();
        camerabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myPageListView.getOnMyListInfoListener() != null)
                    myPageListView.getOnMyListInfoListener().onClickCamera();
            }
        });
        if(!DB_SingleTon.getInstance(act).getUserInfoTable().getProfileImage().matches("null")){
            String profile_imageUrl = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + DB_SingleTon.getInstance(act).getUserInfoTable().getProfileImage();
            Log.d(TAG,"profile_imageUrl : " + profile_imageUrl);
            Glide.with(act).load(profile_imageUrl)
                    .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                    .into(profileImageView);
        }else{//프로필사진이 등록이 안되있을 경우
            profileImageView.setImageResource(R.drawable.profile_man_white);
        }
        //requestUserInfo();
        try {
            if (DB_SingleTon.getInstance(act).getUserInfoTable().getUserTyp().matches("1")) {//개인 유저일경우

                requestPrivateUserInfo();

            } else {//사업자 회원일 경우
                requestCompanyUserInfo();
            }
        }catch (NullPointerException e) {
            nameText.setText("이름");
            pointText.setText("0");
            profileImageView.setImageResource(R.drawable.profile_man_white);
            profileImageDownLoad = true;
        }
        //Glide.with(act).load(profile_imageUrl).into(profileImageView);
    }

    public void profileReload(){
        String profile_imageUrl = Conn_Address.SERVER_ADDRESS + Conn_Address.IMAGEADDRESS + DB_SingleTon.getInstance(act).getUserInfoTable().getProfileImage();
        Log.d(TAG,"profileReload : " + profile_imageUrl);
        Glide.with(act).load(profile_imageUrl)
                .bitmapTransform(new CropCircleTransformation(new CustomBitmapPool()))
                .into(profileImageView);
    }
//http://quickbird.dev.wyhil.com/img/146565324132454.jpg
    private void initListView(){
        ListView listView = (ListView)view.findViewById(R.id.listView);
        myPageListView = new MyPageListView(listView,act);
    }

    /* 사업자 회원정보 받아오기 주소 값
    *
    * */
    private String getCompanyRegisterUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.REQUEST_COMPANYUSERINFO;
        urlStr = urlStr + "?user_idx=" + DB_SingleTon.getInstance(act).getUserInfoTable().getUserIdx();
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }
    /*  사업자 회원 유저정보 받아오기
    *
    * */
    private void requestCompanyUserInfo(){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);

                if (flag.matches("1")) {
                  /*  privateUserInfo.setEmailid(result.get(0).get(0));
                    privateUserInfo.setName(result.get(1).get(0));
                    privateUserInfo.setPhone_number(result.get(2).get(0));
                    privateUserInfo.setProfile_img(result.get(3).get(0));
                    privateUserInfo.setUser_type(result.get(4).get(0));*/

                    Log.d(TAG, "Profile name : " + result.get(0).get(0));
                    Log.d(TAG, "user point : " + result.get(10).get(0));
                 //   Log.d(TAG, "Profile point : " + result.get(5).get(0));
                   // nameText.setText(result.get(0).get(0));
                   // pointText.setText(result.get(5).get(0) + " P");
                    nameText.setText(result.get(0).get(0));
                    pointText.setText(result.get(10).get(0));
                } else {
                    Log.d(TAG, "정보를 받아오는데 실패했습니다.");
                }
                profileImageDownLoad = true;
            }
        };
        jsonParse.getJsonParse(getCompanyRegisterUrlStr());
    }

    /* 개인 회원정보 받아오기 주소 값
*
* */
    private String getRegisterUrlStr(){
        String urlStr = "";

        urlStr = Conn_Address.SERVER_ADDRESS+Conn_Address.REQUEST_PRIVATEUSERINFO;
        urlStr = urlStr + "?user_idx=" + DB_SingleTon.getInstance(act).getUserInfoTable().getUserIdx();
        Log.d(TAG,"urlStr : " + urlStr);
        return urlStr;
    }


    /* 개인회원 유저정보 받아오기
   *
   * */
    private void requestPrivateUserInfo(){

        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                Log.d(TAG, "flag : " + flag);
                Log.d(TAG, "message : " + message);

                if (flag.matches("1")) {
                  /*  privateUserInfo.setEmailid(result.get(0).get(0));
                    privateUserInfo.setName(result.get(1).get(0));
                    privateUserInfo.setPhone_number(result.get(2).get(0));
                    privateUserInfo.setProfile_img(result.get(3).get(0));
                    privateUserInfo.setUser_type(result.get(4).get(0));*/

                    Log.d(TAG, "Profile name : " + result.get(0).get(0));
                    Log.d(TAG, "Profile point : " + result.get(5).get(0));
                    nameText.setText(result.get(0).get(0));
                    pointText.setText(result.get(5).get(0));

                } else {
                    Log.d(TAG, "정보를 받아오는데 실패했습니다.");
                }
                profileImageDownLoad = true;
            }
        };
        jsonParse.getJsonParse(getRegisterUrlStr());
    }

    public void setProfileImage(Bitmap bitmap){
        profileImageView.setImageBitmap(bitmap);
    }

    public MyPageListView getMyPageListView() {
        return myPageListView;
    }

    /* public MyListInfoView getMyListInfoView() {
        return myListInfoView;
    }*/

    public Bitmap getProfile_img() {
        return profile_img;
    }

    public void setProfile_img(Bitmap profile_img) {
        this.profile_img = profile_img;
    }

    public ImageView getProfileImageView() {
        return profileImageView;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public TextView getPointText() {
        return pointText;
    }
}
