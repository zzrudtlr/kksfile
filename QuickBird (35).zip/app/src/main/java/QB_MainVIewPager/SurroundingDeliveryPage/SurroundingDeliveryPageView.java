package QB_MainVIewPager.SurroundingDeliveryPage;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.ActionMenuView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.quickbird.quickbird.DeliveryInfoDetailActivity;
import com.quickbird.quickbird.FreightInfoDetailActivity;
import com.quickbird.quickbird.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import Database.DB_SingleTon;
import Gps.GpsInfo;
import QB_MainVIewPager.HomePage.HomePageWebView;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-03-08.
 * 주변 배송자 페이지
 */
public class SurroundingDeliveryPageView {

    private final String TAG = "SurroundingDelivery";

    public final int SEARCH_DELIVERY = 0;
    public final int SEARCH_FREIGHT=1;

    public final int deliveryColor = Color.rgb(255, 116, 59);//배송자 라인 색깔
    public final int freightColor = Color.rgb(5, 151, 216);//화물 라인 색깔

    private OnSurroundingDeliveryListener onSurroundingDeliveryListener;

    private SurroundingDeliveryWebView surroundingDeliveryWebView;
    private Activity act;
    private View view;
    private LinearLayout delivery_plinear;//배송자 정보
    private LinearLayout errorView;//웹뷰 에러났을떄 보여주는 페이지
    private ImageView profileImageView;
    private TextView nameText;
    private TextView memoText;

    private Button selectbtn;
    private Button requestDeliverybtn;
    private LinearLayout selectlinear;
    private LinearLayout linelinear;

    private  Button deliveryCall;//전화걸기
    private ImageView delivery_pexit;//정보 종료
    private Button dpdetailbtn;//상세정보

    private boolean dpState = false;
    private GpsInfo gps;//gps 위치 정보
    private double latitude=0;
    private double longitude=0;

    private EditText searchEdit;

    private int searchFlag = SEARCH_DELIVERY;//0:배송자 1:화물

    public String search_idx = "";//검색할 idx
    public String phoneNumber = "010-000-0000";

    public SurroundingDeliveryPageView(View view, Activity act){
        this.act = act;
        this.view = view;
        init(view);
        initWebView(view);
        //webPageEvent();
    }

    private void init(View view){
        errorView = (LinearLayout)view.findViewById(R.id.qms_errorview);
        searchEdit = (EditText)view.findViewById(R.id.sudesearchText);
        nameText = (TextView)view.findViewById(R.id.dnameText);
        memoText = (TextView)view.findViewById(R.id.dmemoText);
        profileImageView = (ImageView)view.findViewById(R.id.dprofileImageview);


        delivery_pinit(view);
        buttonEvent(view);
        gps = new GpsInfo(act);
        if (gps.isGetLocation()) {
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
            Log.d(TAG,"latitude : " + latitude + " longitude : " + longitude);
        } else {
            // GPS 를 사용할수 없으므로

        }
        if(searchFlag == SEARCH_FREIGHT){
            selectbtn.setText("화 물");
        }else if(searchFlag == SEARCH_DELIVERY){
            selectbtn.setText("배송자");
        }
    }

    private void delivery_pinit(View view){
        delivery_plinear = (LinearLayout)view.findViewById(R.id.delivery_plinear);
        linelinear = (LinearLayout)view.findViewById(R.id.dlinearline);
    }

    /* 버튼 이벤트
    *
    * */
    private void buttonEvent(View view){
        selectbtn = (Button)view.findViewById(R.id.sudselelctbtn);
        selectbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickSelect(getSurroundigDeliveryPageView());
            }
        });

        selectlinear = (LinearLayout)view.findViewById(R.id.sudselectlinear);
        selectlinear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickSelect(getSurroundigDeliveryPageView());
            }
        });

        //검색 버튼
        Button searchbtn = (Button)view.findViewById(R.id.sudesearchbtn);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            //    if(!dpState){

             //   }
                if(onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickSearch(getSurroundigDeliveryPageView());
            }
        });

        //갱신 버튼
        Button returnbtn = (Button)view.findViewById(R.id.sudereturnbtn);
        returnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gps = new GpsInfo(act);
                if (gps.isGetLocation()) {
                    latitude = gps.getLatitude();
                    longitude = gps.getLongitude();
                    Log.d(TAG,"latitude : " + latitude + " longitude : " + longitude);
                } else {
                    // GPS 를 사용할수 없으므로

                }
                if (onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickReturn(getSurroundigDeliveryPageView());
            }
        });

        delivery_pexit = (ImageView)view.findViewById(R.id.deliverypexit);
        delivery_pexit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "delivery_pexit");

                downAniMove(delivery_plinear);
                dpState = false;
            }
        });

        //전화걸기
        deliveryCall = (Button)view.findViewById(R.id.deliverycall);
        deliveryCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"deliveryCall");
                if (onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickCall(phoneNumber);
            }
        });
        //상세정보
        dpdetailbtn = (Button)view.findViewById(R.id.dpdetailinfo);
        dpdetailbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickDetailInfo(search_idx,""+searchFlag);
            }
        });

        //웹뷰 재시도 버튼
        Button restartbtn = (Button)view.findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onRestartView(surroundingDeliveryWebView.getWebView());
            }
        });

        requestDeliverybtn = (Button)view.findViewById(R.id.requestdeliverybtn);
        requestDeliverybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onSurroundingDeliveryListener != null)
                    onSurroundingDeliveryListener.onClickRequestDelivery(search_idx,""+searchFlag);
            }
        });
    }

    private void webPageEvent(){
        surroundingDeliveryWebView.getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void marker_click(int seq) {
                Log.d(TAG, "marker_click");
                upAniMove(delivery_plinear);
                dpState = true;


            }
        }, "quickbird");
    }

    /* 내가등록한 화물 url
    *
    * */
    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.SURROUNDING_SEARCH;
        if(latitude == 0){
            urlStr = urlStr + "?lat=";
        }else{
            urlStr = urlStr + "?lat="+ latitude;
        }

        if(longitude == 0){
            urlStr = urlStr + "&lng=";
        }else{
            urlStr = urlStr + "&lng=" + longitude;
        }
        try {
            urlStr = urlStr + "&address=" + URLEncoder.encode(searchEdit.getText().toString(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        urlStr = urlStr + "&search_flag=" + searchFlag;
        Log.d(TAG, "getUrlStr : " + urlStr);
        return urlStr;
    }

    /* 재검색
    *
    * */
    public void changeSearch(){
        if(searchFlag == SEARCH_FREIGHT){
            selectbtn.setText("화 물");
        }else if(searchFlag == SEARCH_DELIVERY){
            selectbtn.setText("배송자");
        }
        surroundingDeliveryWebView.getWebView().loadUrl(getUrlStr());

    }
    /* 주변 배송자 위치 알려주는 웹뷰
    *
    * */
    private void initWebView(View view){

        WebView webView = (WebView)view.findViewById(R.id.surrounddeliverywebview);
        surroundingDeliveryWebView = new SurroundingDeliveryWebView(webView,act,getUrlStr());

    }

    public void reLoadWebPage(){
        surroundingDeliveryWebView.getWebView().loadUrl(getUrlStr());
    }

    public void upAniMove(LinearLayout linearLayout){
        TranslateAnimation move = new TranslateAnimation
                (0,   // fromXDelta
                        0,  // toXDelta
                        linearLayout.getHeight(),    // fromYDelta
                        0);// toYDelta
        move.setDuration(200);
        move.setFillAfter(true);
        move.setFillEnabled(true);
        linearLayout.startAnimation(move);
        move.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                delivery_pexit.setEnabled(true);
                deliveryCall.setEnabled(true);
                dpdetailbtn.setEnabled(true);
                delivery_plinear.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


    }
    public void downAniMove(final LinearLayout linearLayout){
        TranslateAnimation move = new TranslateAnimation
                (0,   // fromXDelta
                        0,  // toXDelta
                        0,    // fromYDelta
                        linearLayout.getHeight());// toYDelta
        move.setDuration(200);
        move.setFillAfter(true);
        move.setFillEnabled(true);
        linearLayout.startAnimation(move);
        move.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                delivery_pexit.setEnabled(false);
                deliveryCall.setEnabled(false);
                dpdetailbtn.setEnabled(false);
                delivery_plinear.setVisibility(View.GONE);


            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    public void setOnSurroundingDeliveryListener(OnSurroundingDeliveryListener onSurroundingDeliveryListener) {
        this.onSurroundingDeliveryListener = onSurroundingDeliveryListener;
    }

    public SurroundingDeliveryPageView getSurroundigDeliveryPageView(){
        return this;
    }

    public SurroundingDeliveryWebView getSurroundingDeliveryWebView() {
        return surroundingDeliveryWebView;
    }

    public LinearLayout getErrorView() {
        return errorView;
    }

    public LinearLayout getDelivery_plinear() {
        return delivery_plinear;
    }

    public TextView getNameText() {
        return nameText;
    }

    public TextView getMemoText() {
        return memoText;
    }

    public ImageView getProfileImageView() {
        return profileImageView;
    }

    public void setDpState(boolean dpState) {
        this.dpState = dpState;
    }

    public void setSearchFlag(int searchFlag) {
        this.searchFlag = searchFlag;
    }

    public int getSearchFlag() {
        return searchFlag;
    }

    public LinearLayout getLinelinear() {
        return linelinear;
    }

    public Button getRequestDeliverybtn() {
        return requestDeliverybtn;
    }

    public void setRequestDeliverybtn(Button requestDeliverybtn) {
        this.requestDeliverybtn = requestDeliverybtn;
    }
}
