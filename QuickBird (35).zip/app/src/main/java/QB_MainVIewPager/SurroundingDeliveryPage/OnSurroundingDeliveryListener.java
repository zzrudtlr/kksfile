package QB_MainVIewPager.SurroundingDeliveryPage;

import android.webkit.WebView;

/**
 * Created by KyoungSik on 2017-03-08.
 * 주변 배송자 이벤트 리스너
 */
public interface OnSurroundingDeliveryListener {
    public void onClickSearch(SurroundingDeliveryPageView surroundingDeliveryPageView);
    public void onClickReturn(SurroundingDeliveryPageView surroundingDeliveryPageView);
    public void onClickCall(String phoneNumber);
    public void onClickDetailInfo(String idx, String search_falg);
    public void onClickSelect(SurroundingDeliveryPageView surroundingDeliveryPageView);
    public void onClickRequestDelivery(String search_idx, String search_falg);
    public void onRestartView(WebView webView);
}
