package QB_MainVIewPager.BookMarkPage;

import android.webkit.WebView;

/**
 * Created by KyoungSik on 2017-03-07.
 */
public interface OnBookMarkPageListener {
    public void onClickfilter();
    public void onRestartView(WebView webView);
}
