package QB_MainVIewPager.BookMarkPage;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;

import com.quickbird.quickbird.DeliveryInfoDetailActivity;
import com.quickbird.quickbird.FreightInfoDetailActivity;
import com.quickbird.quickbird.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import Database.DB_SingleTon;
import Gps.GpsInfo;
import QB_MainVIewPager.HomePage.HomePageWebView;
import SearchLayout.SearchInfo;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-03-07.
 * 즐겨찾기 페이지
 */
public class BookMarkPageView {

    private final String TAG = "HomePageView";

    private OnBookMarkPageListener onBookMarkPageListener;
    private Activity act;

    private BookMarkPageWebView bookMarkPageWebView;
    private LinearLayout errorView;//웹뷰 에러났을떄 보여주는 페이지

    private double latitude=0;
    private double longitude=0;

    private GpsInfo gps;

    public BookMarkPageView(View view, Activity act){
        this.act = act;
        init(view);
        initWebView(view);
    }

    private void init(View view){
        errorView = (LinearLayout)view.findViewById(R.id.qmb_errorview);
        buttonEvent(view);
        gps = new GpsInfo(act);

        if (gps.isGetLocation()) {
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
            Log.d(TAG, "latitude : " + latitude + " longitude : " + longitude);
        } else {
            // GPS 를 사용할수 없으므로
           // gps.showSettingsAlert();
        }
    }

    private void buttonEvent(View view){
        Button filterbtn = (Button)view.findViewById(R.id.filterbtn);
        filterbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onBookMarkPageListener != null)
                    onBookMarkPageListener.onClickfilter();
            }
        });

        //웹뷰 재시도 버튼
        Button restartbtn = (Button)view.findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onBookMarkPageListener != null)
                    onBookMarkPageListener.onRestartView(bookMarkPageWebView.getWebView());
            }
        });
    }

    private String getWebUrl(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.BOOKMARK;
        urlStr = urlStr + "?lat="+latitude;
        urlStr = urlStr + "&lng=" + longitude;
        urlStr = urlStr + "&user_idx=" + DB_SingleTon.getInstance(act).getUserInfoTable().getUserIdx();
        Log.d(TAG,"getBookMarkUrl : " + urlStr);
        return urlStr;
    }

    private void initWebView(View view){

        WebView webView = (WebView)view.findViewById(R.id.bookmarkwebview);
        bookMarkPageWebView = new BookMarkPageWebView(webView,act,getWebUrl());
     //   initWebViewJavascript();
    }

    /* 검색시 새로 웹 갱신
    *
    * */
   /* public void reloadWebview(SearchInfo searchInfo){
        String loadurl = homeAddressUrl;
        loadurl = loadurl + "?"+searchInfo.searchFlagStr + "="+searchInfo.getSearchFlagStr();
        loadurl = loadurl+"&"+searchInfo.latStr+"="+searchInfo.getMyLat();
        loadurl = loadurl+"&"+searchInfo.lngStr+"="+searchInfo.getMyLng();
        loadurl = loadurl+"&distance=3";
        try {
            loadurl = loadurl + "&"+searchInfo.s_addressStr + "="+ URLEncoder.encode(searchInfo.getStart_address(), "UTF-8");
            loadurl = loadurl + "&"+searchInfo.a_addressStr + "="+URLEncoder.encode(searchInfo.getEnd_address(), "UTF-8");
            loadurl = loadurl + "&"+searchInfo.item_idxStr + "="+searchInfo.getItemidx();
            loadurl = loadurl + "&"+searchInfo.key_wordStr + "="+URLEncoder.encode(searchInfo.getKeyword(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        bookMarkPageWebView.getWebView().loadUrl(loadurl);
    }
*/
    private void initWebViewJavascript(){
        bookMarkPageWebView.getWebView().addJavascriptInterface(new Object(){

            @JavascriptInterface
            public void h_list(int state){
                Log.d(TAG, "h_list");
                if(state == 0){//화물
                    Intent intent = new Intent(act, FreightInfoDetailActivity.class);
                    act.startActivity(intent);
                }else if(state == 1){//배송자
                    Intent intent = new Intent(act, DeliveryInfoDetailActivity.class);
                    act.startActivity(intent);
                }
            }
        },"quickbird");

    }

    public BookMarkPageWebView getBookMarkPageWebView() {
        return bookMarkPageWebView;
    }

    public void setOnBookMarkPageListener(OnBookMarkPageListener onBookMarkPageListener) {
        this.onBookMarkPageListener = onBookMarkPageListener;
    }

    public LinearLayout getErrorView() {
        return errorView;
    }
}
