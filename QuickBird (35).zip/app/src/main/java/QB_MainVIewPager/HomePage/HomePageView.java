package QB_MainVIewPager.HomePage;

import android.app.Activity;
import android.content.Intent;
import android.nfc.Tag;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;

import com.quickbird.quickbird.CompanyUserRegisterActivity;
import com.quickbird.quickbird.DeliveryInfoDetailActivity;
import com.quickbird.quickbird.FreightInfoDetailActivity;
import com.quickbird.quickbird.PrivateUserRegisterActivity;
import com.quickbird.quickbird.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import Dialog.SelectTwoDialog;
import Gps.GpsInfo;
import SearchLayout.SearchInfo;
import connection.Conn_Address;

/**
 * Created by KyoungSik on 2017-03-03.
 *  홈 페이지
 */
public class HomePageView {

    private final String TAG = "HomePageView";

    private OnHomePageListener onHomePageListener;

    public final String homeAddressUrl = Conn_Address.SERVER_ADDRESS+Conn_Address.HOME;
    private String subAddress="";

    private Activity act;
    private HomePageWebView homePageWebView;//홈페이지 웹뷰
    private LinearLayout errorView;//웹뷰 에러났을떄 보여주는 페이지

    private GpsInfo gps;

    private double latitude=0;
    private double longitude=0;

    public HomePageView(View view, Activity act){
        this.act = act;

        init(view);
        initWebView(view);
    }

    private void init(View view){
        errorView = (LinearLayout)view.findViewById(R.id.qmh_errorview);
        gps = new GpsInfo(act);

        if (gps.isGetLocation()) {
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
            Log.d(TAG, "latitude : " + latitude + " longitude : " + longitude);
        } else {
            // GPS 를 사용할수 없으므로
            // gps.showSettingsAlert();
        }
        buttonEvent(view);
    }

    private void buttonEvent(View view){
        //검색 필터 버튼
        Button searchbtn = (Button)view.findViewById(R.id.searchbtn);
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "searchbtn click");
                //onOpenLeftDrawer();
                if(onHomePageListener != null)
                    onHomePageListener.onClickSearch();
            }
        });

        //등록 버튼
        Button writebtn = (Button) view.findViewById(R.id.writebtn);
        writebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onHomePageListener != null)
                    onHomePageListener.onClickWrite();
            }
        });

        //웹뷰 재시도 버튼
        Button restartbtn = (Button)view.findViewById(R.id.restartbtn);
        restartbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onHomePageListener != null)
                    onHomePageListener.onRestartView(homePageWebView.getWebView());
            }
        });
    }

    private void initWebView(View view){

        WebView webView = (WebView)view.findViewById(R.id.homepagewebview);
        homePageWebView = new HomePageWebView(webView,act,getUrlStr());
       // initWebViewJavascript();
    }

    private String getUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.HOME;
        urlStr = urlStr + "?search_flag=2";
        urlStr = urlStr+"&lat="+longitude;
        urlStr = urlStr+"&lng="+longitude;
        urlStr = urlStr+"&distance=";
        urlStr = urlStr + "&s_address=";
        urlStr = urlStr + "&a_address=";
        urlStr = urlStr + "&item_idx=";
        urlStr = urlStr + "&key_word=";
        Log.d(TAG,"getUrlStr : " + urlStr);
        return urlStr;
    }

    private void initWebViewJavascript(){
        homePageWebView.getWebView().addJavascriptInterface(new Object(){
            @JavascriptInterface
            public void h_list(int state){
                Log.d(TAG, "h_list");
                if(state == 0){//화물
                    Intent intent = new Intent(act, FreightInfoDetailActivity.class);
                    act.startActivity(intent);
                }else if(state == 1){//배송자
                    Intent intent = new Intent(act, DeliveryInfoDetailActivity.class);
                    act.startActivity(intent);
                }
            }
        },"quickbird");
    }

    /* 검색시 새로 웹 갱신
    *
    * */
    public void reloadWebview(SearchInfo searchInfo){
        String loadurl = homeAddressUrl;
        loadurl = loadurl + "?"+searchInfo.searchFlagStr + "="+searchInfo.getSearchState();
        loadurl = loadurl+"&"+searchInfo.latStr+"="+searchInfo.getMyLat();
        loadurl = loadurl+"&"+searchInfo.lngStr+"="+searchInfo.getMyLng();
        loadurl = loadurl+"&distance="+searchInfo.getMyarea_name();
        try {
            loadurl = loadurl + "&"+searchInfo.s_addressStr + "="+URLEncoder.encode(searchInfo.getStart_address(), "UTF-8");
            loadurl = loadurl + "&"+searchInfo.a_addressStr + "="+URLEncoder.encode(searchInfo.getEnd_address(), "UTF-8");
            loadurl = loadurl + "&"+searchInfo.item_idxStr + "="+searchInfo.getItemidx();
            loadurl = loadurl + "&"+searchInfo.key_wordStr + "="+URLEncoder.encode(searchInfo.getKeyword(), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Log.d(TAG,"home loadurl : " + loadurl);
        homePageWebView.getWebView().loadUrl(loadurl);

    }
    /* 검색 조건
    *
    * */
    public void setSubAddress(String subAddress) {
        this.subAddress = subAddress;
    }

    public HomePageWebView getHomePageWebView() {
        return homePageWebView;
    }

    /* 홈 페이지뷰 이벤트 리스너 설정
        *
        * */
    public void setOnHomePageListener(OnHomePageListener onHomePageListener){
        this.onHomePageListener = onHomePageListener;
    }

    public LinearLayout getErrorView() {
        return errorView;
    }
}
