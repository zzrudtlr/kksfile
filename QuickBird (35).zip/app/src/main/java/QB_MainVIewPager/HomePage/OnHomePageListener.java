package QB_MainVIewPager.HomePage;

import android.webkit.WebView;

/**
 * Created by KyoungSik on 2017-03-06.
 */
public interface OnHomePageListener {
    public void onClickSearch();
    public void onClickWrite();
    public void onRestartView(WebView webView);
}
