package QB_MainVIewPager.OptionPage;

import SearchLayout.SearchInfo;

/**
 * Created by KyoungSik on 2017-04-03.
 * 옵션 페이지 이벤트 리스너
 */
public interface OnOptionListener {

    public void onClickState(int state);
    public void onClickPushState(int state);
    public void onClickStoreage(SearchInfo searchInfo);
    public void onClickNotice();
    public void onStartInfo();
    public void onNoticeCount(int noticeCount);
    public void onEndInfo();
}
