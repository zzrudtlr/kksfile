package QB_MainVIewPager.OptionPage;

import android.app.Activity;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.quickbird.quickbird.R;

import java.util.ArrayList;
import java.util.Locale;

import Dialog.Loading;
import Dialog.SelectAddressDialog;
import Dialog.SelectList.OnSelectDialogListener;
import Dialog.SelectListDialog;
import Dialog.SelectTwoDialog;
import SearchLayout.ItemList.ItemInfo;
import SearchLayout.OnSearchLayoutListener;
import SearchLayout.SearchInfo;
import SearchLayout.SearchState;
import connection.Conn_Address;
import connection.JsonParse;

/**
 * Created by KyoungSik on 2017-03-20.
 * 옵션페이지 검색 설정
 */
public class OptionSearchLayout  {

    private final String TAG = "OptionSearchLayout";

    public final int DOMESTIC = 0;
    public final int OVERSEAS = 1;

    public final int STARTAREA = 0;
    public final int ENDAREA = 1;

    private LinearLayout linearLayout;//검색 조건 레이아웃
    private Activity act;

    private TextView itemText;//선택된 품목을 보여주는 TextView
    private TextView myareaText;//선택된 내주변 항목을 보여주는 TextView
    private EditText startText;//출발지 주소를 보여주는 EditText
    private EditText endText;//도착지 주소를 보여주는 EditText
    private EditText keyworkdText;//키워드 EditText

    private Loading loading;
    private ArrayList<ItemInfo> itemInfos;
    private SearchInfo searchInfo;//검색 정보를 담는 구조체
    private OnOptionSearchLayoutListener onOptionSearchLayoutListener;

    public OptionSearchLayout(LinearLayout linearLayout,Activity act){
        Log.d(TAG, "생성자");
        this.act = act;
        this.linearLayout = linearLayout;
        loading = new Loading(act);
        itemInfos = new ArrayList<>();
        init();
    }

    private void init(){
        itemText = (TextView)linearLayout.findViewById(R.id.searhItemText);
        myareaText = (TextView)linearLayout.findViewById(R.id.myareaText);
        startText = (EditText)linearLayout.findViewById(R.id.alDeparturePointText);
        endText = (EditText)linearLayout.findViewById(R.id.alArrivePointText);
        keyworkdText = (EditText)linearLayout.findViewById(R.id.keywordEdit);
        LinearLayout searchState = (LinearLayout)linearLayout.findViewById(R.id.searchStateLinear);
        searchInfo = new SearchInfo();
        searchState.setVisibility(View.GONE);
        //initSeaerchState();//전체.화물 및 배송자 선택 버튼 이벤트
        itemButtonEvent();//품목 버튼 이벤트
        myareaButtonEvent();//내주변 버튼 이벤트
       // startEndAreaEvent();//출발지 도착지 이벤트
    }

    /* 전체.화물 및 배송자 선택 버튼 이벤트
    *
    * */
    private void initSeaerchState(){
        SearchState searchState = new SearchState(linearLayout,act) {
            @Override
            public void onClickButton(int state, SearchState searchState) {
                if(searchState.SEARCH_ALL == state){
                    Log.d(TAG,"SEARCH_ALL");
                }else if(searchState.SEARCH_FREIGHT == state){
                    Log.d(TAG,"SEARCH_FREIGHT");
                }else if(searchState.SEARCH_DELIVERY == state){
                    Log.d(TAG,"SEARCH_DELIVERY");
                }

                if(onOptionSearchLayoutListener != null)
                    onOptionSearchLayoutListener.onClickSearchState(state);

            }
        };
    }
    /* 품목 정보 받아오기 URL
    *
    * */
    private String getItemInfoUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_ITEMINFO;
        return urlStr;
    }

    /* 품목 정보받아오기
    *
    * */
    private void getItemInfo(){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {
                loading.show();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {

                if(flag.matches("1")){
                    Log.d(TAG, "message : " + message);
                    if(result.size()>0) {
                        setItemInfos(result);
                    }
                }else{

                }
                loading.dismiss();
            }
        };
        jsonParse.getJsonParse(getItemInfoUrlStr());
    }
    /* 화물리스트 정보 분류하기
    *
    * */
    private void setItemInfos(ArrayList<ArrayList<String>> result){
        itemInfos.clear();
        String itemName[] = new String[result.get(0).size()];
        for(int i=0;i<result.get(0).size();i++){
            Log.d(TAG, "freight_idx : " + result.get(0).get(i));
            Log.d(TAG, "freight_name : " + result.get(1).get(i));
            ItemInfo itemInfo = new ItemInfo();
            itemInfo.setItem_idx(result.get(0).get(i));
            itemInfo.setItemName(result.get(1).get(i));
            itemName[i] = itemInfo.getItemName();
            itemInfos.add(itemInfo);
        }
        showItemDialog(itemName);
    }
    /* 품목 다이얼로그 보여주기
    *
    * */
    private void showItem(){

        getItemInfo();

    }
    //품목 선택 다이얼로그
    private void showItemDialog(String[] titlelist){
        //품목 선택 다이얼로그
        SelectListDialog selectListDialog = new SelectListDialog(act, titlelist);
        selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
            @Override
            public void onClickCancel() {

            }

            @Override
            public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                itemText.setText(titlelist[position]);
                searchInfo.setItemidx(itemInfos.get(position).getItem_idx());
                searchInfo.setItemName(titlelist[position]);
                if(onOptionSearchLayoutListener != null)
                    onOptionSearchLayoutListener.onClickItem(position,titlelist);
                selectListDialog.dismiss();
            }

            @Override
            public void onClickList(int position, View view, String[] titlelist) {
                //  view.setBackgroundColor(Color.BLUE);
                Log.d(TAG, "position : " + titlelist[position]);
            }
        });
        selectListDialog.getTitleImage().setImageResource(R.drawable.icon_map_stuff);
        selectListDialog.getTitleText().setText("품목 검색");
        selectListDialog.show();
    }
    /*품목 선택 버튼
    *
    * */
    private void itemButtonEvent(){

        Button itembtn = (Button)linearLayout.findViewById(R.id.searchItembtn);
        itembtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick");
                showItem();
            }
        });

    }
    /*내주변 선택 버튼 이벤트
    *
    * */
    private void myareaButtonEvent(){
        Button myareabtn = (Button)linearLayout.findViewById(R.id.myareabtn);
        myareabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick");
                String[] titlelist = act.getResources().getStringArray(R.array.myarea_list);
                String[] subtitle = act.getResources().getStringArray(R.array.km);
                //내주변 선택 다이얼로그
                SelectListDialog selectListDialog = new SelectListDialog(act, titlelist,subtitle);
                selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                    @Override
                    public void onClickCancel() {

                    }

                    @Override
                    public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                        if (titlelist[position].matches("전국")) {
                            searchInfo.setMyarea_name("0");
                            myareaText.setText(titlelist[position]);
                        } else {
                            searchInfo.setMyarea_name(titlelist[position]);
                            myareaText.setText(titlelist[position] + " KM");
                        }
                       /* myareaText.setText(titlelist[position] + " KM");
                        searchInfo.setMyarea_idx("" + position);
                        searchInfo.setMyarea_name(titlelist[position]);*/
                        if(onOptionSearchLayoutListener != null)
                            onOptionSearchLayoutListener.onClickItem(position,titlelist);
                        selectListDialog.dismiss();
                    }

                    @Override
                    public void onClickList(int position, View view, String[] titlelist) {
                        //  view.setBackgroundColor(Color.BLUE);
                        Log.d(TAG, "position : " + titlelist[position]);
                    }
                });
                selectListDialog.getTitleImage().setImageResource(R.drawable.icon_map_white);
                selectListDialog.getTitleText().setText("내주변 검색");
                selectListDialog.show();
            }
        });
    }

    /* 출발지 도착지 이벤트
   *
   * */
   /* private void startEndAreaEvent(){
        startText = (TextView)linearLayout.findViewById(R.id.alDeparturePointText);
        startText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "startText event");
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(act) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {

                        selectInternatinl(DOMESTIC,STARTAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {
                        selectInternatinl(OVERSEAS,STARTAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
            }
        });

        endText = (TextView)linearLayout.findViewById(R.id.alArrivePointText);
        endText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "endText event");
                SelectTwoDialog selectTwoDialog = new SelectTwoDialog(act) {
                    @Override
                    public void clickOneButton(SelectTwoDialog selectTwoDialog) {

                        selectInternatinl(DOMESTIC,ENDAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickTwoButton(SelectTwoDialog selectTwoDialog) {

                        selectInternatinl(OVERSEAS,ENDAREA);
                        selectTwoDialog.dismiss();
                    }

                    @Override
                    public void clickCancelButton() {

                    }
                };
                selectTwoDialog.getSelectOneButton().setText("국내");
                selectTwoDialog.getSelectTwoButton().setText("국외");
                selectTwoDialog.show();
            }
        });
    }*/

    /* 국내, 국외 구분 함수
  *
  * */
    private void selectInternatinl(int countryState, final int pointState){
        if(countryState == DOMESTIC){
            handler.sendEmptyMessage(pointState);
        }else if(countryState == OVERSEAS){
            String[] country;
            Locale[] locales = Locale.getAvailableLocales();

            String[] isoCodes = Locale.getISOCountries();
            country = new String[isoCodes.length];

            for( int i=0; i < isoCodes.length; i++ ){
                Locale locale = new Locale( "en",isoCodes[ i ] );
                Log.d( TAG,"country : " + locale.getDisplayCountry() );
                country[i] = locale.getDisplayCountry();
            }
            //나라 선택 다이얼로그
            SelectListDialog selectListDialog = new SelectListDialog(act, country);
            selectListDialog.setOnSelectDialogListener(new OnSelectDialogListener() {
                @Override
                public void onClickCancel() {

                }

                @Override
                public void onClickConfirm(SelectListDialog selectListDialog, int position, String[] titlelist) {
                    if(pointState == STARTAREA){
                        startText.setText(titlelist[position] + selectListDialog.getSubAddressEdit().getText());
                    }else if(pointState == ENDAREA){
                        endText.setText(titlelist[position] + selectListDialog.getSubAddressEdit().getText());
                    }
                    selectListDialog.dismiss();
                }

                @Override
                public void onClickList(int position, View view, String[] titlelist) {
                    //  view.setBackgroundColor(Color.BLUE);
                    Log.d(TAG, "position : " + titlelist[position]);

                }
            });
            selectListDialog.getTitleText().setText("나라 선택");
            selectListDialog.getSubLinear().setVisibility(View.VISIBLE);
            selectListDialog.show();
        }
    }

    /* 지도 선택 다이얼로그 띄우기
    *
    * */
    android.os.Handler handler = new android.os.Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == STARTAREA) {
                // 국내
                SelectAddressDialog selectAddressDialog = new SelectAddressDialog(act) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        startText.setText(address);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();
            }else if(msg.what == ENDAREA){
                // 국내
                SelectAddressDialog selectAddressDialog = new SelectAddressDialog(act) {

                    @Override
                    public void onClickSelect(String lat, String lng, String address) {
                        Log.d(TAG, "lat : " + lat + "  lng : " + lng + "  address : " + address);
                        endText.setText(address);
                    }

                    @Override
                    public void onClickCancel() {

                    }
                };
                selectAddressDialog.show();
            }
        }
    };

    public TextView getItemText() {
        return itemText;
    }

    public void setItemText(TextView itemText) {
        this.itemText = itemText;
    }

    public TextView getMyareaText() {
        return myareaText;
    }

    public void setMyareaText(TextView myareaText) {
        this.myareaText = myareaText;
    }

    public TextView getEndText() {
        return endText;
    }

    public TextView getStartText() {
        return startText;
    }

    public EditText getKeyworkdText() {
        return keyworkdText;
    }

    public SearchInfo getSearchInfo() {
        return searchInfo;
    }

    public void setSearchInfo(SearchInfo searchInfo) {
        this.searchInfo = searchInfo;
    }

    public void setOnOptionSearchLayoutListener(OnOptionSearchLayoutListener onOptionSearchLayoutListener) {
        this.onOptionSearchLayoutListener = onOptionSearchLayoutListener;
    }
}
