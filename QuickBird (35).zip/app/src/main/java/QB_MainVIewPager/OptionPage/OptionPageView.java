package QB_MainVIewPager.OptionPage;

import android.app.Activity;
import android.app.VoiceInteractor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import Database.DB_SingleTon;
import SearchLayout.SearchInfo;
import com.quickbird.quickbird.R;

import org.w3c.dom.Text;

import java.util.ArrayList;

import SearchLayout.SearchLayout;
import SearchLayout.OnSearchLayoutListener;
import connection.Conn_Address;
import connection.JsonParse;

/**
 * Created by KyoungSik on 2017-03-13.
 * 메인 뷰페이저의 설정 페이지
 *
 */
public class OptionPageView {

    private final String TAG = "OptionPageView";

    public final int KAKAO_SHARE = 1;//카카오톡 공유
    public final int LINE_SHARE = 2;//라인 공유
    public final int PUSH_ONOFF = 3;//알람 설정 끄고켜기

    private boolean optionFinish = false;

    private View view;
    private Activity act;
    private  Button alarmbtn;

    private boolean alarmState = false;//알람설정 버튼 상태

    private OnOptionListener onOptionListener;//알람 설정 이벤트 리스너
    private OptionSearchLayout filterLayout;

    private SearchInfo searchInfo;

    private TextView noticebadgeText;

    public OptionPageView(View view, Activity act){
        this.act = act;
        searchInfo = new SearchInfo();
        init(view);
        if(!DB_SingleTon.getInstance(act).getUserInfoTable().getDelivery_idx().matches("0")) {
            NoticeCount();
        }else {
            optionFinish = true;
            if(onOptionListener != null)
                onOptionListener.onEndInfo();
        }

    }

    private void init(View view){
        //알람 설정
        LinearLayout search_linear = (LinearLayout)view.findViewById(R.id.optionlienar);
        noticebadgeText = (TextView)view.findViewById(R.id.noticebadgeText);
        filterLayout = new OptionSearchLayout(search_linear,act);
        filterLayout.setOnOptionSearchLayoutListener(new OnOptionSearchLayoutListener() {
            @Override
            public void onClickSearchState(int state) {
                Log.d(TAG, "onClickSearchState : " + state);
                searchInfo.setSearchState(state);
            }

            @Override
            public void onClickItem(int position, String[] titlelist) {
                Log.d(TAG, "titllist : " + titlelist[position]);
                searchInfo.setItemidx("" + position);
            }

        });

        //알람설정 버튼
        alarmbtn = (Button)view.findViewById(R.id.alarmbtn);
        alarmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!alarmState){
                  //  v.setBackgroundResource(R.drawable.icon_alarm_on);
                    v.setBackgroundResource(R.drawable.button_red_rect);
                    alarmbtn.setText("ON");
                    alarmState = true;
                }else{
                   // v.setBackgroundResource(R.drawable.icon_alarm_off);
                    v.setBackgroundResource(R.drawable.button_gray_rect);
                    alarmbtn.setText("OFF");
                    alarmState = false;
                }

                int statePush = 0;
                if(alarmState){
                    statePush = 1;
                }
                if(onOptionListener != null)
                    onOptionListener.onClickPushState(statePush);
            }
        });

        if(DB_SingleTon.getInstance(act).getUserInfoTable().getPushOnOff().matches("1")){
            alarmbtn.setBackgroundResource(R.drawable.button_red_rect);
            alarmbtn.setText("ON");
            alarmState = true;
        }else{
            alarmbtn.setBackgroundResource(R.drawable.button_gray_rect);
            alarmbtn.setText("OFF");
            alarmState = false;
        }
        //알림 설정 저장
    /*    Button storagebtn = (Button)view.findViewById(R.id.qmostorageOption);
        storagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchInfo.setStart_address(filterLayout.getStartText().getText().toString());
                searchInfo.setEnd_address(filterLayout.getEndText().getText().toString());
                searchInfo.setKeyword(filterLayout.getKeyworkdText().getText().toString());
                Log.d(TAG,"storeagebtn startAddress : " + searchInfo.getStart_address() + " endAddress : " + searchInfo.getEnd_address() + " searchState : " + searchInfo.getSearchState() + " itemidx : " + searchInfo.getItemidx() + " keyword " + searchInfo.getKeyword());
                if(onOptionListener != null)
                    onOptionListener.onClickStoreage(searchInfo);
            }
        });
*/

        //카카오톡 공유하기
        Button kakaosharebtn = (Button)view.findViewById(R.id.qmokakaosharebtn);
        kakaosharebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onOptionListener != null)
                    onOptionListener.onClickState(KAKAO_SHARE);
            }
        });

        //라인 공유하기
        Button linesharebtn = (Button)view.findViewById(R.id.qmolinesharebtn);
        linesharebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onOptionListener != null)
                    onOptionListener.onClickState(LINE_SHARE);
            }
        });

        //저장하기
        Button registerbtn = (Button)view.findViewById(R.id.qmostorageOption);
        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filterLayout.getSearchInfo().setStart_address(filterLayout.getStartText().getText().toString());
                filterLayout.getSearchInfo().setEnd_address(filterLayout.getEndText().getText().toString());
                filterLayout.getSearchInfo().setKeyword(filterLayout.getKeyworkdText().getText().toString());
                Log.d(TAG,"item_idx : " + filterLayout.getSearchInfo().getItemidx() + " startAddress : " + filterLayout.getSearchInfo().getStart_address() + " endAddress : " + filterLayout.getSearchInfo().getEnd_address() + " area : " + filterLayout.getSearchInfo().getMyarea_idx() + " keyword : " + filterLayout.getSearchInfo().getKeyword());
                if(onOptionListener != null)
                    onOptionListener.onClickStoreage(filterLayout.getSearchInfo());
            }
        });
        //버전 TextView
        TextView versionText = (TextView)view.findViewById(R.id.qmoversionText);
        versionText.setText(versionText.getText()+verSionInfo());

        Button noticebtn = (Button)view.findViewById(R.id.noticebtn);
        noticebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onOptionListener != null)
                    onOptionListener.onClickNotice();
            }
        });
    }

    /* 알림 설정 저장 받아오기 url
    *
    * */
    private String getpushOptionUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.REQUEST_PUSHOPTION_;
        urlStr = urlStr + "?delivery_idx=" + DB_SingleTon.getInstance(act).getUserInfoTable().getDelivery_idx();
        Log.d(TAG, "getpushOptionUrlStr : " + urlStr);
        return urlStr;
    }




    /* 알림 설정 저장 받아오기
    *
     */
    private void pushOption(){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {

            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "optionUpdate flag : " + flag);
                Log.d(TAG, "optionUpdate message : " + message);
                Log.d(TAG, "optionUpdate message : " + message);

                if (flag.matches("1")) {
                    if(result.get(0).size()>0) {
                        Log.d(TAG, "optionUpdate distance : " + result.get(0).get(0));
                        Log.d(TAG, "optionUpdate sp_address : " + result.get(1).get(0));
                        Log.d(TAG, "optionUpdate ap_address : " + result.get(2).get(0));
                        Log.d(TAG, "optionUpdate item_idx : " + result.get(3).get(0));
                        Log.d(TAG, "optionUpdate item_name : " + result.get(4).get(0));
                        Log.d(TAG, "optionUpdate keyword : " + result.get(5).get(0));

                        filterLayout.getSearchInfo().setMyarea_name(result.get(0).get(0));
                        filterLayout.getSearchInfo().setStart_address(result.get(1).get(0));
                        filterLayout.getSearchInfo().setEnd_address(result.get(2).get(0));
                        filterLayout.getSearchInfo().setItemidx(result.get(3).get(0));
                        filterLayout.getSearchInfo().setItemName(result.get(4).get(0));
                        filterLayout.getSearchInfo().setKeyword(result.get(5).get(0));
                        setFilterLayoutView();
                    }
                } else {

                }
                optionFinish = true;
                if(onOptionListener != null)
                    onOptionListener.onEndInfo();
            }
        };
        jsonParse.getJsonParse(getpushOptionUrlStr());
    }


    /* 공지사항 최근 갯수 받아오기 url
*
* */
    private String getNoticeCountUrlStr(){
        String urlStr = Conn_Address.SERVER_ADDRESS + Conn_Address.NOTICE_COOUNT;
        Log.d(TAG, "getNoticeCountUrlStr : " + urlStr);
        return urlStr;
    }


    /* 알림 설정 저장 받아오기
  *
   */
    private void NoticeCount(){
        JsonParse jsonParse = new JsonParse(act) {
            @Override
            public void startParse() {
                if(onOptionListener != null)
                    onOptionListener.onStartInfo();
            }

            @Override
            public void behavior(String flag, String message, ArrayList<ArrayList<String>> result) {
                Log.d(TAG, "NoticeCount flag : " + flag);
                Log.d(TAG, "NoticeCount message : " + message);

                if (flag.matches("1")) {
                    if(onOptionListener != null)
                        onOptionListener.onNoticeCount(Integer.parseInt(message));
                } else {

                }
                pushOption();
            }
        };
        jsonParse.getJsonParse(getNoticeCountUrlStr());
    }

    /* 옵션 설정 예외처리
    *
    * */
    private void setFilterLayoutView() {
        if (!filterLayout.getSearchInfo().getStart_address().matches("null")){//출발지
            filterLayout.getStartText().setText(filterLayout.getSearchInfo().getStart_address());
        }else {
            filterLayout.getStartText().setText("");
        }

        if (!filterLayout.getSearchInfo().getEnd_address().matches("null")) {//도착지
            filterLayout.getEndText().setText(filterLayout.getSearchInfo().getEnd_address());
        }else {
            filterLayout.getEndText().setText("");
        }

        if (!filterLayout.getSearchInfo().getKeyword().matches("null")) {//키워드
            filterLayout.getKeyworkdText().setText(filterLayout.getSearchInfo().getKeyword());
        }else {
            filterLayout.getKeyworkdText().setText("");
        }

        if (!filterLayout.getSearchInfo().getItemName().matches("null")) {//품목
            filterLayout.getItemText().setText(filterLayout.getSearchInfo().getItemName());
        }else {
            filterLayout.getItemText().setText("");
        }

        if(filterLayout.getSearchInfo().getMyarea_name().matches("0")){
            filterLayout.getMyareaText().setText("전국");
        } else if (!filterLayout.getSearchInfo().getMyarea_name().matches("null")) {//내주변
            filterLayout.getMyareaText().setText(filterLayout.getSearchInfo().getMyarea_name()+"KM");
        }else {
            filterLayout.getItemText().setText("");
        }


    }
    //앱 버전 알아오기
    private String verSionInfo(){
        String version="";
        try {
            PackageInfo i = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
            version = i.versionName;
        } catch(PackageManager.NameNotFoundException e) { }
        return version;
    }

    public boolean isOptionFinish() {
        return optionFinish;
    }

    public void setOptionFinish(boolean optionFinish) {
        this.optionFinish = optionFinish;
    }

    public OptionPageView getOptionPageView(){
        return this;
    }

    public OnOptionListener getOnOptionListener() {
        return onOptionListener;
    }

    public void setOnOptionListener(OnOptionListener onOptionListener) {
        this.onOptionListener = onOptionListener;
    }

    public TextView getNoticebadgeText() {
        return noticebadgeText;
    }
}
